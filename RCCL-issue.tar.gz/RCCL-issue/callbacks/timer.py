import time
from lightning.pytorch.callbacks import Callback
from typing import Optional

class TimerCallback(Callback):
    def __init__(self):
        self.epoch_start_time: Optional[float] = None
        self.train_start_time: Optional[float] = None
        self.validation_start_time: Optional[float] = None
        self.train_time: float = 0.0

    def on_train_epoch_start(self, trainer, pl_module):
        self.epoch_start_time = time.time()
        self.train_start_time = time.time()
        self.train_time = 0.0

    def on_validation_start(self, trainer, pl_module):
        # Pause training timer when validation starts
        if self.train_start_time is not None:
            self.train_time += time.time() - self.train_start_time
            self.train_start_time = None
        
        self.validation_start_time = time.time()

    def on_validation_end(self, trainer, pl_module):
        # Log validation time using direct logger access
        if self.validation_start_time is not None:
            validation_time = time.time() - self.validation_start_time
            
            # Use trainer.logger directly (Lightning's recommended approach)
            if trainer.logger:
                trainer.logger.experiment.log({
                    "validation_time": validation_time
                }, step=trainer.global_step)
        
        # Resume training timer after validation
        self.train_start_time = time.time()

    def on_train_epoch_end(self, trainer, pl_module):
        # Capture any remaining training time
        if self.train_start_time is not None:
            self.train_time += time.time() - self.train_start_time
        
        # These hooks are safe for pl_module.log()
        pl_module.log("train_time", self.train_time, on_step=False, on_epoch=True, prog_bar=True, sync_dist=True)
        
        if self.epoch_start_time is not None:
            total_epoch_time = time.time() - self.epoch_start_time
            pl_module.log("epoch_total_time", total_epoch_time, on_step=False, on_epoch=True, prog_bar=True, sync_dist=True)
