# 3rd iteration feasibility
- changed behavior of bottleneck (use adapted bottleneck class instead of conv layer)
- added 3-layer bottleneck
- fixed transforms (and removed normalization)