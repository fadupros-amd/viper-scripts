from typing import Any
from torch.utils.data import Dataset, DataLoader
import numpy as np
from torch.nn.functional import interpolate
from torchvision.transforms import v2
import torch

class CacheDataset(Dataset):
    def __init__(self, *args, **kwargs) -> None:
        super().__init__(*args, **kwargs)
        self.cache = {}
       
    def __getitem__(self, index) -> Any:
        """
        Retrieves an item from the dataset, using the cache if available.
        If the item is not in the cache, it calls _load_item to load it.
        This method handles the caching logic and should not be overridden by subclasses.
        Subclasses should implement the _load_item method for data loading.
        """
        if index in self.cache:
            return self.cache[index].clone().detach()
        else:
            item = self.__loaditem__(index)
            self.cache[index] = item
            return item
        
    def __loaditem__(self, index):
            # This method should be implemented by the child class
            raise NotImplementedError("Child class must implement _load_item method")
    

def grid_transform(image_list: list, scale):
    '''
    Arguments:
        image_list(list): list of images for creating a grid. Elements should have shape [C, W, H]
    
    Returns:
        fused grid-image
    '''
    assert (scale ** 2) == len(image_list)
    shape = image_list[0].shape
    assert shape[0] == 3 or shape[0] == 6, "Image does not have 3 channels: might not be an RGB image"

    # orig_size = shape[-2:]
    # new_size = int(orig_size/scale)
    image_list = [interpolate(i.unsqueeze(0), scale_factor = 1/scale, mode = "bilinear").squeeze() for i in image_list]
    index = 0
    stacked = []
    for i in range(scale):
        index = i*scale
        stacked.append(torch.concatenate(image_list[index:index+scale], axis = 2))
    stacked = torch.concatenate(stacked, axis = 1)
    return stacked

