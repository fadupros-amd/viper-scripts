import os
from data.imagenet import TinyImagenetDataset
from experiment.experiment import Experiment
from torch.utils.data import DataLoader
import lightning.pytorch as pl
import torchvision.transforms.v2 as transforms
import torch
from torchvision.transforms.functional import InterpolationMode
from bcos.data.transforms import AddInverse
from models.lightning_module import is_bcos
from data.grid_pg import GridPGDataset
from data.utils import DatasetWithIndices
from torchvision.datasets import FGVCAircraft
from datasets import load_dataset, Image, Dataset, load_from_disk
import logging

log = logging.getLogger("lightning")   # or your own name


HUGGINGFACE_DATASETS_CACHE = os.environ.get("HUGGINGFACE_DATASETS_CACHE", "/ptmp/rmaser/data/huggingface/datasets")
assert HUGGINGFACE_DATASETS_CACHE, "HUGGINGFACE_DATASETS_CACHE environment variable must be set to a valid path."
HUGGINGFACE_DATASETS_CACHE_ARROW = os.path.join(HUGGINGFACE_DATASETS_CACHE, "arrow")
DEFAULT_CROP_SIZE = 224
IMAGENET_MEAN = (0.485, 0.456, 0.406)
IMAGENET_STD = (0.229, 0.224, 0.225)
HFLIP_PROB = 0.5
 

class BcosDataModule(pl.LightningDataModule):
    def __init__(self, experiment: Experiment):
        super().__init__()
        self.dataloader_args = {
            "num_workers": experiment.num_workers,
            "pin_memory": experiment.pin_memory,
            "persistent_workers": experiment.persistent_workers,
            "batch_size": experiment.batch_size
        }
        self.dataset: str = experiment.dataset
        self.experiment = experiment
        self.num_classes = experiment.num_classes
        self.high_confidence_gridpg_set = None


    def setup(self, stage: str):
        import logging
        log = logging.getLogger("lightning.pytorch")
        log.info(f"DataModule setup called with stage: {stage}")
        log.info(f"DataModule self.dataset: {self.dataset}")

        if self.experiment.pretrained_weights.startswith("huggingface#google/vit-"):
            normalization_mean = (0.5, 0.5, 0.5)
            normalization_std = (0.5, 0.5, 0.5)
            # raise NotImplementedError("Check if this is correct.")
        else:
            normalization_mean = IMAGENET_MEAN
            normalization_std = IMAGENET_STD

        if self.dataset.lower() == "TinyImagenet".lower():
            # train_path = os.path.join(self.data_path, "train")
            # val_path = os.path.join(self.data_path, "val")
            transforms = self.imagenet_transforms(self.experiment.model, self.experiment.efficient_bcos, normalize=self.experiment.use_normalization, precision=self.experiment.model_precision, normalization_mean=normalization_mean, normalization_std=normalization_std)

            self.train_set = TinyImagenetDataset(split="train", transform=transforms[0])
            self.val_set = TinyImagenetDataset(split="val", transform=transforms[1])

        elif self.dataset.lower() == "imagenet1k".lower():            
            train_tf, val_tf = self.imagenet_transforms(self.experiment.model, self.experiment.efficient_bcos, normalize=self.experiment.use_normalization, precision=self.experiment.model_precision, normalization_mean=normalization_mean, normalization_std=normalization_std)
            self.train_set = self.load_hf_dataset("ILSVRC/imagenet-1k", split="train", transform=train_tf)
            self.val_set = self.load_hf_dataset("ILSVRC/imagenet-1k", split="validation", transform=val_tf)


        elif self.dataset.lower().startswith("FGVCAircraft".lower()):
            if "#" in self.dataset:
                dataset_name , annotation_level = self.dataset.split("#")
                log.info(f"Dataset name: {dataset_name}, Annotation level: {annotation_level} with num_classes: {self.experiment.num_classes}")
            else:
                annotation_level = "variant"

            transforms = self.fgvc_transforms(self.experiment.model, self.experiment.efficient_bcos, normalize=self.experiment.use_normalization)
            
            self.train_set = FGVCAircraft(
                    root = self.experiment.data_path,
                    split = "train",
                    transform = transforms[0],
                    download = True,
                    annotation_level=annotation_level,
                    )

            self.val_set = FGVCAircraft(
                    root = self.experiment.data_path,
                    split = "val",
                    transform = transforms[1],
                    download = True,
                    annotation_level=annotation_level,
                    )

        else:
            raise NotImplementedError("Only tiny imagenet implemented for now.")
        
        if self.experiment.use_normalization:
            log.info("Using normalization in data module.")
        log.info(f"Dataset: {self.dataset}, Train set size: {len(self.train_set)}, Val set size: {len(self.val_set)}")
        # log.info(f"Train transforms: {self.train_set.transform}")
        # log.info(f"Val transforms: {self.val_set.transform}")


        self.pg_set_val = GridPGDataset(self.val_set, scale=self.experiment.grid_pg_scale, num_samples=self.experiment.limit_grid_samples)

    def load_hf_dataset(self, dataset_name, split, transform):
        # det_transforms, non_det_transform = self.get_deterministic_transforms(transform)

        non_det_transform = transform # TODO change later
        # Define batched wrapper functions for HuggingFace dataset format
        def non_det_transform_wrapper(batch):
            images = batch["image"]
            # Convert RGBA to RGB if needed at PIL level
            images = [img.convert('RGB') if img.mode != 'RGB' else img for img in images]
            batch["image"] = [non_det_transform(img) for img in images]
            return batch


        # Load datasets (keep PIL images, no with_format)
        # self.train_set = load_dataset("ILSVRC/imagenet-1k", split="train", streaming=False, cache_dir=HUGGINGFACE_DATASETS_CACHE).with_transform(train_transform)
        # self.val_set = load_dataset("ILSVRC/imagenet-1k", split="validation", streaming=False, cache_dir=HUGGINGFACE_DATASETS_CACHE).with_transform(val_transform)
        HUGGINGFACE_DATASETS_CACHE_ARROW_SPLIT = os.path.join(HUGGINGFACE_DATASETS_CACHE_ARROW, f"{dataset_name}_{split}.arrow")
        # if not os.path.exists(HUGGINGFACE_DATASETS_CACHE_ARROW_SPLIT):
        # log.info("HuggingFace datasets not found in cache, loading from source.")
        dataset = load_dataset(dataset_name, split=split, streaming=False, cache_dir=HUGGINGFACE_DATASETS_CACHE, trust_remote_code=True)

        # Save to disk for future use

        # TODO add efficient version later
        # dataset = self.setup_hf_dataset(dataset, det_transforms, HUGGINGFACE_DATASETS_CACHE_ARROW_SPLIT)
        # dataset = load_from_disk(HUGGINGFACE_DATASETS_CACHE_ARROW_SPLIT).with_transform(non_det_transform)
        # dataset.set_format(type="torch", columns=["image", "label"])
        dataset = dataset.with_format("torch").with_transform(non_det_transform_wrapper)
        
        return dataset
    
    def setup_hf_dataset(self, dataset, transform, path):
        def preprocess(batch):
            processed_batch = [transform(img) for img in batch["image"]]
            return {"image": processed_batch, "label": batch["label"]}

        dataset = dataset.map(preprocess, batched=True, num_proc=self.experiment.num_workers, batch_size=self.experiment.batch_size, desc="Processing images")
        dataset.save_to_disk(path)
        return dataset 
    
    def get_deterministic_transforms(self, transform):
        """
        Returns a deterministic version of the transforms.
        This is useful for debugging and reproducibility.
        """
        transforms_list = transform.transforms

        deterministic_transform_classes = [
            transforms.PILToTensor,
        ]
        deterministic_transforms = []
        non_deterministic_transforms = []
        non_det_found = False

        # separate first deterministic from non-deterministic transforms
        for transform in transforms_list:
            for transform_class in deterministic_transform_classes:
                if isinstance(transform, transform_class) and not non_det_found:
                    deterministic_transforms.append(transform)
                else:
                    non_det_found = True
                    non_deterministic_transforms.append(transform)

        return transforms.Compose(deterministic_transforms), transforms.Compose(non_deterministic_transforms)

    @staticmethod
    def imagenet_transforms(model=None, ignore_inverse=False, normalize = False, precision=torch.float32, normalization_mean=IMAGENET_MEAN, normalization_std=IMAGENET_STD):
        '''
        Mostly taken from bcos.data.presets.ImageNetClassificationPresetTrain. Returns tuple of (train_transforms, val_transforms).
        '''
        precision = torch.float32
        train = [
            transforms.PILToTensor(),  # Convert PIL to tensor first
            transforms.RandomResizedCrop(size=DEFAULT_CROP_SIZE , interpolation=InterpolationMode.BILINEAR),
            transforms.RandomHorizontalFlip(p=HFLIP_PROB),
            transforms.ToDtype(precision, scale=True),  # Convert to float and scale [0,1]
        ]

        val = [
                transforms.PILToTensor(),  # Convert PIL to tensor first
                transforms.Resize(256),
                transforms.CenterCrop(DEFAULT_CROP_SIZE),
                transforms.ToDtype(precision, scale=True),  # Convert to float and scale [0,1]
        ]
        
        if normalize:
            train.append(transforms.Normalize(mean=normalization_mean, std=normalization_std))
            val.append(transforms.Normalize(mean=normalization_mean, std=normalization_std))
            # log.info("Using normalization_mean and std:", normalization_mean, normalization_std)
                    
        if is_bcos(model) and not ignore_inverse:
            train.append(AddInverse())
            val.append(AddInverse())
        
        return transforms.Compose(train), transforms.Compose(val)

    @staticmethod
    def fgvc_transforms(model=None, ignore_inverse=False, normalize = False):
        '''
        Mostly taken from bcos.data.presets.ImageNetClassificationPresetTrain. Returns tuple of (train_transforms, val_transforms).
        '''

        train = [
            transforms.PILToTensor(),
            transforms.Resize(500),
            transforms.RandomResizedCrop(size=448 , interpolation=InterpolationMode.BILINEAR),
            transforms.RandomHorizontalFlip(p=HFLIP_PROB),
            transforms.ToDtype(torch.float, scale=True),
        ]

        val = [
                transforms.Resize(500),
                transforms.CenterCrop(448),
                transforms.ToTensor(),
        ]

        if normalize:
            train.append(transforms.Normalize(mean=IMAGENET_MEAN, std=IMAGENET_STD))
            val.append(transforms.Normalize(mean=IMAGENET_MEAN, std=IMAGENET_STD))

        if is_bcos(model) and not ignore_inverse:
            train.append(AddInverse())
            val.append(AddInverse())
        
        return transforms.Compose(train), transforms.Compose(val)
    
    
    def train_dataloader(self):
        g = torch.Generator()
        g.manual_seed(self.experiment.seed)
        return DataLoader(self.train_set, shuffle=True, generator=g, drop_last=True, **self.dataloader_args)

    def val_dataloader(self):
        dataloaders = []

        # Original validation dataloader
        g_1 = torch.Generator()
        g_1.manual_seed(self.experiment.seed)
        dl1 = DataLoader(self.val_set, generator=g_1, shuffle=False, drop_last=True, **self.dataloader_args)
        dataloaders.append(dl1)

        # GridPG dataloader (either original or high-confidence)
        g_pg = torch.Generator()
        g_pg.manual_seed(self.experiment.seed)
        dl_pg = DataLoader(self.pg_set_val, shuffle=False, drop_last=True, generator=g_pg, **self.dataloader_args)
        dataloaders.append(dl_pg)

        return dataloaders
    
    def test_dataloader(self) -> list[DataLoader]:
        return self.val_dataloader()

    # def PGdataloader(self):
    #     g = torch.Generator()
    #     g.manual_seed(self.experiment.seed)
    #     return DataLoader(self.pg_set_val, generator=g, drop_last=True, shuffle=True, **self.dataloader_args)

    def val_dataloader_visualization(self):
        dataloaders = []

        # Original validation dataloader
        g_1 = torch.Generator()
        g_1.manual_seed(self.experiment.seed)
        dl1 = DataLoader(self.val_set, generator=g_1, shuffle=False, drop_last=True, **self.dataloader_args, batch_size=1)
        dataloaders.append(dl1)

        # GridPG dataloader (either original or high-confidence)
        g_pg = torch.Generator()
        g_pg.manual_seed(self.experiment.seed)
        dl_pg = DataLoader(self.pg_set_val, shuffle=False, drop_last=True, generator=g_pg, **self.dataloader_args, batch_size=1)
        dataloaders.append(dl_pg)

        return dataloaders

    def convert_to_label(self, id):
        return self.train_set.labels[id]


