from typing import Any
import warnings
from torch.utils.data import Dataset, DataLoader
import numpy as np
from torch.nn.functional import interpolate
from torchvision.transforms import v2
import torch
from data.cache_dataset import CacheDataset

class GridPGDataset(Dataset):
    def __init__(self, dataset=None, *args, scale=2, seed=42, num_samples, **kwargs) -> None:
        # self.transforms = v2.Compose([
        #     v2.ToDtype(dtype=torch.float32),
        # ])
        self.transforms = None
        super().__init__(*args, **kwargs)
        self.scale = scale
        self.rng = np.random.default_rng(seed)
        self.dataset = dataset
        self.cache = {}
        self.num_samples = num_samples

    def update_dataset(self, new_dataset):
        """Updates the underlying dataset."""
        self.dataset = new_dataset

    def __getitem__(self, index) -> Any:
        # print(f"Length of dataset: {len(self.dataset)}")
        # print(f"Index was: {index}")
        # Convert numpy int64 to Python int for HuggingFace datasets
        index = int(index)
        num_items = self.scale ** 2

        images, labels = self.check_cache(index)
        

        if images == None:
            images = []
            labels = []
            
            first_item = self.dataset.__getitem__(index)
            # Handle both dict and tuple formats
            if isinstance(first_item, dict):
                first_image = first_item["image"]
                first_label = first_item["label"]
            else:
                first_image = first_item[0]
                first_label = first_item[1]
            
            # print(f"GridPG item has shape: ", first_image.shape)
            images.append(first_image)
            labels.append(first_label)

            # Generate a shuffled array of indices excluding the current index
            available_indices = np.arange(len(self.dataset))
            available_indices = available_indices[available_indices != index]
            self.rng.shuffle(available_indices)

            # Iterate through the shuffled indices to find matching samples
            for idx in available_indices:
                if len(images) == num_items:
                    break # Exit if enough images are found

                # Convert numpy int64 to Python int for HuggingFace datasets
                idx = int(idx)
                item = self.dataset.__getitem__(idx)
                # Handle both dict and tuple formats
                if isinstance(item, dict):
                    image = item["image"]
                    label = item["label"]
                else:
                    image = item[0]
                    label = item[1]
                
                if label not in labels:
                    images.append(image)
                    labels.append(label)
            
            self.store_in_cache(index, images, labels)

        # Check if enough unique samples were found
        if len(images) < num_items:
            raise Exception()
            # Return dummy tensors with correct shape
            # Get the shape of the original image
            original_image_shape = self.dataset.__getitem__(index)[0].shape
            num_channels = original_image_shape[0]
            original_height = original_image_shape[1]
            original_width = original_image_shape[2]


            # Create dummy image tensor
            dummy_grid = torch.zeros(num_channels, original_height, original_width , dtype=torch.float32)

            # Create dummy labels tensor
            dummy_labels = torch.zeros(num_items, dtype=torch.long) # Assuming labels are long

            warnings.warn(f"Grid PG dataset returned dummy image.")
            return dummy_grid, dummy_labels

        grid = grid_transform(images, scale=self.scale)
        if self.transforms != None:
            grid = self.transforms(grid)
        
        labels = torch.tensor(labels)
        return grid, labels

    def check_cache(self, index):
        if index in self.cache: return self.cache[index]
        return None, None
    
    def store_in_cache(self, index, images, labels):
        self.cache[index] = (images, labels)
    
    def __len__(self):
        return min(len(self.dataset), self.num_samples)
    

def grid_transform(image_list: list, scale):
    '''
    Arguments:
        image_list(list): list of images for creating a grid. Elements should have shape [C, H, W]
    
    Returns:
        fused grid-image
    '''
    assert (scale ** 2) == len(image_list)
    shape = image_list[0].shape
    assert shape[0] == 3 or shape[0] == 6, "Image does not have 3 channels: might not be an RGB image"

    # orig_size = shape[-2:]
    # new_size = int(orig_size/scale)
    # scale_factor = 1

    # image_list = [interpolate(i.unsqueeze(0), scale_factor = scale_factor, mode = "bilinear").squeeze() for i in image_list]
    index = 0
    stacked = []
    for i in range(scale):
        index = i*scale
        stacked.append(torch.concatenate(image_list[index:index+scale], axis = 2))
    stacked = torch.concatenate(stacked, axis = 1)
    return stacked

