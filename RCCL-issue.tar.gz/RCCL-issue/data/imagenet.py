import json
from typing import Any
import pytorch_lightning as pl
import os # Added for path joining
import torch
import torch.utils
from torch.utils.data import Dataset, DataLoader
from torchvision.io import decode_image, ImageReadMode
from experiment.experiment import Experiment

import os

# Use environment variables for dataset paths
IMAGENET200_LABEL_MAPPING = os.environ.get("IMAGENET200_LABEL_MAPPING_PATH")
IMAGENET_LABELS = os.environ.get("IMAGENET_LABELS_PATH")
DATA_PATH = os.environ.get("DATA_PATH")
TRAIN_SPLIT = os.environ.get("IMAGENET_TRAIN_SPLIT")
VAL_SPLIT = os.environ.get("IMAGENET_VAL_SPLIT")

# Add checks to ensure environment variables are set
if not IMAGENET200_LABEL_MAPPING:
    raise EnvironmentError("IMAGENET200_LABEL_MAPPING_PATH environment variable not set.")
if not IMAGENET_LABELS:
    raise EnvironmentError("IMAGENET_LABELS_PATH environment variable not set.")
if not DATA_PATH:
    raise EnvironmentError("DATA_PATH environment variable not set.")

    
class TinyImagenetDataset(Dataset):
    def __init__(
        self,
        split: str,
        transform: Any = None,
    ):
        """
        Initializes the tiny imagenet dataset with caching.

        Args:
            data_path (str): Path to the root ImageNet data directory.
            train_set_path (str): Path to the .txt file containing the train set paths and labels.
            val_set_path (str):  Path to the .txt file containing the validation set paths and labels.
            split (str): Which split to use ('train' or 'val').
            transform (callable, optional): Optional transform to be applied on a sample.
            cache (bool): Whether to cache the transformed images.
            cache_dir (str): Directory to store the cache. If None, uses in-memory caching.
        """
        self.data_path = DATA_PATH
        if split=="train": 
            self.split_file = TRAIN_SPLIT 
            self.data_path = os.path.join(self.data_path, "train")
        elif split=="val": 
            self.split_file = VAL_SPLIT 
            self.data_path = os.path.join(self.data_path, "val")
        else: 
            raise Exception()
        self.transform = transform
        self.samples = []  # To store (image_path, label) tuples
        self.num_classes = 200
        self.imagenet_labels_file = IMAGENET_LABELS
        self.imagenet200_labels_mapping = IMAGENET200_LABEL_MAPPING

        # Construct label mapping
        self.construct_labels()

        # Read the split file
        try:
            with open(self.split_file, 'r') as f:
                for line in f:
                    parts = line.strip().split()
                    if len(parts) == 2:
                        relative_path, label_str = parts

                        # Construct full path relative to data_path
                        full_path = os.path.join(self.data_path, relative_path)
                        label = int(label_str)
                        self.samples.append((full_path, label))
                    else:

                        # Handle potential format issues or empty lines
                        print(f"Skipping malformed line in {self.split_file}: {line.strip()}")
        except FileNotFoundError:
            raise FileNotFoundError(f"Split file not found: {self.split_file}")
        except Exception as e:
            raise IOError(f"Error reading split file {self.split_file}: {e}")

    def construct_labels(self):
        """
        Parses the imagenet200 labels mapping file (int to int) and the
        imagenet labels file (int to string) to create a mapping from
        imagenet200 integer labels to standard imagenet string label names.
        """
        # Parse the imagenet200 integer-to-integer mapping
        self.imagenet200_to_imagenet_int_mapping = {}
        try:
            with open(self.imagenet200_labels_mapping, 'r') as f:
                for line in f:
                    parts = line.strip().split()
                    if len(parts) == 2:
                        try:
                            imagenet200_label = int(parts[0])
                            standard_imagenet_label = int(parts[1])
                            self.imagenet200_to_imagenet_int_mapping[imagenet200_label] = standard_imagenet_label
                        except ValueError:
                            print(f"Skipping malformed line in {self.imagenet200_labels_mapping}: Invalid integers in line {line.strip()}")
                    else:
                        print(f"Skipping malformed line in {self.imagenet200_labels_mapping}: {line.strip()}")
        except FileNotFoundError:
            raise FileNotFoundError(f"Imagenet200 labels mapping file not found: {self.imagenet200_labels_mapping}")
        except Exception as e:
            raise IOError(f"Error reading Imagenet200 labels mapping file {self.imagenet200_labels_mapping}: {e}")

        # Parse the standard imagenet integer-to-string mapping (JSON file)
        self.imagenet_int_to_string_mapping = {}
        try:
            with open(self.imagenet_labels_file, 'r') as f:
                self.imagenet_int_to_string_mapping = json.load(f)
                # Ensure keys are integers if they are loaded as strings
                self.imagenet_int_to_string_mapping = {int(k): v for k, v in self.imagenet_int_to_string_mapping.items()}
        except FileNotFoundError:
            raise FileNotFoundError(f"Standard Imagenet labels file not found: {self.imagenet_labels_file}")
        except json.JSONDecodeError:
            raise IOError(f"Error decoding JSON from standard Imagenet labels file: {self.imagenet_labels_file}")
        except Exception as e:
            raise IOError(f"Error reading standard Imagenet labels file {self.imagenet_labels_file}: {e}")

        # Create the final mapping from imagenet200 integer to standard imagenet string
        self.imagenet200_to_string_mapping = {}
        for imagenet200_label, standard_imagenet_label in self.imagenet200_to_imagenet_int_mapping.items():
            if standard_imagenet_label in self.imagenet_int_to_string_mapping:
                self.imagenet200_to_string_mapping[imagenet200_label] = self.imagenet_int_to_string_mapping[standard_imagenet_label]
            else:
                print(f"Warning: Standard Imagenet label {standard_imagenet_label} not found in the integer-to-string mapping.")
        self.labels = self.imagenet200_to_string_mapping

    def __getitem__(self, index: int, return_index: bool = False) -> tuple[Any, int] | tuple[Any, int, int]:
        """
        Args:
            index (int): Index
            return_index (bool): Whether to return the original index.

        Returns:
            tuple: (image, label) or (image, label, index) where image is the transformed image.
        """
        img_path, label = self.samples[index]

        img = decode_image(img_path, mode=ImageReadMode.RGB)

        if self.transform:
            img = self.transform(img)

        if return_index:
            return img, label, index
        else:
            return img, label

    def __len__(self) -> int:
        """
        Returns the total number of samples in the dataset split.
        """
        return len(self.samples)


