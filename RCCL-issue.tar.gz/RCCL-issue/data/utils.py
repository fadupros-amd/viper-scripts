import torch
from torch.utils.data import Dataset

class DatasetWithIndices(Dataset):
    """
    A dataset wrapper that returns the index along with each sample.
    
    This wrapper takes any PyTorch dataset and modifies its __getitem__ method
    to return a tuple of (sample, label, index) instead of just (sample, label).
    """
    def __init__(self, dataset):
        self.dataset = dataset
        
    def __getitem__(self, idx):
        img, label = self.dataset[idx]
        return img, label, idx
            
    def __len__(self):
        return len(self.dataset)