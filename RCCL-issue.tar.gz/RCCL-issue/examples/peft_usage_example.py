"""
Example of how to use HuggingFace PEFT adapters with the entire model.

This shows how to configure PEFT strategies for the ViT model through the experiment configuration.
PEFT is now applied at the model level, not individual layer level, which is cleaner and more standard.
"""

# Example configuration for using LoRA with the entire model
peft_lora_config = {
    "use_peft": True,
    "peft_config": {
        "strategy": "LoraConfig",
        "r": 8,                         # LoRA rank
        "lora_alpha": 16,               # LoRA alpha parameter
        "target_modules": ["linear"],   # Target module patterns (supports regex)
        "lora_dropout": 0.1,            # LoRA dropout
    }
}

# Example configuration for using AdaLoRA
peft_adalora_config = {
    "use_peft": True,
    "peft_config": {
        "strategy": "AdaLoraConfig",
        "r": 8,
        "lora_alpha": 16,
        "target_modules": ["to_qkv", "to_out", "linear1", "linear2"],  # Specific ViT layer names
        "lora_dropout": 0.1,
        "target_r": 4,            # Target rank for adaptive pruning
        "init_r": 12,             # Initial rank
    }
}

# Example configuration for targeting specific layers
peft_selective_config = {
    "use_peft": True,
    "peft_config": {
        "strategy": "LoraConfig",
        "r": 16,
        "lora_alpha": 32,
        "target_modules": [
            "transformer.*.to_qkv",     # All QKV projection layers
            "transformer.*.linear1",    # All first linear layers in FFN
            "classifier"                # Final classifier layer
        ],
        "lora_dropout": 0.05,
    }
}

# Example YAML configuration for experiments
yaml_example = """
model: "ViT"
use_peft: true
peft_config:
  strategy: "LoraConfig"
  r: 8
  lora_alpha: 16
  target_modules: 
    - "linear"           # Target all linear layers
    - "to_qkv"          # Target attention projection layers
    - "to_out"          # Target attention output layers
  lora_dropout: 0.1

# Other ViT configuration...
vit_patch_size: 16
vit_dim: 768
vit_depth: 12
vit_num_heads: 12
vit_mlp_dim: 3072
linear_layer: "BcosLinear"
b: 2
num_classes: 1000
"""

print("✅ PEFT integration with model-level application is ready!")
print("📝 Benefits of this approach:")
print("   - Standard HuggingFace PEFT usage pattern")
print("   - Full control over target_modules at model level")
print("   - Cleaner code without layer-level PEFT logic")
print("   - Better compatibility with PEFT library features")
print("🚀 Set use_peft=True and provide peft_config in your experiment configuration.")
