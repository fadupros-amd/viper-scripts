import warnings
import yaml
import torch
import os

import yaml
import torch
import os

class Experiment():
    def __init__(self, config: dict):
        """Initializes the Experiment with a configuration dictionary."""
        if not isinstance(config, dict):
            raise TypeError("config must be a dictionary")
        self.config = config
        # Consider calling this after initialization if needed,
        # or make it a read-only property accessing the config value.
        # self._process_num_workers()

    # 2. Class method to load from YAML paths (original __init__ logic)
    @classmethod
    def from_yaml_paths(cls, config_path: str, model_config_path: str, experiment_name: str):
        """Creates an Experiment instance by loading config from YAML files."""
        try:
            with open(config_path, "r") as f:
                main_config = yaml.safe_load(f)
            if main_config is None: main_config = {} # Handle empty file

            with open(model_config_path, "r") as f:
                model_configs = yaml.safe_load(f)
            if model_configs is None: model_configs = {} # Handle empty file

            model_config = model_configs.get(experiment_name, {}) # Use .get for safety
            if not model_config and experiment_name in model_configs:
                 # Handle case where key exists but value is None/empty
                 model_config = {}

            final_config = main_config.copy() # Start with main config
            final_config.update(model_config) # Merge model specific config
            final_config["experiment_name"] = experiment_name # Ensure name is set

            # Create and return an instance using the main __init__
            return cls(final_config)

        except FileNotFoundError as e:
            print(f"Error loading config: {e}")
            # Decide how to handle missing files: raise error, return None, etc.
            raise
        except KeyError as e:
            print(f"Error: Experiment name '{experiment_name}' not found in {model_config_path}")
            raise
        except Exception as e:
            print(f"An unexpected error occurred during config loading: {e}")
            raise


    # 3. Class method to load from a pre-existing config dictionary (your original intention)
    @classmethod
    def from_config_dict(cls, config: dict):
        """Creates an Experiment instance from a pre-existing config dictionary."""
        # Just create and return an instance using the main __init__
        return cls(config.copy()) # Pass a copy to avoid external modification issues

    # Optional: Method to process num_workers if needed after init
    def process_num_workers(self):
       """Processes the num_workers setting."""
       if "num_workers" in self.config:
            num_workers = self.config["num_workers"]
            if num_workers == "auto":
                try:
                    cpu_count = os.cpu_count()
                    if cpu_count is not None and cpu_count > 2:
                        self.config["num_workers"] = cpu_count - 2
                    elif cpu_count is not None and cpu_count <= 2:
                        self.config["num_workers"] = 1 # Use at least 1 worker
                    else:
                        self.config["num_workers"] = 2 # Default if cpu_count fails
                except NotImplementedError:
                    self.config["num_workers"] = 2 # Default if os.cpu_count() is not implemented
                print(f"Auto-detected num_workers: {self.config['num_workers']}")

    def override_arguments(self, **kwargs):
        '''
        Enhanced override that supports nested configs using dot notation.
        Examples:
        - peft_config.r=16
        - peft_config.target_modules=["to_qkv.linear"]
        - model.use_peft=True
        '''
        for key, val in kwargs.items():
            if val is not None:
                if '.' in key:
                    self._set_nested_value(key, val)
                else:
                    print(f"Value of argument {key} replaced with {val}")
                    self.config[key] = val
    
    def _set_nested_value(self, key_path: str, value):
        """Set nested dictionary value using dot notation."""
        keys = key_path.split('.')
        current = self.config
        
        # Navigate to the parent of the target key
        for key in keys[:-1]:
            if key not in current:
                current[key] = {}
            current = current[key]
        
        # Set the final value
        final_key = keys[-1]
        print(f"Value of nested argument {key_path} replaced with {value}")
        current[final_key] = self._parse_value(value)
    
    def _parse_value(self, value):
        """Parse string value to appropriate type."""
        if value is None:
            return None
        
        # Handle string representations of lists
        if isinstance(value, str):
            if value.startswith('[') and value.endswith(']'):
                try:
                    # Parse list strings like '["to_qkv.linear", "to_out.linear"]'
                    import ast
                    return ast.literal_eval(value)
                except:
                    return value
            
            # Handle booleans
            if value.lower() in ['true', 'false']:
                return value.lower() == 'true'
            
            # Handle numbers
            try:
                if '.' in value:
                    return float(value)
                return int(value)
            except ValueError:
                return value
        
        return value
    
    def get_nested_value(self, key_path: str):
        """Get nested value using dot notation."""
        keys = key_path.split('.')
        current = self.config
        
        for key in keys:
            if isinstance(current, dict) and key in current:
                current = current[key]
            else:
                return None
        
        return current

    @property
    def lr(self):
        # Add type checking/conversion for robustness
        try:
            return float(self.config["lr"])
        except KeyError:
            # Handle missing key - raise error, return default, return None?
            raise AttributeError("Learning rate 'lr' not found in config.")
        except (ValueError, TypeError):
            raise TypeError(f"Invalid type for 'lr': {self.config['lr']}")


    @property
    def weight_decay(self):
        return self.config.get('weight_decay', 0.0) # Provide a default if missing

    @property
    def num_workers(self):
        # Return the processed value. Might need adjustment
        # depending on when/if you call _process_num_workers
        return self.config.get('num_workers', 0) # Provide a default

    @property
    def num_gpus(self):
        # Default to 1 GPU for Ray training (typical SLURM setup)
        return self.config.get('num_gpus', 1)

    @property
    def compile(self):
        return self.config.get('compile', False) # Default False

    @property
    def precision(self):
        return self.config.get('precision', '32-true') # Default

    @property
    def batch_size(self):
        return self.config.get('batch_size', 1) # Default

    @property
    def pretrained_weights(self):
        return self.config.get('pretrained_weights', False) # Default
   
    @property
    def replace_classifier_by_pretrained(self):
        return self.config.get("replace_classifier_by_pretrained", True)

    @property
    def freeze_pretrained_weights(self):
        return self.config.get("freeze_pretrained_weights", False)

    @property
    def loss(self):
        return self.config.get('loss', 'CE') # Default

    @property
    def tags(self):
        return self.config.get("tags", [])

    @property
    def dataset(self) -> str:
        return self.config.get("dataset", "None") # May return None if missing

    @property
    def model(self):
        return self.config.get("model") # May return None if missing

    @property
    def experiment_name(self):
        return self.config.get("experiment_name") # May return None if missing

    @property
    def epochs(self):
        return self.config.get("epochs", 1) # Default

    @property
    def warmup_epochs(self):
        return self.config.get("warmup_epochs", 0) # Default

    @property
    def matmul_precision(self):
        return self.config.get("matmul_precision", 'high') # Default

    @property
    def cache_data(self):
        return self.config.get("cache_data", False) # Default

    @property
    def group(self):
        return self.config.get("group", None) # Default

    @property
    def seed(self):
        return self.config.get("seed", 42)
    
    @property
    def b_classifier(self):
        return self.config.get("b_classifier", 2)
    
    @property
    def b_adapter(self):
        return self.config.get("b_adapter", None)
    
    @property
    def adapter(self):
        return self.config.get("adapter", None)
    
    @property
    def insert_adapter_layers(self):
        return self.config.get("insert_adapter_layers", False)
    
    @property
    def add_initial_adapter(self):
        return self.config.get("add_initial_adapter", False)

    @property
    def efficient_bcos(self):
        return self.config.get("efficient_bcos", False)
    
    @property
    def block_class(self):
        return self.config.get("block_class", "bottleneck_relu")
    
    @property
    def b(self):
        return self.config.get("b", 1)
    
    @property
    def layergradcam(self):
        return self.config.get("layergradcam", None)
        
    @property
    def grid_pg_scale(self):
        return self.config.get("grid_pg_scale", 2)
    
    @property
    def grid_scale_confidence_threshold(self):
        return self.config.get("grid_scale_confidence_threshold", 0.99)
    
    @property
    def limit_val_batches(self):
        return self.config.get("limit_val_batches", 1.0)
    
    @property
    def limit_grid_samples(self):
        return self.config.get("limit_grid_samples", 500000)
    
    @property
    def enable_bottleneck_layers(self):
        return self.config.get("enable_bottleneck_layers", [1, 1, 1, 1, 1])
    
    @property
    def remove_adapter_skip_connections(self):
        return self.config.get("remove_adapter_skip_connections", False)
    
    @property
    def compile_mode(self):
        return self.config.get("compile_mode", "default")
    
    @property
    def persistent_workers(self):
        return self.config.get("persistent_workers", True)
    
    @property
    def pin_memory(self):
        return self.config.get("pin_memory", True)
    
    @property
    def compile_fullgraph(self):
        return self.config.get(f"compile_fullgraph", False)
    
    @property
    def convolution(self):
        return self.config.get(f"convolution", "BcosConv2d")
    
    @property
    def define_frozen_layers(self):
        if not self.freeze_pretrained_weights:
            warnings.warn(f"Layers were specified for freezing but \"freeze_pretrained_weights\" was set to \"False\". Layers will NOT BE FROZEN.")

        return self.config.get("define_frozen_layers", None)
    
    @property
    def overwrite_b_for_layer(self):
        return self.config.get("overwrite_b_for_layer", None)
    
    @property
    def limit_train_batches(self):
        return self.config.get("limit_train_batches", 1.0)  # Default to 100% of training data

    @property
    def number_of_visualization_samples(self):
        return self.config.get("number_of_visualization_samples", 5)  # Default to 5 samples for visualization
    
    @property
    def visualization_log_frequency(self):
        return self.config.get("visualization_log_frequency", 5)  # Default to log 5 times per training
    
    @property
    def conv_adapter_style(self):
        ret = self.config.get("conv_adapter_style", "parallel")
        assert(ret in ["parallel", "sequential"])
        return ret
    
    @property
    def conv_adapter_position(self):
        ret = self.config.get("conv_adapter_position", "residual")
        assert(ret in ["residual", "conv", "both"]) 
        return ret
    
    @property
    def conv_adapter_kernel_size(self):
        return self.config.get("conv_adapter_kernel_size", 3)
    
    @property
    def conv_adapter_factor(self):
        return self.config.get("conv_adapter_factor", 8)
    
    @property
    def conv_adapter_act_layer(self):
        return self.config.get("conv_adapter_act_layer", "relu")
    
    @property
    def conv_adapter_activate(self):
        return self.config.get("conv_adapter_activate", False)

    @property
    def standard_explanations_confidence_threshold(self):
        return self.config.get("standard_explanations_confidence_thresholds", 0.99)

    @property
    def use_explanation_metric_as_loss(self):
        return self.config.get("use_explanation_metric_as_loss", False)

    @property
    def explanation_metric_threshold(self):
        return self.config.get("explanation_metric_threshold", None)

    @property
    def data_path(self) -> None | str:
        return self.config.get("data_path", None)

    @property
    def num_classes(self):
        if self.dataset.lower() == "tinyimagenet".lower():
            return 200
        elif self.dataset.lower().startswith("FGVCAircraft".lower()):
            _, annotation_level = self.dataset.split("#") if "#" in self.dataset else "variant"
            if annotation_level == "variant":
                return 100
            elif annotation_level == "family":
                return 70
            elif annotation_level == "manufacturer":
                return 30
            else:
                raise ValueError(f"Unknown annotation level '{annotation_level}' for dataset {self.dataset}")
        elif self.dataset.lower() == "imagenet1k".lower():
            return 1000
        else:
            raise Exception(f"Dataset classes not yet defined for dataset {self.dataset}")

        #return self.config.get("num_classes", 200)

    @property
    def act_layer(self):
        return self.config.get("act_layer", "relu")

    @property
    def conv_adapter_b(self):
        return self.config.get("conv_adapter_b", 1)

    @property
    def norm_layer(self):
        return self.config.get("norm_layer", "BatchNormUncentered2d")
    
    @property
    def use_normalization(self):
        return self.config.get("use_normalization", False)
    
    #@property
    #def image_resolution(self):
    #    return self.config.get("image_resolution", 256)

    @property
    def concept_layer_factor(self):
        return self.config.get("concept_layer_factor", 2)

    @property
    def concept_layer_b(self):
        return self.config.get("concept_layer_b", 2)
    
    @property
    def concept_layer_use(self):
        return self.config.get("concept_layer_use", False)
    
    # @property
    # def set_pretrained_modules_to_eval(self):
    #     return self.config.get("set_pretrained_modules_to_eval", True)

    @property
    def set_pretrained_batchnorms_to_eval(self):
        return self.config.get("set_pretrained_batchnorms_to_eval", False)
    
    @property
    def vit_patch_size(self):
        """Returns the patch size for ViT models."""
        return self.config.get("vit_patch_size", 16)
    
    @property
    def vit_dim(self):
        """Returns the dimension for ViT models."""
        return self.config.get("vit_dim", 1536)
    
    @property
    def vit_depth(self):
        """Returns the depth for ViT models."""
        return self.config.get("vit_depth", 12)
    
    @property
    def vit_num_heads(self):
        """Returns the number of attention heads for ViT models."""
        return self.config.get("vit_num_heads", 12)
    
    @property
    def vit_mlp_dim(self):
        """Returns the MLP dimension for ViT models."""
        return self.config.get("vit_mlp_dim", 3072)
    
    @property
    def vit_conv_stem(self) -> None | list[int]:
        """Returns whether to use a convolutional stem for ViT models."""
        return self.config.get("vit_conv_stem", None)
    
    @property
    def vit_qkv_b(self):
        """Returns whether to use bias in QKV layers for ViT models."""
        return self.config.get("vit_qkv_b", 1)
    
    @property
    def attention_mode(self):
        """Returns the attention mode for ViT models."""
        return self.config.get("attention_mode", "default")
    
    @property
    def image_size(self):
        """Returns the image size for the model."""
        # Assuming image_size is defined in the config, otherwise return a default
        return self.config.get("image_size", 224)

    @property
    def dynamic_bias(self):
        """
        Returns whether to use dynamic bias layers.
        This is a placeholder property; actual implementation may vary.
        """
        return self.config.get("dynamic_bias", False)
    
    @property
    def dynamic_bias_b(self):
        """
        Returns the value of b for dynamic bias layers.
        """
        return self.config.get("dynamic_bias_b", 1)
    
    @property
    def conv_wise_adapter_mode(self):
        """
        Returns the mode for convolution-wise adapters.
        This is a placeholder property; actual implementation may vary.
        """
        return self.config.get("conv_wise_adapter_mode", "in_channel")

    @property
    def linear_layer(self):
        """
        Returns the linear layer type specified in the config.
        This is a placeholder property; actual implementation may vary.
        """
        return self.config.get("linear_layer", "BcosLinear")
    
    @property
    def use_lora(self):
        """
        Returns whether to use LoRA (Low-Rank Adaptation) in the model.
        This is a placeholder property; actual implementation may vary.
        """
        return self.config.get("use_lora", False)
    
    @property
    def lora_mode(self):
        """
        Returns whether to use DORA (Dynamic Low-Rank Adaptation) in the model.
        This is a placeholder property; actual implementation may vary.
        """
        return self.config.get("lora_mode", "lora")
    
    @property
    def modification_order(self):
        """
        Returns the order of modifications to apply to the model.
        This is a list of strings representing modification names.
        """
        return self.config.get("modification_order", ["lora"])

    @property
    def lora_rank(self):
        """
        Returns the LoRA factor used in the model.
        This is a placeholder property; actual implementation may vary.
        """
        return self.config.get("lora_rank", 16)
    
    @property
    def lora_alpha(self):
        """
        Returns the LoRA alpha value used in the model.
        This is a placeholder property; actual implementation may vary.
        """
        return self.config.get("lora_alpha", 16)
    
    @property
    def lora_b(self):
        """
        Returns the LoRA b value used in the model.
        This is a placeholder property; actual implementation may vary.
        """
        return self.config.get("lora_b", 1)
    
    @property
    def use_peft(self):
        """
        Returns whether to use HuggingFace PEFT (Parameter-Efficient Fine-Tuning) adapters.
        When True, PEFT adapters will be applied to linear layers based on peft_config.
        """
        return self.config.get("use_peft", False)
    
    @property
    def peft_config(self):
        """
        Returns the PEFT configuration dictionary.
        Should contain 'strategy' key (e.g., 'LoraConfig') and strategy-specific kwargs.
        Example: {"strategy": "LoraConfig", "r": 8, "lora_alpha": 16, "target_modules": ["linear"]}
        """
        return self.config.get("peft_config", None)
    
    @property
    def freeze_layer_norms(self):
        """
        Returns whether to freeze layer normalization layers.
        This is a placeholder property; actual implementation may vary.
        """
        return self.config.get("freeze_layer_norms", False)

    @property
    def freeze_patch_embeddings(self):
        """
        Returns whether to freeze path embeddings.
        This is a placeholder property; actual implementation may vary.
        """
        return self.config.get("freeze_patch_embeddings", False)

    @property
    def freeze_pretrained_batchnorms(self):
        """
        Returns whether to freeze batch normalization layers from pretrained weights.
        When True, batch norm parameters are frozen (requires_grad=False).
        This is separate from set_pretrained_batchnorms_to_eval which controls eval mode.
        """
        return self.config.get("freeze_pretrained_batchnorms", True)
    
    @property
    def use_gradient_checkpointing(self):
        """
        Returns whether to use gradient checkpointing.
        This is a placeholder property; actual implementation may vary.
        """
        return self.config.get("use_gradient_checkpointing", False)

    @property
    def skip_norm_division(self):
        """
        Returns whether to skip norm division in BcosLinear/BcosConv2d layers.
        This provides a norm-free approximation that may reduce memory usage.
        """
        return self.config.get("skip_norm_division", False)

    @property
    def power_trick(self):
        """
        Returns whether to use the power trick simplification in BcosLinear/BcosConv2d layers.
        This simplifies B-cos to sign(x·W) * |x·W|^B, making model conversion less disruptive.
        """
        return self.config.get("power_trick", False)
    
    @property
    def bcos_use_cosine_similarity(self):
        """
        Returns whether to use PyTorch's optimized cosine similarity in BcosLinear layers.
        This leverages torch.nn.functional.cosine_similarity for better performance.
        """
        return self.config.get("bcos_use_cosine_similarity", False)
    
    @property
    def lora_use_layer_b(self):
        """
        Returns whether to use the B value from the layer for LoRA or BcosLinear.
        This allows for dynamic adjustment of the B value based on the layer's configuration.
        """
        return self.config.get("lora_use_layer_b", False)
    
    @property
    def bcos_weight_normalization(self):
        """
        Returns whether to apply weight normalization in BcosLinear layers.
        This normalizes the output by the weight vector's norm, which can improve stability.
        """
        return self.config.get("bcos_weight_normalization", False)
    
    @property
    def lora_act_layer(self):
        """
        Returns the activation layer to use in LoRA layers.
        This allows for flexibility in choosing the activation function.
        """
        return self.config.get("lora_act_layer", None)
    
    @property
    def lora_depth(self):
        """
        Returns the depth of LoRA layers.
        This allows for multi-layer LoRA configurations.
        """
        return self.config.get("lora_depth", 0)
    
    @property
    def optimizer(self):
        """
        Returns the optimizer type specified in the config.
        This is a placeholder property; actual implementation may vary.
        """
        return self.config.get("optimizer", "AdamW")
    
    @property
    def momentum(self):
        """
        Returns the momentum value for the optimizer.
        This is a placeholder property; actual implementation may vary.
        """
        return self.config.get("momentum", 0.9)
    
    @property
    def use_sam(self):
        """
        Returns whether to use the SAM (Sharpness-Aware Minimization) optimizer.
        This is a placeholder property; actual implementation may vary.
        """
        return self.config.get("use_sam", False)
    
    @property
    def compile_dynamic(self):
        """
        Returns whether to use dynamic compilation.
        This is a placeholder property; actual implementation may vary.
        """
        return self.config.get("compile_dynamic", True)

    @property
    def lora_initialization_mode(self):
        """
        Returns the initialization mode for LoRA layers.
        This is a placeholder property; actual implementation may vary.
        """
        return self.config.get("lora_initialization_mode", "kaiming-uniform")

    @property
    def lora_use_input_norm(self):
        """
        Returns whether to use layer normalization in LoRA layers.
        This is a placeholder property; actual implementation may vary.
        """
        return self.config.get("lora_use_input_norm", False)
    
    @property
    def lora_use_neat(self):
        """
        Returns whether to use the NEAT (Nonlinear Parameter-efficient Adaptation of Pre-trained Models) mode in LoRA layers.
        """
        return self.config.get("lora_use_neat", False)

    @property
    def lora_target_modules(self):
        """
        Returns the target modules for LoRA layers.
        This is a placeholder property; actual implementation may vary.
        """
        return self.config.get("lora_target_modules", ["to_qkv", "to_out", "linear1", "linear2"])
    
    @property
    def vit_conv_stem_layer(self):
        """
        Returns the convolutional stem layer for ViT models.
        This is a placeholder property; actual implementation may vary.
        """
        return self.config.get("vit_conv_stem_layer", "BcosConv2d")
    
    @property
    def agc_clipping_value(self):
        """
        Returns the AGC (Adaptive Gradient Clipping) clipping value. This is used by ranger21
        This is a placeholder property; actual implementation may vary.
        """
        return self.config.get("agc_clipping_value", 0.01)
    
    @property
    def gradient_clip_val(self):
        """
        Returns the gradient clipping value.
        """
        return self.config.get("gradient_clip_val", None)

    @property
    def use_profiler(self):
        """
        Returns whether to use the profiler.
        This is a placeholder property; actual implementation may vary.
        """
        return self.config.get("use_profiler", False)
    
    @property
    def prefetch_factor(self):
        """
        Returns the prefetch factor for data loading.
        This is a placeholder property; actual implementation may vary.
        """
        return self.config.get("prefetch_factor", 1)
    
    @property
    def accumulate_grad_batches(self):
        """
        Returns the number of batches to accumulate gradients over.
        This is a placeholder property; actual implementation may vary.
        """
        return self.config.get("accumulate_grad_batches", 1)

    @property
    def model_precision(self):
        """
        Returns the precision to use for the model.
        This is a placeholder property; actual implementation may vary.
        """
        if self.precision == "bf16-true":
            return torch.bfloat16
        else: 
            return torch.float32  # Default to float32 if not bf16-true
        
    @property
    def vit_conv_stem_norm_layer(self):
        """
        Returns the normalization layer to use in the convolutional stem of ViT models.
        This is a placeholder property; actual implementation may vary.
        """
        return self.config.get("vit_conv_stem_norm_layer", "BatchNormUncentered2d")
    
    
    def to_wandb_config(self):
        """Collects experiment configuration from properties for wandb logging."""
        config_dict = {
            "lr": self.lr,
            "weight_decay": self.weight_decay,
            "num_workers": self.num_workers,
            "num_gpus": self.num_gpus,  # Add num_gpus to wandb config
            "compile": self.compile,
            "precision": self.precision,
            "batch_size": self.batch_size,
            "pretrained_weights": self.pretrained_weights,
            "freeze_pretrained_weights": self.freeze_pretrained_weights,
            "loss": self.loss,
            "tags": self.tags,
            "dataset": self.dataset,
            "model": self.model,
            "experiment_name": self.experiment_name,
            "epochs": self.epochs,
            "warmup_epochs": self.warmup_epochs,
            "matmul_precision": self.matmul_precision,
            "cache_data": self.cache_data,
            "group": self.group,
            "seed": self.seed,
            "b_classifier": self.b_classifier,
            "b_adapter": self.b_adapter,
            "adapter": self.adapter,
            "insert_adapter_layers": self.insert_adapter_layers,
            "add_initial_adapter": self.add_initial_adapter,
            "efficient_bcos": self.efficient_bcos,
            "block_class": self.block_class,
            "b": self.b,
            "layergradcam": self.layergradcam,
            "grid_pg_scale": self.grid_pg_scale,
            "grid_scale_confidence_threshold": self.grid_scale_confidence_threshold,
            "standard_explanations_confidence_threshold": self.standard_explanations_confidence_threshold,
            "limit_val_batches": self.limit_val_batches,
            "limit_grid_samples": self.limit_grid_samples,
            "enable_bottleneck_layers": self.enable_bottleneck_layers,
            "remove_adapter_skip_connections": self.remove_adapter_skip_connections,
            "compile_mode": self.compile_mode,
            "pin_memory": self.pin_memory,
            "persistent_workers": self.persistent_workers,
            "compile_fullgraph": self.compile_fullgraph,
            "convolution": self.convolution,
            "define_frozen_layers": self.define_frozen_layers,
            "overwrite_b_for_layer": self.overwrite_b_for_layer,
            "limit_train_batches": self.limit_train_batches,
            "number_of_visualization_samples": self.number_of_visualization_samples,
            "visualization_log_frequency": self.visualization_log_frequency,
            "conv_adapter_style": self.conv_adapter_style,
            "conv_adapter_position": self.conv_adapter_position,
            "conv_adapter_factor": self.conv_adapter_factor,
            "conv_adapter_act_layer": self.conv_adapter_act_layer,
            "conv_adapter_kernel_size": self.conv_adapter_kernel_size,
            "conv_adapter_activate": self.conv_adapter_activate,
            "explanation_metric_threshold": self.explanation_metric_threshold,
            "use_explanation_metric_as_loss": self.use_explanation_metric_as_loss,
            "data_path": self.data_path,
            "num_classes": self.num_classes,
            "act_layer": self.act_layer,
            "replace_classifier_by_pretrained": self.replace_classifier_by_pretrained,
            "conv_adapter_b": self.conv_adapter_b,
            "norm_layer": self.norm_layer,
            "use_normalization": self.use_normalization,
            #"image_resolution": self.image_resolution,
            "concept_layer_factor": self.concept_layer_factor,
            "concept_layer_b": self.concept_layer_b,
            "concept_layer_use": self.concept_layer_use,
            "set_pretrained_batchnorms_to_eval": self.set_pretrained_batchnorms_to_eval,
            "vit_patch_size": self.vit_patch_size,
            "vit_dim": self.vit_dim,
            "vit_depth": self.vit_depth,
            "vit_num_heads": self.vit_num_heads,
            "vit_mlp_dim": self.vit_mlp_dim,
            "vit_conv_stem": self.vit_conv_stem,
            "image_size": self.image_size,
            "dynamic_bias": self.dynamic_bias,
            "dynamic_bias_b": self.dynamic_bias_b,
            "conv_wise_adapter_mode": self.conv_wise_adapter_mode,
            "linear_layer": self.linear_layer,
            "use_lora": self.use_lora,
            "lora_mode": self.lora_mode,
            "modification_order": self.modification_order,
            "lora_rank": self.lora_rank,
            "vit_qkv_b": self.vit_qkv_b,
            "attention_mode": self.attention_mode,
            "freeze_layer_norms": self.freeze_layer_norms,
            "freeze_patch_embeddings": self.freeze_patch_embeddings,
            "freeze_pretrained_batchnorms": self.freeze_pretrained_batchnorms,
            "use_gradient_checkpointing": self.use_gradient_checkpointing,
            "skip_norm_division": self.skip_norm_division,
            "power_trick": self.power_trick,
            "lora_use_layer_b": self.lora_use_layer_b,
            "bcos_use_cosine_similarity": self.bcos_use_cosine_similarity,
            "bcos_weight_normalization": self.bcos_weight_normalization,
            "lora_b": self.lora_b,
            "lora_act_layer": self.lora_act_layer,
            "lora_alpha": self.lora_alpha,
            "lora_depth": self.lora_depth,
            "optimizer": self.optimizer,
            "momentum": self.momentum,
            "use_sam": self.use_sam,
            "compile_dynamic": self.compile_dynamic,
            "lora_use_input_norm": self.lora_use_input_norm,
            "lora_initialization_mode": self.lora_initialization_mode,
            "lora_use_neat": self.lora_use_neat,
            "lora_target_modules": self.lora_target_modules,
            "use_peft": self.use_peft,
            "peft_config": self.peft_config,
            "vit_conv_stem_layer": self.vit_conv_stem_layer,
            "gradient_clip_val": self.gradient_clip_val,
            "agc_clipping_value": self.agc_clipping_value,
            "use_profiler": self.use_profiler,
            "prefetch_factor": self.prefetch_factor,
            "accumulate_grad_batches": self.accumulate_grad_batches,
            "vit_conv_stem_norm_layer": self.vit_conv_stem_norm_layer,

        }
        return config_dict
