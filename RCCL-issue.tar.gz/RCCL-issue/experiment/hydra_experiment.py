import warnings
import yaml
from hydra import compose, initialize
from hydra.core.config_store import ConfigStore
from omegaconf import DictConfig, OmegaConf
import hydra
from dataclasses import dataclass, field
from typing import Optional, List, Any, Dict

@dataclass
class PeftConfig:
    strategy: str = "LoraConfig"
    r: int = 8
    lora_alpha: int = 8
    target_modules: Optional[List[str]] = None
    modules_to_save: Optional[List[str]] = None
    use_dora: bool = False
    lora_dropout: Optional[float] = None
    init_lora_weights: Optional[str] = None

@dataclass
class ExperimentConfig:
    # Basic config
    experiment_name: str = "default"
    model: Optional[str] = None
    dataset: str = "ImageNet"
    
    # Training parameters
    epochs: int = 100
    warmup_epochs: int = 0
    batch_size: int = 32
    lr: float = 1e-3
    weight_decay: float = 0.001
    optimizer: str = "AdamW"
    momentum: float = 0.9
    use_sam: bool = False
    
    # Model configuration
    pretrained: bool = False
    pretrained_weights: Optional[str] = None
    loss: str = "CE"
    freeze_pretrained_weights: bool = False
    replace_classifier_by_pretrained: bool = True
    
    # Technical settings
    precision: str = "32-true"
    matmul_precision: str = "high"
    compile: bool = False
    compile_mode: str = "default"
    compile_fullgraph: bool = False
    compile_dynamic: bool = True
    num_workers: int = 0
    persistent_workers: bool = True
    pin_memory: bool = True
    cache_data: bool = False
    seed: int = 42
    
    # B-cos specific
    b: int = 1
    b_classifier: int = 2
    b_adapter: Optional[int] = None
    efficient_bcos: bool = False
    convolution: str = "BcosConv2d"
    linear_layer: str = "BcosLinear"
    norm_layer: str = "BatchNormUncentered2d"
    act_layer: str = "relu"
    use_normalization: bool = False
    
    # Adapter configuration
    adapter: Optional[str] = None
    block_class: str = "bottleneck_relu"
    insert_adapter_layers: bool = False
    add_initial_adapter: bool = False
    enable_bottleneck_layers: List[int] = field(default_factory=lambda: [1, 1, 1, 1, 1])
    remove_adapter_skip_connections: bool = False
    
    # Conv adapter settings
    conv_adapter_style: str = "parallel"
    conv_adapter_position: str = "residual"
    conv_adapter_factor: int = 8
    conv_adapter_kernel_size: int = 3
    conv_adapter_act_layer: str = "relu"
    conv_adapter_activate: bool = False
    conv_adapter_b: int = 1
    conv_wise_adapter_mode: str = "in_channel"
    
    # ViT configuration
    vit_patch_size: int = 16
    vit_dim: int = 1536
    vit_depth: int = 12
    vit_num_heads: int = 12
    vit_mlp_dim: int = 3072
    vit_conv_stem: Optional[List[int]] = None
    vit_qkv_b: int = 1
    attention_mode: str = "default"
    image_size: int = 224
    vit_conv_stem_layer: str = "BcosConv2d"
    
    # LoRA configuration
    use_lora: bool = False
    lora_mode: str = "lora"
    lora_rank: int = 16
    lora_alpha: int = 16
    lora_b: int = 1
    lora_act_layer: Optional[str] = None
    lora_depth: int = 0
    lora_initialization_mode: str = "kaiming-uniform"
    lora_use_input_norm: bool = False
    lora_use_neat: bool = False
    lora_use_layer_b: bool = False
    lora_target_modules: List[str] = field(default_factory=lambda: ["to_qkv", "to_out", "linear1", "linear2"])
    
    # PEFT configuration
    use_peft: bool = False
    peft_config: Optional[PeftConfig] = None
    
    # Advanced features
    skip_norm_division: bool = False
    power_trick: bool = False
    bcos_use_cosine_similarity: bool = False
    bcos_weight_normalization: bool = False
    dynamic_bias: bool = False
    dynamic_bias_b: int = 1
    use_gradient_checkpointing: bool = False
    
    # Freezing options
    freeze_layer_norms: bool = False
    freeze_patch_embeddings: bool = False
    freeze_pretrained_batchnorms: bool = True
    set_pretrained_batchnorms_to_eval: bool = False
    define_frozen_layers: Optional[List[str]] = None
    overwrite_b_for_layer: Optional[Dict[str, int]] = None
    
    # Concept layer
    concept_layer_factor: int = 2
    concept_layer_b: int = 2
    concept_layer_use: bool = False
    
    # Training limits and logging
    limit_train_batches: float = 1.0
    limit_val_batches: float = 1.0
    limit_grid_samples: int = 500000
    number_of_visualization_samples: int = 5
    visualization_log_frequency: int = 5
    
    # Grid and explanations
    grid_pg_scale: int = 2
    grid_scale_confidence_threshold: float = 0.99
    standard_explanations_confidence_threshold: float = 0.99
    explanation_metric_threshold: Optional[float] = None
    use_explanation_metric_as_loss: bool = False
    
    # Misc
    group: Optional[str] = None
    tags: List[str] = field(default_factory=list)
    data_path: Optional[str] = None
    layergradcam: Optional[Dict] = None
    modification_order: List[str] = field(default_factory=lambda: ["lora"])

# Register configurations
cs = ConfigStore.instance()
cs.store(name="base_config", node=ExperimentConfig)
cs.store(group="peft", name="lora", node=PeftConfig)
cs.store(group="peft", name="dora", node=PeftConfig(use_dora=True))

class HydraExperiment:
    def __init__(self, cfg: DictConfig):
        self.config = cfg
    
    @classmethod
    def from_hydra_config(cls, config_path: str = "configs", config_name: str = "config"):
        """Load configuration using Hydra"""
        with initialize(config_path=config_path, version_base=None):
            cfg = compose(config_name=config_name)
            return cls(cfg)
    
    @classmethod
    def from_yaml_paths(cls, config_path: str, model_config_path: str, experiment_name: str):
        """Load configuration from YAML files and convert to Hydra format"""
        try:
            with open(config_path, "r") as f:
                main_config = yaml.safe_load(f)
            if main_config is None: 
                main_config = {}

            with open(model_config_path, "r") as f:
                model_configs = yaml.safe_load(f)
            if model_configs is None: 
                model_configs = {}

            model_config = model_configs.get(experiment_name, {})
            
            final_config = main_config.copy()
            final_config.update(model_config)
            final_config["experiment_name"] = experiment_name
            
            # Convert to OmegaConf
            omega_config = OmegaConf.create(final_config)
            
            return cls(omega_config)

        except FileNotFoundError as e:
            print(f"Error loading config: {e}")
            raise
        except KeyError as e:
            print(f"Error: Experiment name '{experiment_name}' not found in {model_config_path}")
            raise
    
    def override_arguments(self, **kwargs):
        """Override arguments with dot notation support via OmegaConf"""
        for key, val in kwargs.items():
            if val is not None:
                try:
                    parsed_val = self._parse_value(val)
                    OmegaConf.update(self.config, key, parsed_val)
                    print(f"Value of argument {key} replaced with {parsed_val}")
                except Exception as e:
                    print(f"Error setting {key}={val}: {e}")
    
    def _parse_value(self, value):
        """Parse string value to appropriate type"""
        if value is None:
            return None
        
        if isinstance(value, str):
            # Handle YAML-like strings
            try:
                import ast
                return ast.literal_eval(value)
            except:
                if value.lower() in ['true', 'false']:
                    return value.lower() == 'true'
                try:
                    if '.' in value:
                        return float(value)
                    return int(value)
                except ValueError:
                    return value
        
        return value
    
    def get_nested_value(self, key_path: str):
        """Get nested configuration value using dot notation"""
        return OmegaConf.select(self.config, key_path)
    
    def set_nested_value(self, key_path: str, value: Any):
        """Set nested configuration value using dot notation"""
        OmegaConf.update(self.config, key_path, value)
    
    # All the property methods from your original experiment class
    @property
    def lr(self):
        try:
            return float(self.config.get("lr", 1e-3))
        except (ValueError, TypeError):
            raise TypeError(f"Invalid type for 'lr': {self.config.get('lr')}")

    @property
    def weight_decay(self):
        return self.config.get('weight_decay', 0.0)

    @property
    def num_workers(self):
        return self.config.get('num_workers', 0)

    @property
    def compile(self):
        return self.config.get('compile', False)

    @property
    def precision(self):
        return self.config.get('precision', '32-true')

    @property
    def batch_size(self):
        return self.config.get('batch_size', 1)

    @property
    def pretrained_weights(self):
        return self.config.get('pretrained_weights', False)
   
    @property
    def replace_classifier_by_pretrained(self):
        return self.config.get("replace_classifier_by_pretrained", True)

    @property
    def freeze_pretrained_weights(self):
        return self.config.get("freeze_pretrained_weights", False)

    @property
    def loss(self):
        return self.config.get('loss', 'CE')

    @property
    def tags(self):
        return self.config.get("tags", [])

    @property
    def dataset(self) -> str:
        return self.config.get("dataset", "None")

    @property
    def model(self):
        return self.config.get("model")

    @property
    def experiment_name(self):
        return self.config.get("experiment_name")

    @property
    def epochs(self):
        return self.config.get("epochs", 1)

    @property
    def warmup_epochs(self):
        return self.config.get("warmup_epochs", 0)

    @property
    def matmul_precision(self):
        return self.config.get("matmul_precision", 'high')

    @property
    def cache_data(self):
        return self.config.get("cache_data", False)

    @property
    def group(self):
        return self.config.get("group", None)

    @property
    def seed(self):
        return self.config.get("seed", 42)
    
    @property
    def b_classifier(self):
        return self.config.get("b_classifier", 2)
    
    @property
    def b_adapter(self):
        return self.config.get("b_adapter", None)
    
    @property
    def adapter(self):
        return self.config.get("adapter", None)
    
    @property
    def insert_adapter_layers(self):
        return self.config.get("insert_adapter_layers", False)
    
    @property
    def add_initial_adapter(self):
        return self.config.get("add_initial_adapter", False)

    @property
    def efficient_bcos(self):
        return self.config.get("efficient_bcos", False)
    
    @property
    def block_class(self):
        return self.config.get("block_class", "bottleneck_relu")
    
    @property
    def b(self):
        return self.config.get("b", 1)
    
    @property
    def layergradcam(self):
        return self.config.get("layergradcam", None)
        
    @property
    def grid_pg_scale(self):
        return self.config.get("grid_pg_scale", 2)
    
    @property
    def grid_scale_confidence_threshold(self):
        return self.config.get("grid_scale_confidence_threshold", 0.99)
    
    @property
    def limit_val_batches(self):
        return self.config.get("limit_val_batches", 1.0)
    
    @property
    def limit_grid_samples(self):
        return self.config.get("limit_grid_samples", 500000)
    
    @property
    def enable_bottleneck_layers(self):
        return self.config.get("enable_bottleneck_layers", [1, 1, 1, 1, 1])
    
    @property
    def remove_adapter_skip_connections(self):
        return self.config.get("remove_adapter_skip_connections", False)
    
    @property
    def compile_mode(self):
        return self.config.get("compile_mode", "default")
    
    @property
    def persistent_workers(self):
        return self.config.get("persistent_workers", True)
    
    @property
    def pin_memory(self):
        return self.config.get("pin_memory", True)
    
    @property
    def compile_fullgraph(self):
        return self.config.get(f"compile_fullgraph", False)
    
    @property
    def convolution(self):
        return self.config.get(f"convolution", "BcosConv2d")
    
    @property
    def define_frozen_layers(self):
        if not self.freeze_pretrained_weights:
            warnings.warn(f"Layers were specified for freezing but \"freeze_pretrained_weights\" was set to \"False\". Layers will NOT BE FROZEN.")
        return self.config.get("define_frozen_layers", None)
    
    @property
    def overwrite_b_for_layer(self):
        return self.config.get("overwrite_b_for_layer", None)
    
    @property
    def limit_train_batches(self):
        return self.config.get("limit_train_batches", 1.0)

    @property
    def number_of_visualization_samples(self):
        return self.config.get("number_of_visualization_samples", 5)
    
    @property
    def visualization_log_frequency(self):
        return self.config.get("visualization_log_frequency", 5)
    
    @property
    def conv_adapter_style(self):
        ret = self.config.get("conv_adapter_style", "parallel")
        assert(ret in ["parallel", "sequential"])
        return ret
    
    @property
    def conv_adapter_position(self):
        ret = self.config.get("conv_adapter_position", "residual")
        assert(ret in ["residual", "conv", "both"]) 
        return ret
    
    @property
    def conv_adapter_kernel_size(self):
        return self.config.get("conv_adapter_kernel_size", 3)
    
    @property
    def conv_adapter_factor(self):
        return self.config.get("conv_adapter_factor", 8)
    
    @property
    def conv_adapter_act_layer(self):
        return self.config.get("conv_adapter_act_layer", "relu")
    
    @property
    def conv_adapter_activate(self):
        return self.config.get("conv_adapter_activate", False)

    @property
    def standard_explanations_confidence_threshold(self):
        return self.config.get("standard_explanations_confidence_thresholds", 0.99)

    @property
    def use_explanation_metric_as_loss(self):
        return self.config.get("use_explanation_metric_as_loss", False)

    @property
    def explanation_metric_threshold(self):
        return self.config.get("explanation_metric_threshold", None)

    @property
    def data_path(self) -> None | str:
        return self.config.get("data_path", None)

    @property
    def num_classes(self):
        if self.dataset.lower() == "tinyimagenet".lower():
            return 200
        elif self.dataset.lower().startswith("FGVCAircraft".lower()):
            _, annotation_level = self.dataset.split("#") if "#" in self.dataset else ("", "variant")
            if annotation_level == "variant":
                return 100
            elif annotation_level == "family":
                return 70
            elif annotation_level == "manufacturer":
                return 30
            else:
                raise ValueError(f"Unknown annotation level '{annotation_level}' for dataset {self.dataset}")
        else:
            return 1000  # Default ImageNet classes

    @property
    def act_layer(self):
        return self.config.get("act_layer", "relu")

    @property
    def conv_adapter_b(self):
        return self.config.get("conv_adapter_b", 1)

    @property
    def norm_layer(self):
        return self.config.get("norm_layer", "BatchNormUncentered2d")
    
    @property
    def use_normalization(self):
        return self.config.get("use_normalization", False)

    @property
    def concept_layer_factor(self):
        return self.config.get("concept_layer_factor", 2)

    @property
    def concept_layer_b(self):
        return self.config.get("concept_layer_b", 2)
    
    @property
    def concept_layer_use(self):
        return self.config.get("concept_layer_use", False)

    @property
    def set_pretrained_batchnorms_to_eval(self):
        return self.config.get("set_pretrained_batchnorms_to_eval", False)
    
    @property
    def vit_patch_size(self):
        return self.config.get("vit_patch_size", 16)
    
    @property
    def vit_dim(self):
        return self.config.get("vit_dim", 1536)
    
    @property
    def vit_depth(self):
        return self.config.get("vit_depth", 12)
    
    @property
    def vit_num_heads(self):
        return self.config.get("vit_num_heads", 12)
    
    @property
    def vit_mlp_dim(self):
        return self.config.get("vit_mlp_dim", 3072)
    
    @property
    def vit_conv_stem(self) -> None | list[int]:
        return self.config.get("vit_conv_stem", None)
    
    @property
    def vit_qkv_b(self):
        return self.config.get("vit_qkv_b", 1)
    
    @property
    def attention_mode(self):
        return self.config.get("attention_mode", "default")
    
    @property
    def image_size(self):
        return self.config.get("image_size", 224)

    @property
    def dynamic_bias(self):
        return self.config.get("dynamic_bias", False)
    
    @property
    def dynamic_bias_b(self):
        return self.config.get("dynamic_bias_b", 1)
    
    @property
    def conv_wise_adapter_mode(self):
        return self.config.get("conv_wise_adapter_mode", "in_channel")

    @property
    def linear_layer(self):
        return self.config.get("linear_layer", "BcosLinear")
    
    @property
    def use_lora(self):
        return self.config.get("use_lora", False)
    
    @property
    def lora_mode(self):
        return self.config.get("lora_mode", "lora")
    
    @property
    def modification_order(self):
        return self.config.get("modification_order", ["lora"])

    @property
    def lora_rank(self):
        return self.config.get("lora_rank", 16)
    
    @property
    def lora_alpha(self):
        return self.config.get("lora_alpha", 16)
    
    @property
    def lora_b(self):
        return self.config.get("lora_b", 1)
    
    @property
    def use_peft(self):
        return self.config.get("use_peft", False)
    
    @property
    def peft_config(self):
        return self.config.get("peft_config", None)
    
    @property
    def freeze_layer_norms(self):
        return self.config.get("freeze_layer_norms", False)

    @property
    def freeze_patch_embeddings(self):
        return self.config.get("freeze_patch_embeddings", False)

    @property
    def freeze_pretrained_batchnorms(self):
        return self.config.get("freeze_pretrained_batchnorms", True)
    
    @property
    def use_gradient_checkpointing(self):
        return self.config.get("use_gradient_checkpointing", False)

    @property
    def skip_norm_division(self):
        return self.config.get("skip_norm_division", False)

    @property
    def power_trick(self):
        return self.config.get("power_trick", False)
    
    @property
    def bcos_use_cosine_similarity(self):
        return self.config.get("bcos_use_cosine_similarity", False)
    
    @property
    def lora_use_layer_b(self):
        return self.config.get("lora_use_layer_b", False)
    
    @property
    def bcos_weight_normalization(self):
        return self.config.get("bcos_weight_normalization", False)
    
    @property
    def lora_act_layer(self):
        return self.config.get("lora_act_layer", None)
    
    @property
    def lora_depth(self):
        return self.config.get("lora_depth", 0)
    
    @property
    def optimizer(self):
        return self.config.get("optimizer", "AdamW")
    
    @property
    def momentum(self):
        return self.config.get("momentum", 0.9)
    
    @property
    def use_sam(self):
        return self.config.get("use_sam", False)
    
    @property
    def compile_dynamic(self):
        return self.config.get("compile_dynamic", True)

    @property
    def lora_initialization_mode(self):
        return self.config.get("lora_initialization_mode", "kaiming-uniform")

    @property
    def lora_use_input_norm(self):
        return self.config.get("lora_use_input_norm", False)
    
    @property
    def lora_use_neat(self):
        return self.config.get("lora_use_neat", False)

    @property
    def lora_target_modules(self):
        return self.config.get("lora_target_modules", ["to_qkv", "to_out", "linear1", "linear2"])
    
    @property
    def vit_conv_stem_layer(self):
        return self.config.get("vit_conv_stem_layer", "BcosConv2d")

    def to_wandb_config(self):
        """Convert to wandb config dict - same as original"""
        # Use OmegaConf to convert to dict, resolving all interpolations
        return OmegaConf.to_container(self.config, resolve=True)

# Example usage with command line:
# python train.py peft_config.r=16 peft_config.lora_alpha=32
