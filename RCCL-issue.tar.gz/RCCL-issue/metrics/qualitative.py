import torch
from torch import add, nn
import torchmetrics
from torchmetrics import Metric
from torch import Tensor
from typing import Optional, Union, Callable, Dict, Any
from utils.utils import add_batch_if_missing

class ContributionMetric(Metric):
    """
    Base class for contribution metrics.
    
    This class serves as a base for implementing various contribution metrics
    that can be used to evaluate the performance of models.
    """
    
    def __init__(self, threshold: int | None = None, **kwargs) -> None:
        super().__init__(**kwargs)
        self.threshold: int | None = threshold
        self.add_state("score", default=torch.tensor(0.0), dist_reduce_fx="sum")
        self.add_state("total_samples", default=torch.tensor(0.0), dist_reduce_fx="sum")
        self.cos = torch.nn.CosineSimilarity()


    def update(self, original_image:Tensor, explanation: Tensor, contribution_map: Tensor) -> None:
        assert(isinstance(original_image, Tensor))
        assert(isinstance(explanation, Tensor))
        assert(isinstance(contribution_map, Tensor))
        # add batch dimensions if missing
        original_image = add_batch_if_missing(original_image)
        explanation = add_batch_if_missing(explanation)
        contribution_map = add_batch_if_missing(contribution_map)

        # Check threshold and compute mask
        denominator = torch.max(contribution_map) + 1e-6
        mask: Tensor = (contribution_map - torch.min(contribution_map)) * torch.reciprocal(denominator)
        if self.threshold is not  None:
            threshold_tensor: Tensor = torch.tensor(self.threshold, dtype=mask.dtype, device=self.device)
            mask: Tensor = mask > threshold_tensor
            #print(f"Using threshold value of {self.threshold}") 
        
        # Permute input data (different order of dimensions)
        #mask = mask.permute(0, 2, 3, 1)
        original_image = original_image.permute(0, 2, 3, 1)
        explanation = explanation[:, :, :, :3]

        
    #     print(f"Mask has shape {mask.shape}")
    #    # print(f"Mask has values {mask}")
    #     print(f"Orig image has shape {original_image.shape}")
    #     print(f"Explanation has shape {explanation.shape}")
    #     print(f"Contribution map has shape {contribution_map.shape}")
        if mask.shape[1] == 1:
            mask = mask.permute(0, 2, 3, 1)
        filtered_image: Tensor = original_image * mask
        filtered_explanation: Tensor= explanation * mask
        
        #print(f"ContributionMap has values {contribution_map}")
        #print(f"Mask has values {mask}")
        #print(f"filtered_image has values {filtered_image}")
        #print(f"filtered_explanation has values {filtered_explanation}")
       
        # print(f"Mask non-zero values: {mask.count_nonzero()} of total values {mask.numel()}")

        flattened_filtered_image: Tensor = filtered_image.flatten(start_dim=1)
        flattened_filtered_explanation: Tensor=filtered_explanation.flatten(start_dim=1)
        # print(f"Filtered image non-zero values: {flattened_filtered_image.count_nonzero()} of total values {flattened_filtered_image.numel()}")
        # print(f"Filtered explanation non-zero values: {flattened_filtered_explanation.count_nonzero()} of total values {flattened_filtered_explanation.numel()}")
        
        score: Tensor = self.cos(flattened_filtered_image, flattened_filtered_explanation)
        #print(f"Score has shape {score.shape} and value {score}")
        #print(f"self.core has shape {self.score.shape} and value {self.score}")
        self.score += torch.sum(score)

    def compute(self) -> Tensor:
        if self.total_samples == 0:
            return torch.tensor(0.0, device=self.device)
        return self.score * torch.reciprocal(self.total_samples.float())


