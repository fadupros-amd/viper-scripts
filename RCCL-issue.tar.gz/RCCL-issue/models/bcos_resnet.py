from functools import partial
import math
from typing import Any, Callable, List, Optional, Type, Union
from utils.explanations import BcosUtilMixin
from modules.adapters.conv_adapter import ConvAdapter, DynamicBias
#from models.utils import BcosifierMixin

import torch
from torch import nn
from bcos.models.resnet import LogitLayer, BasicBlock#, BcosConv2d
from modules.bcos_conv import BcosConv2d
from bcos.modules import NoBias, norms
from modules.norms.batchnorm_uncentered import BatchNormUncentered2d
from torchvision.ops import StochasticDepth

from modules.bcos_conv import BcosConv2d_unnormed
from modules.blocks import Bottleneck, BottleneckReLU, AdapterBottleneck, conv1x1, conv3x3

from utils.norms import DynamicTanh

from modules.concept_layer import ConceptLayer
from modules.legacy.defaults import DEFAULT_ACT_LAYER, DEFAULT_CONV_LAYER, DEFAULT_CONV_LAYER_ADAPTER, DEFAULT_NORM_LAYER
from models.utils import LayerBGetter, get_act_layer, get_bottleneck, get_conv, get_norm
    

    
class BcosResnet50_bottleneck(BcosUtilMixin, nn.Module):
    def __init__(
        self,
        block: Type[Bottleneck],
        layers: List[int],
        num_classes: int = 1000,
        in_chans: int = 6,
        zero_init_residual: bool = False,
        groups: int = 1,
        width_per_group: int = 64,
        replace_stride_with_dilation: Optional[List[bool]] = None,
        norm_layer: Optional[Callable[..., nn.Module]] = DEFAULT_NORM_LAYER,
        conv_layer: Callable[..., nn.Module] = DEFAULT_CONV_LAYER,
        classification_conv_block: Callable[..., nn.Module] = DEFAULT_CONV_LAYER,
        adapter_block = Bottleneck,
        insert_adapter_layers: bool = False,
        add_initial_adapter: bool = False,
        act_layer: Callable[..., nn.Module] = None,
        b_bottleneck = 2,
        b_classifier = 2,
        b = 1,
        efficient_bcos = False,
        inplanes: int = 64,
        small_inputs: bool = False,
        stochastic_depth_prob: float = 0.0,
        logit_bias: Optional[float] = None,
        logit_temperature: Optional[float] = None,
        enable_bottleneck_layers = [1, 1, 1, 1],
        remove_adapter_skip_connections = False,
        overwrite_b_for_layer: Union[None, dict] = None,
        conv_adapter_style: str = "parallel",
        conv_adapter_pos: str = "residual",
        conv_adapter_kernel_size: int = 3,
        conv_adapter_act_layer: Callable[..., nn.Module] = DEFAULT_ACT_LAYER,
        conv_adapter_factor: int = 8,
        conv_adapter_b: int = 1,
        concept_layer_factor: int = 2,
        concept_layer_b: int = 2,
        concept_layer_use: bool = False,
        dynamic_bias: bool = False,
        dynamic_bias_b: int = 1,
        **kwargs: Any,  # ignore rest
    ):
        super().__init__()

        self.layer_b_getter = LayerBGetter(overwrite_b_for_layer=overwrite_b_for_layer, default_layer_b=b)

        if kwargs:
            print("The following args passed to model will be ignored", kwargs)

        if norm_layer is None:
            norm_layer = nn.Identity
        self._norm_layer = norm_layer
        self._conv_layer = conv_layer
        self._act_layer = act_layer
        self.add_initial_adapter = add_initial_adapter
        self.efficient_bcos = efficient_bcos
        self.enable_bottleneck_layers = enable_bottleneck_layers
        self.remove_adapter_skip_connections = remove_adapter_skip_connections

        self.inplanes = inplanes
        self.dilation = 1
        self.dynamic_bias = dynamic_bias
        self.dynamic_bias_b = dynamic_bias_b
        
        n = len(layers)  # number of stages
        if replace_stride_with_dilation is None:
            # each element in the tuple indicates if we should replace
            # the 2x2 stride with a dilated convolution instead
            replace_stride_with_dilation = [False] * (n - 1)
        if len(replace_stride_with_dilation) != n - 1:
            raise ValueError(
                "replace_stride_with_dilation should be None "
                f"or a {n - 1}-element tuple, got {replace_stride_with_dilation}"
            )
        self.groups = groups
        self.base_width = width_per_group

        if self.add_initial_adapter:
            self.initial_adapter = adapter_block(
                    inplanes=in_chans,
                    planes=in_chans,
                    b = b_bottleneck,
                    remove_skip_connections = remove_adapter_skip_connections,
                    expansion = 1,
                )
        else:
            self.initial_adapter = None

        if small_inputs:
            self.conv1 = conv3x3(
                in_chans,
                self.inplanes,
                conv_layer=conv_layer,
                b=b,
            )
            self.pool = None
        else:
            self.conv1 = conv_layer(
                in_chans,
                self.inplanes,
                kernel_size=7,
                stride=2,
                padding=3,
                b=b,
            )
            self.pool = nn.AvgPool2d(kernel_size=3, stride=2, padding=1)
        
        if dynamic_bias:
            self.conv1_bias = DynamicBias(
                num_channels=self.inplanes,
                b=dynamic_bias_b,
            )
            self.conv1_bias = None
        else:
            self.conv1_bias = None

        self.bn1 = norm_layer(self.inplanes)

        if act_layer != None: 
            self.act = act_layer() 
        else: 
            self.act = None

        self.__total_num_blocks = sum(layers)
        self.__num_blocks = 0

        # Adapter before layer 1
        if adapter_block == None:
            self.adapter0 = None
        elif self.enable_bottleneck_layers[0]:
            if insert_adapter_layers:
                self.adapter0 = self._make_layer(
                    adapter_block,
                    inplanes,
                    layers[0],
                    stochastic_depth_prob=stochastic_depth_prob,
                    b = b_bottleneck,
                    remove_skip_connections = remove_adapter_skip_connections,
                    dynamic_bias_b=dynamic_bias_b,
                    dynamic_bias=dynamic_bias,
                )
            else:
                self.adapter0 = adapter_block(
                    inplanes=self.inplanes,
                    planes=self.inplanes,
                    b = b_bottleneck,
                    remove_skip_connections = remove_adapter_skip_connections,
                    expansion = 1,
                    conv_layer=conv_layer,
                    dynamic_bias_b=dynamic_bias_b,
                    dynamic_bias=dynamic_bias,
                )
        else:
            self.adapter0 = None

        self.layer1 = self._make_layer(
            block,
            inplanes,
            layers[0],
            stochastic_depth_prob=stochastic_depth_prob,
            b = self.layer_b_getter.by_name("layer1"),
            conv_adapter_style = conv_adapter_style,
            conv_adapter_pos = conv_adapter_pos,
            conv_adapter_kernel_size = conv_adapter_kernel_size,
            conv_adapter_act_layer = conv_adapter_act_layer,
            conv_adapter_factor = conv_adapter_factor,
            conv_adapter_b = conv_adapter_b,
            dynamic_bias_b=dynamic_bias_b,
            dynamic_bias=dynamic_bias,

        )

        # Adapter between layer1 and layer2
        if adapter_block == None:
            self.adapter1 = None
        elif self.enable_bottleneck_layers[1]:
            if insert_adapter_layers:
                self.adapter1 = self._make_layer(
                    adapter_block,
                    inplanes,
                    layers[0],
                    stochastic_depth_prob=stochastic_depth_prob,
                    b = b_bottleneck,
                    remove_skip_connections = remove_adapter_skip_connections,
                    dynamic_bias_b=dynamic_bias_b,
                    dynamic_bias=dynamic_bias,
                )
            else:
                self.adapter1 = adapter_block(
                    inplanes=self.inplanes,
                    planes=inplanes,
                    b = b_bottleneck,
                    remove_skip_connections = remove_adapter_skip_connections,
                    conv_layer=conv_layer,
                    dynamic_bias_b=dynamic_bias_b,
                    dynamic_bias=dynamic_bias,
                )
        else:
            self.adapter1 = None


        self.layer2 = self._make_layer(
            block,
            inplanes * 2,
            layers[1],
            stride=2,
            dilate=replace_stride_with_dilation[0],
            stochastic_depth_prob=stochastic_depth_prob,
            b = self.layer_b_getter.by_name("layer2"),
            conv_adapter_style = conv_adapter_style,
            conv_adapter_pos = conv_adapter_pos,
            conv_adapter_kernel_size = conv_adapter_kernel_size,
            conv_adapter_act_layer = conv_adapter_act_layer,
            conv_adapter_factor = conv_adapter_factor,
            conv_adapter_b = conv_adapter_b,
            dynamic_bias_b=dynamic_bias_b,
            dynamic_bias=dynamic_bias,
        )
        # Adapter between layer2 and layer3
        if adapter_block == None:
            self.adapter2 = None
        elif self.enable_bottleneck_layers[2]:
            if insert_adapter_layers:
                self.adapter2 = self._make_layer(
                    adapter_block,
                    inplanes*2,
                    layers[1],
                    stochastic_depth_prob=stochastic_depth_prob,
                    b = b_bottleneck,
                    remove_skip_connections = remove_adapter_skip_connections,
                    dynamic_bias_b=dynamic_bias_b,
                    dynamic_bias=dynamic_bias,
                )
            else:
                self.adapter2 = adapter_block(
                    inplanes=self.inplanes,
                    planes=inplanes*2,
                    b = b_bottleneck,
                    remove_skip_connections = remove_adapter_skip_connections,
                    conv_layer=conv_layer,
                    dynamic_bias_b=dynamic_bias_b,
                    dynamic_bias=dynamic_bias,
                )
        else:
            self.adapter2 = None


        self.layer3 = self._make_layer(
            block,
            inplanes * 4,
            layers[2],
            stride=2,
            dilate=replace_stride_with_dilation[1],
            stochastic_depth_prob=stochastic_depth_prob,
            b = self.layer_b_getter.by_name("layer3"),
            conv_adapter_style = conv_adapter_style,
            conv_adapter_pos = conv_adapter_pos,
            conv_adapter_kernel_size = conv_adapter_kernel_size,
            conv_adapter_act_layer = conv_adapter_act_layer,
            conv_adapter_factor = conv_adapter_factor,
            conv_adapter_b = conv_adapter_b,
            dynamic_bias_b=dynamic_bias_b,
            dynamic_bias=dynamic_bias,
        )
        # Adapter between layer2 and layer3
        if adapter_block == None:
            self.adapter3 = None
        elif self.enable_bottleneck_layers[3]:
            if insert_adapter_layers:
                self.adapter3 = self._make_layer(
                    adapter_block,
                    inplanes*4,
                    layers[2],
                    stochastic_depth_prob=stochastic_depth_prob,
                    b = b_bottleneck,
                    remove_skip_connections = remove_adapter_skip_connections,
                    dynamic_bias_b=dynamic_bias_b,
                    dynamic_bias=dynamic_bias,
                )
            else:
                self.adapter3 = adapter_block(
                    inplanes=self.inplanes,
                    planes=inplanes*4,
                    b = b_bottleneck,
                    remove_skip_connections = remove_adapter_skip_connections,
                    conv_layer=conv_layer,
                    dynamic_bias_b=dynamic_bias_b,
                    dynamic_bias=dynamic_bias,
                )
        else:
            self.adapter3 = None
        try:
            self.layer4 = self._make_layer(
                block,
                inplanes * 8,
                layers[3],
                stride=2,
                dilate=replace_stride_with_dilation[2],
                stochastic_depth_prob=stochastic_depth_prob,
                b = self.layer_b_getter.by_name("layer4"),
                conv_adapter_style = conv_adapter_style,
                conv_adapter_pos = conv_adapter_pos,
                conv_adapter_kernel_size = conv_adapter_kernel_size,
                conv_adapter_act_layer = conv_adapter_act_layer,
                conv_adapter_factor = conv_adapter_factor,
                conv_adapter_b = conv_adapter_b,
                dynamic_bias_b=dynamic_bias_b,
                dynamic_bias=dynamic_bias,
            )

            if adapter_block == None:
                self.adapter4 = None
            elif self.enable_bottleneck_layers[4]:
                if insert_adapter_layers:
                    self.adapter4 = self._make_layer(
                        adapter_block,
                        inplanes*8,
                        layers[3],
                        stochastic_depth_prob=stochastic_depth_prob,
                        b = b_bottleneck,
                        remove_skip_connections = remove_adapter_skip_connections,
                        dynamic_bias_b=dynamic_bias_b,
                        dynamic_bias=dynamic_bias,
                    )
                else:
                    self.adapter4 = adapter_block(
                        inplanes=self.inplanes,
                        planes=inplanes*8,
                        b = b_bottleneck,
                        remove_skip_connections = remove_adapter_skip_connections,
                        conv_layer=conv_layer,
                        dynamic_bias_b=dynamic_bias_b,
                        dynamic_bias=dynamic_bias,
                    )
            else:
                self.adapter4 = None
                
            last_ch = inplanes * 8
        except IndexError:
            self.layer4 = None
            self.adapter4 = None
            last_ch = inplanes * 4


        self.num_features = last_ch * block.expansion
        self.avgpool = nn.AdaptiveAvgPool2d((1, 1))

        self.num_classes = num_classes
        
        if concept_layer_use:
            self.concept_layer = ConceptLayer(planes=self.inplanes, factor=concept_layer_factor, b=concept_layer_b)
        else:
            self.concept_layer = None

        self.fc = classification_conv_block(
            self.num_features,
            self.num_classes,
            kernel_size=1,
            b = b_classifier,
        )
        self.logit_layer = LogitLayer(
            logit_temperature=logit_temperature,
            logit_bias=logit_bias or -math.log(num_classes - 1),
        )
        


        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight, mode="fan_out", nonlinearity="relu")
            elif isinstance(m, nn.BatchNorm2d):
                if m.weight is not None:
                    nn.init.constant_(m.weight, 1)
                if m.bias is not None:
                    nn.init.constant_(m.bias, 0)

        # Zero-initialize the last BN in each residual branch,
        # so that the residual branch starts with zeros, and each residual block behaves like an identity.
        # This improves the model by 0.2~0.3% according to https://arxiv.org/abs/1706.02677
        if zero_init_residual:
            for m in self.modules():
                if isinstance(m, BottleneckReLU) and m.bn3.weight is not None:
                    nn.init.constant_(m.bn3.weight, 0)  # type: ignore[arg-type]
                elif isinstance(m, BasicBlock) and m.bn2.weight is not None:
                    nn.init.constant_(m.bn2.weight, 0)  # type: ignore[arg-type]
        


    def _make_layer(
        self,
        block: Type[Bottleneck],
        planes: int,
        blocks: int,
        stride: int = 1,
        dilate: bool = False,
        b: Union[int, float] = 1,
        stochastic_depth_prob: float = 0.0,
        remove_skip_connections = False,
        conv_adapter_style: str = "parallel",
        conv_adapter_pos: str = "residual",
        conv_adapter_kernel_size: int = 3,
        conv_adapter_act_layer: Callable[..., nn.Module] = DEFAULT_ACT_LAYER,
        conv_adapter_factor: int = 0,
        conv_adapter_b: int = 1,
        dynamic_bias_b: int = 1,
        dynamic_bias: bool = False,
    ) -> nn.Sequential:
        norm_layer = self._norm_layer
        conv_layer = self._conv_layer
        act_layer = self._act_layer
        downsample = None
        previous_dilation = self.dilation
        if dilate:
            self.dilation *= stride
            stride = 1
        if stride != 1 or self.inplanes != planes * block.expansion:
            downsample = nn.Sequential(
                conv1x1(
                    self.inplanes,
                    planes * block.expansion,
                    stride,
                    conv_layer=conv_layer,
                    b = b,
                ),
                norm_layer(planes * block.expansion),
            )

        layers = []
        if issubclass(block, AdapterBottleneck):
            layers.append(
                block(
                    inplanes = self.inplanes,
                    planes = planes,
                    stride = stride,
                    downsample = downsample,
                    groups = self.groups,
                    base_width = self.base_width,
                    dilation = previous_dilation,
                    norm_layer=norm_layer,
                    conv_layer=conv_layer,
                    act_layer=act_layer,
                    stochastic_depth_prob=stochastic_depth_prob
                    * self.__num_blocks
                    / (self.__total_num_blocks - 1),
                    b = b,
                    remove_skip_connections = remove_skip_connections,
                    conv_adapter_style = conv_adapter_style,
                    conv_adapter_pos = conv_adapter_pos,
                    conv_adapter_kernel_size = conv_adapter_kernel_size,
                    conv_adapter_act_layer = conv_adapter_act_layer,
                    conv_adapter_factor = conv_adapter_factor,
                    conv_adapter_b = conv_adapter_b,
                    dynamic_bias_b=dynamic_bias_b,
                    dynamic_bias=dynamic_bias,
                )
            )
        else:
            layers.append(
                block(
                    inplanes = self.inplanes,
                    planes = planes,
                    stride = stride,
                    downsample = downsample,
                    groups = self.groups,
                    base_width = self.base_width,
                    dilation = previous_dilation,
                    norm_layer=norm_layer,
                    conv_layer=conv_layer,
                    act_layer=act_layer,
                    stochastic_depth_prob=stochastic_depth_prob
                    * self.__num_blocks
                    / (self.__total_num_blocks - 1),
                    b = b,
                    remove_skip_connections = remove_skip_connections,
                    dynamic_bias_b=dynamic_bias_b,
                    dynamic_bias=dynamic_bias,
                )
            )
        
        self.__num_blocks += 1
        self.inplanes = planes * block.expansion
        for _ in range(1, blocks):
            if issubclass(block, AdapterBottleneck):
                layers.append(
                    block(
                        inplanes = self.inplanes,
                        planes = planes,
                        groups=self.groups,
                        base_width=self.base_width,
                        dilation=self.dilation,
                        norm_layer=norm_layer,
                        conv_layer=conv_layer,
                        act_layer=act_layer,
                        stochastic_depth_prob=stochastic_depth_prob
                        * self.__num_blocks
                        / (self.__total_num_blocks - 1),
                        b = b,
                        remove_skip_connections = remove_skip_connections,
                        conv_adapter_style = conv_adapter_style,
                        conv_adapter_pos = conv_adapter_pos,
                        conv_adapter_kernel_size = conv_adapter_kernel_size,
                        conv_adapter_act_layer = conv_adapter_act_layer,
                        conv_adapter_factor = conv_adapter_factor,
                        conv_adapter_b = conv_adapter_b,
                        dynamic_bias_b=dynamic_bias_b,
                        dynamic_bias=dynamic_bias,
                    )
                )
            else:
                layers.append(
                    block(
                        inplanes =self.inplanes,
                        planes = planes,
                        groups=self.groups,
                        base_width=self.base_width,
                        dilation=self.dilation,
                        norm_layer=norm_layer,
                        conv_layer=conv_layer,
                        act_layer=act_layer,
                        stochastic_depth_prob=stochastic_depth_prob
                        * self.__num_blocks
                        / (self.__total_num_blocks - 1),
                        b = b,
                        remove_skip_connections = remove_skip_connections,
                        dynamic_bias_b=dynamic_bias_b,
                        dynamic_bias=dynamic_bias,
                    )
                )
            self.__num_blocks += 1
        
        return nn.Sequential(*layers)

    def forward_features(self, x):
        if self.initial_adapter is not None: x = self.initial_adapter(x)
        x = self.conv1(x)
        if self.conv1_bias: x = self.conv1_bias(x)

        x = self.bn1(x)
        if self.act is not None: x = self.act(x)
        if self.pool is not None:
            x = self.pool(x)
        
        if self.adapter0 != None: x = self.adapter0(x)


        x = self.layer1(x)
        if self.adapter1 != None: x = self.adapter1(x)

        x = self.layer2(x)
        if self.adapter2 != None: x = self.adapter2(x)

        x = self.layer3(x)
        if self.adapter3 != None: x = self.adapter3(x)
        
        if self.layer4 is not None:
            x = self.layer4(x)
            if self.adapter4 != None: x = self.adapter4(x)
        return x

    def forward(self, x):
        if self.efficient_bcos and x.shape[1] == 3:
            x = self.add_inverse(x)
        x = self.forward_features(x)
        if self.concept_layer: x = self.concept_layer(x)
        x = self.fc(x)
        x = self.avgpool(x)
        x = x.flatten(1)
        x = self.logit_layer(x)

        return x

    def add_inverse(self, x):
        # Concatenate input with its inverse along channel dimension
        # Allow gradients to flow for training on GPU
        return torch.cat([x, 1 - x], dim=1) # dim 1 is the channel dim

    def get_classifier(self) -> nn.Module:
        """Returns the classifier part of the model. Note this comes before global pooling."""
        return self.fc

    def get_feature_extractor(self) -> nn.Module:
        """Returns the feature extractor part of the model. Without global pooling."""
        modules = [
            self.conv1,
            self.bn1,
            self.act,
        ]
        if self.pool is not None:
            modules += [self.pool]
        modules += [
            self.layer1,
            self.layer2,
            self.layer3,
        ]
        if self.layer4 is not None:
            modules += [self.layer4]
        return nn.Sequential(*modules)
    

class BcosResnet50_conv_b1_classifier(BcosResnet50_bottleneck):
    def __init__(
        self,
        *args,
        classification_conv_layer: Callable[..., nn.Module] = DEFAULT_CONV_LAYER,
        b_bottleneck = 2,
        **kwargs: Any,  # ignore rest
    ):
        super().__init__(*args, **kwargs)
        self.fc = classification_conv_layer(
            self.num_features,
            self.num_classes,
            kernel_size=1,
        )



def _resnet_conv(
    arch: str,
    block: Type[Union[BasicBlock, BottleneckReLU]],
    adapter_block: Type[Union[BcosConv2d, BottleneckReLU]],
    layers: List[int],
    classification_block: Callable[..., nn.Module],
    conv_block: Callable[..., nn.Module],
    pretrained: bool = False,
    progress: bool = True,
    inplanes: int = 64,
    b_bottleneck = 2,
    b_classifier = 2,
    b = 2,
    act_layer = None,
    insert_adapter_layers = False,
    add_initial_adapter = False,
    efficient_bcos = False,
    enable_bottleneck_layers = [1, 1, 1, 1, 1],
    remove_adapter_skip_connections = False,
    overwrite_b_for_layer = None,
    conv_adapter_style: str = "parallel",
    conv_adapter_pos: str = "residual",
    conv_adapter_kernel_size: int = 3,
    conv_adapter_act_layer: Callable[..., nn.Module] = DEFAULT_ACT_LAYER,
    conv_adapter_factor: int = 8,
    conv_adapter_b: int = 1,
    concept_layer_b: int = 2,
    concept_layer_factor: int = 2,
    concept_layer_use: bool = False, 
    dynamic_bias: bool = False,
    dynamic_bias_b: int = 1,
    conv_wise_adapter_mode: str = "in_channel",
    **kwargs: Any,
) -> BcosResnet50_bottleneck:
    model = BcosResnet50_bottleneck(
        block, 
        layers, 
        classification_conv_block=classification_block, 
        conv_layer=conv_block, 
        adapter_block=adapter_block, 
        inplanes=inplanes, 
        b_bottleneck=b_bottleneck, 
        b_classifier=b_classifier, 
        insert_adapter_layers=insert_adapter_layers, 
        add_initial_adapter=add_initial_adapter, 
        efficient_bcos=efficient_bcos, 
        b=b, 
        act_layer= act_layer, 
        enable_bottleneck_layers=enable_bottleneck_layers, 
        remove_adapter_skip_connections = remove_adapter_skip_connections, 
        overwrite_b_for_layer=overwrite_b_for_layer, 
        conv_adapter_style = conv_adapter_style,
        conv_adapter_pos = conv_adapter_pos,
        conv_adapter_kernel_size = conv_adapter_kernel_size,
        conv_adapter_act_layer = conv_adapter_act_layer,
        conv_adapter_factor = conv_adapter_factor,
        conv_adapter_b = conv_adapter_b,
        concept_layer_b=concept_layer_b,
        concept_layer_factor=concept_layer_factor,
        concept_layer_use = concept_layer_use,
        dynamic_bias_b=dynamic_bias_b,
        dynamic_bias=dynamic_bias,
        conv_wise_adapter_mode=conv_wise_adapter_mode,
        **kwargs)
    if pretrained:
        raise ValueError(
            "If you want to load pretrained weights, then please use the entrypoints in "
            "bcos.pretrained or bcos.model.pretrained instead."
        )
    return model

def bcosresnet50_bottleneck(
    pretrained: bool = False, 
    progress: bool = True, 
    bottleneck="bottleneck_d1", 
    b_bottleneck = 2, 
    b_classifier = 2, 
    insert_adapter_layers = False, 
    add_initial_adapter = False, 
    efficient_bcos = False, 
    block_class = None, 
    b=2, 
    act_layer = None,
    enable_bottleneck_layers = [1, 1, 1, 1], 
    remove_adapter_skip_connections = False, 
    convolution = None, 
    overwrite_b_for_layer = None, 
    conv_adapter_style: str = "parallel",
    conv_adapter_pos: str = "residual",
    conv_adapter_kernel_size: int = 3,
    conv_adapter_act_layer: Callable[..., nn.Module] = DEFAULT_ACT_LAYER,
    conv_adapter_factor: int = 8,
    conv_adapter_b: int = 1,
    norm_layer: str | None = None,
    concept_layer_b: int = 2,
    concept_layer_factor: int = 2,
    concept_layer_use: bool = False,
    dynamic_bias: bool = False,
    dynamic_bias_b: int = 1,
    conv_wise_adapter_mode: str = "in_channel",
    **kwargs: Any
) -> BcosResnet50_bottleneck:
    
    if insert_adapter_layers and enable_bottleneck_layers[0] == True:
        raise Exception(f"Layers as intial adapters are currently not supported.")
    bottleneck_class = get_bottleneck(bottleneck)
    block_class = get_bottleneck(block_class)
    convolution_class = get_conv(convolution)

    adapter_act_layer_class = get_act_layer(conv_adapter_act_layer)
    act_layer_class = get_act_layer(act_layer)
    norm_class = get_norm(norm_layer)


    return _resnet_conv(
        "bcosresnet50_bottleneck", 
        block_class, 
        bottleneck_class, 
        [3, 4, 6, 3], 
        DEFAULT_CONV_LAYER, 
        convolution_class, 
        pretrained, progress, 
        b_bottleneck = b_bottleneck, 
        b_classifier=b_classifier, 
        insert_adapter_layers=insert_adapter_layers, 
        add_initial_adapter=add_initial_adapter, 
        efficient_bcos=efficient_bcos, 
        b=b, 
        act_layer = act_layer_class,
        enable_bottleneck_layers=enable_bottleneck_layers, 
        remove_adapter_skip_connections=remove_adapter_skip_connections, 
        overwrite_b_for_layer=overwrite_b_for_layer, 
        conv_adapter_style = conv_adapter_style,
        conv_adapter_pos = conv_adapter_pos,
        conv_adapter_kernel_size = conv_adapter_kernel_size,
        conv_adapter_act_layer = adapter_act_layer_class,
        conv_adapter_factor = conv_adapter_factor,
        conv_adapter_b= conv_adapter_b,
        norm_layer = norm_class,
        concept_layer_factor=concept_layer_factor,
        concept_layer_b=concept_layer_b,
        concept_layer_use=concept_layer_use,
        dynamic_bias = dynamic_bias,
        dynamic_bias_b = dynamic_bias_b,
        **kwargs)

