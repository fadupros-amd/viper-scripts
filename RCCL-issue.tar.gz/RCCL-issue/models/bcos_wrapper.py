import logging
import math
import fnmatch
import torch
import torch.nn as nn
from typing import Dict, Tuple, Type, Any, Optional, Union, Callable
from collections import defaultdict, OrderedDict

import transformers
from modules.bcos_conv import BcosConv2d, BcosConv2d_unnormed
from modules.bcos_linear import BcosLinear, BcosUnnormedLinear
from modules.utils import double_conv_input_channels, double_conv_input_channels_then_convert_to_linear
from utils.explanations import BcosUtilMixin
from modules.defaults import DEFAULT_ACT_LAYER, DEFAULT_CONV_LAYER, DEFAULT_NORM_LAYER, DEFAULT_LINEAR_LAYER
from models.bcos_vit import make_conv_stem
from modules.activations import DetachableGELU
from bcos.modules import NoBias, norms, DetachableModule
from modules.norms.layernorm import DetachableLayerNorm
from bcos.models.resnet import LogitLayer
from transformers.modeling_outputs import ImageClassifierOutput
from einops import rearrange
from einops.layers.torch import Rearrange


log = logging.getLogger("lightning")   # or your own name

class ConvStem(nn.Module):
    """
    Convolutional stem that replaces the patch embedding.
    Follows the same pattern as SimpleViT: conv -> rearrange to spatial patches -> linear projection.
    """
    def __init__(
        self,
        conv_layers: list[int],
        patch_size: int = 16,
        target_dim: int = 768,
        conv2d_layer=None,
        norm2d_layer=None,
        act_layer=None,
        linear_layer=None
    ):
        super().__init__()
        self.patch_size = patch_size
        self.target_dim = target_dim
        
        # Create conv stem
        self.stem = make_conv_stem(
            in_channels=6,
            out_channels=conv_layers,
            conv2d_layer=conv2d_layer or DEFAULT_CONV_LAYER,
            norm2d_layer=norm2d_layer or DEFAULT_NORM_LAYER,
            act_layer=act_layer or DEFAULT_ACT_LAYER,
        )
        
        # Calculate actual downsampling from conv stem
        # Each layer with stride=2 halves the spatial dimensions
        downsampling_factor = 1
        prev_channels = 6
        for outc in conv_layers:
            stride = 2 if outc > prev_channels else 1
            downsampling_factor *= stride
            prev_channels = outc
        
        patch_size_after_downsampling = patch_size // downsampling_factor
        # Calculate input dim for linear layer (per patch)
        patch_height, patch_width = pair(patch_size_after_downsampling)
        patch_dim = conv_layers[-1] * patch_height * patch_width
        
        # Rearrange to spatial patches: (batch, channels, height, width) -> (batch, h, w, patch_dim)
        # This matches SimpleViT's approach: "b c (h p1) (w p2) -> b h w (p1 p2 c)"
        self.to_patches = Rearrange(
            "b c (h p1) (w p2) -> b h w (p1 p2 c)",
            p1=patch_height,
            p2=patch_width,
        )
        
        # Project each patch to target dimension
        self.patch_projection = (linear_layer or DEFAULT_LINEAR_LAYER)(patch_dim, target_dim)
        
        # Initialize the patch projection layer properly
        self._init_weights()
    
    def _init_weights(self):
        """Initialize weights similar to HuggingFace ViT"""
        # Initialize the patch projection layer
        if hasattr(self.patch_projection, 'weight'):
            # Standard linear layer
            nn.init.xavier_uniform_(self.patch_projection.weight)
        elif hasattr(self.patch_projection, 'linear'):
            # B-COS layer with wrapped linear
            if hasattr(self.patch_projection.linear, 'weight'):
                nn.init.xavier_uniform_(self.patch_projection.linear.weight)
            elif hasattr(self.patch_projection.linear, 'linear') and hasattr(self.patch_projection.linear.linear, 'weight'):
                nn.init.xavier_uniform_(self.patch_projection.linear.linear.weight)
    
    def forward(self, x):
        x = self.stem(x)  # Apply conv layers: (B, 6, 224, 224) -> (B, C, H', W')
        x = self.to_patches(x)  # Rearrange to spatial patches: (B, C, H', W') -> (B, H', W', patch_dim)
        x = self.patch_projection(x)  # Project each patch: (B, H', W', patch_dim) -> (B, H', W', 768)
        
        # Rearrange to match ViTPatchEmbeddings output format: (B, H', W', 768) -> (B, 768, H', W')
        # ViTPatchEmbeddings outputs (batch, hidden_size, height, width)
        x = x.permute(0, 3, 1, 2)  # (B, H', W', 768) -> (B, 768, H', W')
        
        return x
    
    @property
    def weight(self):
        '''
        Needs to be present to avoid errors with HF transformers ViTForImageClassification model when loading pretrained weights.
        '''
        # Handle different types of layers that might not have direct weight access
        if hasattr(self.patch_projection, 'weight'):
            return self.patch_projection.weight
        elif hasattr(self.patch_projection, 'linear') and hasattr(self.patch_projection.linear, 'weight'):
            # For B-COS layers that wrap a linear layer
            return self.patch_projection.linear.weight
        elif hasattr(self.patch_projection, 'linear') and hasattr(self.patch_projection.linear, 'linear'):
            # For doubly wrapped B-COS layers
            return self.patch_projection.linear.linear.weight
        else:
            # Fallback: create a dummy parameter if no weight is found
            import warnings
            warnings.warn("ConvStem: patch_projection layer has no accessible weight, creating dummy parameter")
            return nn.Parameter(torch.empty(self.target_dim, 1))  # Dummy parameter


def pair(t: Any) -> Tuple[Any, Any]:
    return t if isinstance(t, tuple) else (t, t)


class BcosWrapper(BcosUtilMixin, nn.Module):
    """
    A wrapper class that can replace layers in a model with B-COS equivalents.
    
    This wrapper supports both type-based and path-based parameter assignment:
    
    - Type-based: Assign parameters based on the replacement layer type (e.g., all BcosLinear layers)
    - Path-based: Assign parameters based on the layer's position/name in the model hierarchy
    
    Path-based configuration takes precedence over type-based configuration.
    
    Examples:
        # Basic usage with type-based config
        wrapper = BcosWrapper(
            model=my_model,
            layer_mapping={nn.Linear: BcosLinear},
            layer_configs={BcosLinear: {"b": 2.0}}
        )
        
        # Advanced usage with path-based config
        wrapper = BcosWrapper(
            model=my_model,
            layer_mapping={nn.Linear: BcosLinear},
            layer_configs={BcosLinear: {"b": 2.0}},  # Default b=2.0 for all
            path_configs={
                "encoder.layer.0.attention": {"b": 3.0},  # Specific layer
                "*.attention.*": {"b": 2.5},              # Wildcard pattern
                "mlp": {"b": 1.5}                         # Keyword match
            }
        )
    """
    def __init__(
        self, 
        model: nn.Module,
        layer_mapping: Optional[Dict[Type[nn.Module], Type[nn.Module]]] = None,
        layer_configs: Optional[Dict[Type[nn.Module], Dict[str, Any]]] = None,
        path_configs: Optional[Dict[str, Dict[str, Any]]] = None,
        replacement_filter: Optional[Callable[[str, nn.Module], bool]] = None,
        to_patch_embedding_key: Optional[str] = None,
        apply_replacements: bool = True,
        add_conv_stem: Optional[list[int]] = None,
        conv_stem_act_layer: Optional[Type[nn.Module]] = DEFAULT_ACT_LAYER,
        conv_stem_norm_layer: Optional[Type[nn.Module]] = DEFAULT_NORM_LAYER,
        patch_embedding_linear_layer: Optional[Type[nn.Module]] = BcosUnnormedLinear,
        conv_stem_conv_layer: Optional[Type[nn.Module]] = BcosConv2d_unnormed,
        reset_modules: Optional[Dict[str, nn.Module]] = None,
        num_classes: int = 1000,
        logit_temperature: Optional[float] = None,
        logit_bias: Optional[float] = None,
    ):
        super().__init__()
        self.log = log
        self.model = model
        self.layer_mapping = layer_mapping or {}
        self.layer_configs = layer_configs or {}
        self.path_configs = path_configs or {}
        self.replacement_filter = replacement_filter
        self.to_patch_embedding_key = to_patch_embedding_key
        self.add_conv_stem = add_conv_stem
        self.conv_stem_act_layer = conv_stem_act_layer
        self.conv_stem_conv_layer = conv_stem_conv_layer
        self.conv_stem_norm_layer = conv_stem_norm_layer
        self.patch_embedding_linear_layer = patch_embedding_linear_layer
        self.reset_modules = reset_modules or {}
        self.logit_layer = LogitLayer(
            logit_temperature=logit_temperature,
            logit_bias=logit_bias or -math.log(num_classes - 1),
        )
        
        # Track replaced layers for debugging
        self.replacement_log = []
        
        # Add conv-stem if needed
        if self.add_conv_stem:
            self._add_conv_stem()
        else:
            # Modify the patch embedding to accept 6 channels directly
            self._modify_patch_embedding_for_6_channels()
        
        # Apply layer replacements if requested
        if apply_replacements and self.layer_mapping:
            self._replace_layers()
        

    def add_inverse(self, x):
        # Concatenate input with its inverse along channel dimension
        # Allow gradients to flow for training on GPU
        x_inv = (1 - x).detach()
        return torch.cat([x, x_inv], dim=1) # dim 1 is the channel dim

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        if x.shape[1] == 3:
            x = self.add_inverse(x)
        
        x = self.model_forward(x)
        x = self.logit_layer(x)  # Apply logit layer first
        return x
    
    def model_forward(self, x: torch.Tensor) -> torch.Tensor:
        """Forward pass through the
        Base model without any modifications.
        """
        raise NotImplementedError("Subclasses must implement model_forward method.")

    def model_test_forward(self, x: torch.Tensor) -> torch.Tensor:
        """Forward pass through the wrapped model with optional positional embedding handling"""
        raise NotImplementedError("Subclasses must implement model_test_forward method.")
    

    def forward_test(self, x: torch.Tensor) -> torch.Tensor:
        if x.shape[1] == 3:
            x = self.add_inverse(x)
        
        x = self.model_test_forward(x)
        x = self.logit_layer(x)  # Apply logit layer first
        return x


    # def _disable_positional_embeddings(self):
    #     """Permanently disable positional embeddings for B-COS compliance"""
    #     if hasattr(self.model, 'vit') and hasattr(self.model.vit, 'embeddings'):
    #         embeddings = self.model.vit.embeddings
            
    #         with torch.no_grad():
    #             embeddings.position_embeddings.data.zero_()
            
    #         embeddings.position_embeddings.requires_grad_(False)
            
    #         print("Disabled positional embeddings for B-COS compliance")


    def _replace_layers(self):
        """Replace layers according to the mapping configuration"""
        
        # Recursively replace layers
        self._replace_layers_recursive(self.model, "", parent_module=None)
        
        # Log replacement summary
        if self.replacement_log:
            print(f"BcosWrapper: Replaced {len(self.replacement_log)} layers:")
            for log_entry in self.replacement_log:
                print(f"  {log_entry}")

    def _replace_layers_recursive(self, module: nn.Module, path: str, parent_module: Optional[nn.Module] = None):
        """Recursively traverse and replace layers"""
        
        for name, child in list(module.named_children()):
            child_path = f"{path}.{name}" if path else name
            
            # Check if this child should be replaced
            original_type = type(child)
            replacement_type = None
            
            # First check direct type mapping
            if original_type in self.layer_mapping:
                replacement_type = self.layer_mapping[original_type]
            # Then check for Linear-like classes (handles NoNDynamicallyQuantizableLinear, etc.)
            elif "Linear" in original_type.__name__ and hasattr(child, 'in_features') and hasattr(child, 'out_features'):
                # Treat any Linear-like layer as nn.Linear
                replacement_type = self.layer_mapping.get(nn.Linear)
            
            if (replacement_type and self._should_replace_layer(child_path, child, parent_module)):
                
                # Start with type-based config
                type_config = self.layer_configs.get(replacement_type, {})
                
                # Get path-based config (if any)
                path_config = self._get_path_config(child_path)
                
                # Merge configs: path-based config takes precedence over type-based config
                replacement_config = {**type_config, **path_config}
                
                # Create replacement layer
                new_layer = self._create_replacement_layer(
                    original_layer=child,
                    replacement_type=replacement_type,
                    config=replacement_config,
                    layer_path=child_path
                )
                
                # Replace the layer
                setattr(module, name, new_layer)
                
                # Log the replacement
                self.replacement_log.append(
                    f"{child_path}: {original_type.__name__} → {replacement_type.__name__}"
                )
            else:
                # Recursively process child modules, passing current module as parent
                self._replace_layers_recursive(child, child_path, parent_module=module)

    def _should_replace_layer(self, layer_path: str, layer: nn.Module, parent_module: Optional[nn.Module] = None) -> bool:
        """Check if this layer should be replaced"""
        # Skip replacement if we're inside a conv stem (avoid double wrapping)
        if 'stem' in layer_path.lower() or 'convstem' in layer_path.lower() or "patch_projection" in layer_path.lower():
            return False
            
        # Skip replacement if the parent is already a B-COS layer (avoid double wrapping)
        if parent_module is not None:
            if isinstance(parent_module, DetachableModule):
                return False
        
        # Also skip if the layer itself is already a B-COS layer
        if isinstance(layer, DetachableModule):
            return False
            
        if self.replacement_filter:
            return self.replacement_filter(layer_path, layer)
        return True

    def _get_path_config(self, layer_path: str) -> Dict[str, Any]:
        """Get configuration for a layer based on its path/name"""
        config = {}
        
        # Check if there's a direct match for the layer path
        if layer_path in self.path_configs:
            config.update(self.path_configs[layer_path])
        
        # Check for pattern matches (e.g., partial matches, wildcards)
        for pattern, pattern_config in self.path_configs.items():
            if self._path_matches_pattern(layer_path, pattern):
                config.update(pattern_config)
        
        return config
    
    def _path_matches_pattern(self, layer_path: str, pattern: str) -> bool:
        """Check if layer path matches a pattern
        
        Supports:
        - Exact matches
        - Wildcard patterns with * (e.g., "*.attention.*")
        - Substring matches if pattern contains keywords
        """
        # Exact match
        if layer_path == pattern:
            return True
        
        # Wildcard pattern matching
        if '*' in pattern:
            return fnmatch.fnmatch(layer_path, pattern)
        
        # Substring/keyword matching
        # This allows patterns like "attention" to match any path containing "attention"
        if pattern in layer_path:
            return True
        
        return False

    def _create_replacement_layer(
        self, 
        original_layer: nn.Module,
        replacement_type: Type[nn.Module],
        config: Dict[str, Any],
        layer_path: str
    ) -> nn.Module:
        """Create a replacement layer with proper parameter transfer"""
        
        # Get original layer parameters
        original_params = self._extract_layer_params(original_layer)
        
        # Merge original params with replacement config
        # Replacement config takes precedence
        combined_params = {**original_params, **config}
        
        try:
            # Create new layer
            new_layer = replacement_type(**combined_params)
            
            # Transfer weights if possible
            self._transfer_weights(original_layer, new_layer)
            
            # Add explanation mode support if it's a B-COS layer
            if hasattr(new_layer, 'set_explanation_mode'):
                new_layer._explanation_mode_active = False
            
            return new_layer
            
        except Exception as e:
            print(f"Warning: Failed to create {replacement_type.__name__} for {layer_path}: {e}")
            print(f"  Original params: {original_params}")
            print(f"  Combined params: {combined_params}")
            # Return original layer if replacement fails
            return original_layer

    def _extract_layer_params(self, layer: nn.Module) -> Dict[str, Any]:
        """Extract parameters from original layer for replacement layer creation"""
        
        if isinstance(layer, nn.Linear):
            return {
                'in_features': layer.in_features,
                'out_features': layer.out_features,
                # 'bias': layer.bias is not None
            }
        
        elif isinstance(layer, nn.Conv2d):
            return {
                'in_channels': layer.in_channels,
                'out_channels': layer.out_channels,
                'kernel_size': layer.kernel_size,
                'stride': layer.stride,
                'padding': layer.padding,
                'dilation': layer.dilation,
                'groups': layer.groups,
                # 'bias': layer.bias is not None,
                'padding_mode': layer.padding_mode
            }
        
        elif isinstance(layer, nn.Conv1d):
            return {
                'in_channels': layer.in_channels,
                'out_channels': layer.out_channels,
                'kernel_size': layer.kernel_size,
                'stride': layer.stride,
                'padding': layer.padding,
                'dilation': layer.dilation,
                'groups': layer.groups,
                # 'bias': layer.bias is not None,
                'padding_mode': layer.padding_mode
            }
        
        elif isinstance(layer, nn.LayerNorm):
            return {
                'normalized_shape': layer.normalized_shape,
                'eps': layer.eps,
                'elementwise_affine': layer.elementwise_affine
            }
        
        # Handle layers with "Linear" in the class name (like NoNDynamicallyQuantizableLinear)
        elif "Linear" in layer.__class__.__name__ and hasattr(layer, 'in_features') and hasattr(layer, 'out_features'):
            return {
                'in_features': layer.in_features,
                'out_features': layer.out_features,
                # 'bias': layer.bias is not None
            }
        
        # Add more layer types as needed
        else:
            # For unknown layer types, return empty dict
            return {}


    def _transfer_weights(self, original_layer: nn.Module, new_layer: nn.Module):
        """Transfer weights from original layer to replacement layer"""
        
        try:
            with torch.no_grad():
                # Handle different weight transfer scenarios
                
                # First check if new layer has a linear attribute (B-COS layers)
                if hasattr(original_layer, 'weight') and hasattr(new_layer, 'linear'):
                    # For B-COS layers that wrap a linear layer
                    if hasattr(new_layer.linear, 'weight'):
                        new_layer.linear.weight.copy_(original_layer.weight)
                    elif hasattr(new_layer.linear, 'linear') and hasattr(new_layer.linear.linear, 'weight'):
                        new_layer.linear.linear.weight.copy_(original_layer.weight)
                
                elif hasattr(original_layer, 'weight') and hasattr(new_layer, 'weight'):
                    new_layer.weight.copy_(original_layer.weight)
                
        except Exception as e:
            print(f"Warning: Could not transfer weights: {e}")

    def _modify_patch_embedding_for_6_channels(self):
        """Directly modify the patch embedding layer to accept 6 channels"""
        modified = False
        
        # Try to find and modify the patch embedding layer
        for name, module in self.model.named_modules():
            if isinstance(module, nn.Conv2d) and module.in_channels == 3:
                # Check if this is likely the patch embedding layer
                if (self.to_patch_embedding_key and self.to_patch_embedding_key in name):                    
                    print(f"Converting Conv2d layer '{name}' from 3 to 6 input channels")
                    print(f"  Original weight shape: {module.weight.shape}")
                    
                    # Get the current weight
                    original_weight = module.weight.data
                    
                    # Create new weight with doubled input channels
                    new_weight = double_conv_input_channels(original_weight)
                    
                    # Create a new Conv2d layer with 6 input channels
                    new_conv = nn.Conv2d(
                        in_channels=6,
                        out_channels=module.out_channels,
                        kernel_size=module.kernel_size,
                        stride=module.stride,
                        padding=module.padding,
                        dilation=module.dilation,
                        groups=module.groups,
                        bias=module.bias is not None,
                        padding_mode=module.padding_mode,
                        device=module.weight.device,
                        dtype=module.weight.dtype
                    )
                    
                    # Copy the modified weights
                    with torch.no_grad():
                        new_conv.weight.data = new_weight
                        if module.bias is not None and new_conv.bias is not None:
                            new_conv.bias.data = module.bias.data.clone()
                    
                    # Replace the layer in the model
                    parent_name = '.'.join(name.split('.')[:-1])
                    layer_name = name.split('.')[-1]
                    
                    if parent_name:
                        parent_module = dict(self.model.named_modules())[parent_name]
                        setattr(parent_module, layer_name, new_conv)
                    else:
                        setattr(self.model, layer_name, new_conv)
                    
                    print(f"  New weight shape: {new_conv.weight.shape}")
                    modified = True
                    break  # Assume only one patch embedding layer
        
        if not modified:
            print(f"Warning: No patch embedding Conv2d layer found to convert")
            print(f"Looking for layers containing: {self.to_patch_embedding_key}")
            conv_layers = [(name, module) for name, module in self.model.named_modules() 
                          if isinstance(module, nn.Conv2d)]
            print(f"Available Conv2d layers: {[name for name, _ in conv_layers]}")

    
    def _add_conv_stem(self, patch_size = 16):
        assert self.to_patch_embedding_key, "to_patch_embedding_key must be set to add a conv stem."
        if self.add_conv_stem is None: return

        config = self._get_path_config(self.to_patch_embedding_key)

        # Navigate to the patch embedding layer using dot notation
        module_parts = self.to_patch_embedding_key.split('.')
        current_module = self.model
        
        # Navigate through the module hierarchy
        for part in module_parts:
            if hasattr(current_module, part):
                current_module = getattr(current_module, part)
            else:
                raise Exception(f"Cannot find patch embedding key '{self.to_patch_embedding_key}' in model. Missing part: '{part}'")
        
        to_patch_embedding = current_module
        
        # Get target dimension (number of output channels from original patch embedding)
        if hasattr(to_patch_embedding, 'out_channels'):
            target_dim = to_patch_embedding.out_channels
        elif hasattr(to_patch_embedding, 'out_features'):
            target_dim = to_patch_embedding.out_features
        else:
            target_dim = 768  # Default fallback

        # Create the new ConvStem
        conv_stem = ConvStem(
            conv_layers=self.add_conv_stem,
            patch_size=patch_size,
            target_dim=target_dim,
            conv2d_layer=self.conv_stem_conv_layer,
            norm2d_layer=self.conv_stem_norm_layer,
            act_layer=self.conv_stem_act_layer,
            linear_layer=self.patch_embedding_linear_layer,
        )
        
        # Replace the patch embedding in the model
        parent_parts = module_parts[:-1]
        parent_module = self.model
        for part in parent_parts:
            parent_module = getattr(parent_module, part)
        
        setattr(parent_module, module_parts[-1], conv_stem)

    # Convenience methods
    @classmethod
    def create_vit_wrapper(cls, *args, **kwargs):
        raise NotImplementedError("Use create_vit_wrapper with parameters.")

    

    def get_replacement_summary(self) -> Dict[str, int]:
        """Get summary of layer replacements"""
        summary = defaultdict(int)
        for log_entry in self.replacement_log:
            replacement_type = log_entry.split("→")[-1].strip()
            summary[replacement_type] += 1
        return dict(summary)

    def get_path_based_config_info(self) -> Dict[str, Any]:
        """Get information about path-based configurations"""
        info = {
            "total_path_patterns": len(self.path_configs),
            "path_patterns": list(self.path_configs.keys()),
            "example_usage": {
                "specific_layer": "model.encoder.layer.0.attention.output.dense",
                "wildcard_pattern": "*.attention.*", 
                "keyword_match": "attention"
            }
        }
        return info
    
    def _reset_modules(self):
        """Reset specific modules to their original state"""
        for module_name, module in self.model.named_modules():
            for reset_pattern in self.reset_modules:
                if self._path_matches_pattern(module_name, reset_pattern):
                    self._reset_single_module_weights(module)
                    log.info(f"Reset module: {module_name}")
    
    def _reset_single_module_weights(self, module: nn.Module):
        """Reset weights of a single module with random initialization (e.g. for a new classifier)"""
        if hasattr(module, 'weight'):
            with torch.no_grad():
                # Random initialization based on module type
                if isinstance(module, nn.Linear):
                    # Xavier/Glorot uniform initialization for linear layers
                    nn.init.xavier_uniform_(module.weight)
                elif isinstance(module, (nn.Conv1d, nn.Conv2d, nn.Conv3d)):
                    # Kaiming normal initialization for convolutional layers
                    nn.init.kaiming_normal_(module.weight, mode='fan_out', nonlinearity='relu')
                else:
                    # Default normal initialization for other layer types
                    nn.init.normal_(module.weight, mean=0.0, std=0.02)
                
                
                log.info(f"Reset weights for module {module} to random state.")
        else:
            print(f"Warning: Module {module} does not have 'weight' attribute for reset.")
