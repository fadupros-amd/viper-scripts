
import logging
import math
import fnmatch
import torch
import torch.nn as nn
from typing import Dict, Type, Any, Optional, Union, Callable
from collections import defaultdict

import transformers
from modules.utils import double_conv_input_channels, double_conv_input_channels_then_convert_to_linear
from utils.explanations import BcosUtilMixin
from modules.defaults import DEFAULT_ACT_LAYER, DEFAULT_CONV_LAYER, DEFAULT_NORM_LAYER, DEFAULT_LINEAR_LAYER
from models.bcos_vit import make_conv_stem
from modules.activations import DetachableGELU
from bcos.modules import NoBias, norms
from modules.norms.layernorm import DetachableLayerNorm
from bcos.models.resnet import LogitLayer
from transformers.modeling_outputs import ImageClassifierOutput
from models.bcos_wrapper import BcosWrapper


class HFViTForClassificationWrapper(BcosWrapper):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        
        # Initialize hook attributes (only for CLS token removal)
        self._cls_removal_hook = None
        
        self._update_num_channels_for_hf_embedding()
        self.disable_cls_token()  # Disable CLS token by default
        self.enable_attention_detaching()  # Enable attention detaching by default
        self._enable_mean_pooling_vit()  # Enable mean pooling by default


    def model_forward(self, x: torch.Tensor) -> torch.Tensor:
        """Forward pass through the wrapped model with optional positional embedding handling. This function returns the logits from the forward pass of the model."""
        x = self.model(x)
        x = self._extract_logits(x)  # Extract logits if needed
        return x
    
    def model_test_forward(self, x: torch.Tensor) -> torch.Tensor:
        """Forward pass through the wrapped model with optional positional embedding handling"""
        self.disable_pos_embeddings()  # Disable positional embeddings by default

        x = self.model(x, interpolate_pos_encoding=False)
        x = self._extract_logits(x)

        self.enable_pos_embeddings()  # Re-enable positional embeddings after forward pass
        return x

    def disable_pos_embeddings(self):
        """Disable positional embeddings by zeroing them out"""
        if hasattr(self.model, 'vit') and hasattr(self.model.vit, 'embeddings'):
            embeddings = self.model.vit.embeddings
            if hasattr(embeddings, 'position_embeddings'):
                # Store original if not already stored
                if not hasattr(self, '_original_pos_embeddings') or self._original_pos_embeddings is None:
                    self._original_pos_embeddings = embeddings.position_embeddings.data.clone()
                # Zero out the positional embeddings
                embeddings.position_embeddings.data.zero_()
                print("✓ Disabled positional embeddings (zeroed out)")
            else:
                raise Exception("Model does not have 'position_embeddings' attribute")
        else:
            raise Exception("Model does not have 'vit.embeddings' attribute")
    
    def enable_pos_embeddings(self):
        """Re-enable positional embeddings by restoring original values"""
        if hasattr(self.model, 'vit') and hasattr(self.model.vit, 'embeddings'):
            embeddings = self.model.vit.embeddings
            if hasattr(self, '_original_pos_embeddings') and self._original_pos_embeddings is not None:
                embeddings.position_embeddings.data.copy_(self._original_pos_embeddings)
                print("✓ Enabled positional embeddings (restored original values)")
            else:
                print("No original positional embeddings to restore")
        else:
            print("No positional embeddings to enable")


    @classmethod
    def create_vit_wrapper(
        cls,
        model: nn.Module,
        b_linear: float = 1,
        b_conv2d: float = 1,
        b_qkv: float = 1,
        b_classifier: float = 1,
        add_conv_stem: bool = False,
        conv_stem_norm_layer: Type[nn.Module] = DEFAULT_NORM_LAYER,
    ):
        """Create a B-COS wrapper with common layer replacements and path-based configuration
        
        Args:
            model: Model to wrap
            b_linear: Default b value for linear layers
            b_conv2d: Default b value for conv2d layers  
            b_conv1d: Default b value for conv1d layers
            include_conv_layers: Whether to replace conv layers
            replacement_filter: Optional filter function
            path_specific_configs: Dictionary mapping layer paths/patterns to configs
                                 Example:
                                 {
                                     "encoder.layer.0.attention": {"b": 3.0},
                                     "*.attention.*": {"b": 2.5},
                                     "mlp": {"b": 1.5}
                                 }
        """
        
        # Import B-COS layers (assuming they exist in your codebase)
        from modules.bcos_linear import BcosLinear, BcosUnnormedLinear
        from modules.bcos_conv import BcosConv2d, BcosConv2d_unnormed
        
        path_specific_configs: Optional[Dict[str, Dict[str, Any]]] = {
            "*key*": {"b": b_qkv},
            "*value*": {"b": b_qkv},
            "*query*": {"b": b_qkv},
            "*classifier*": {"b": b_classifier},
        }

        # Define layer mapping
        layer_mapping = {
            nn.Linear: BcosUnnormedLinear,
            nn.Conv2d: BcosConv2d_unnormed,
            nn.LayerNorm: NoBias(DetachableLayerNorm),
            nn.GELU: DetachableGELU,
            # transformers.models.vit.modeling_vit.ViTIntermediate: BcosUnnormedLinear,
            # transformers.models.vit.modeling_vit.ViTOutput: BcosUnnormedLinear,
            transformers.activations.GELUActivation: DetachableGELU,  # For HuggingFace ViT
            torch.nn.modules.linear.Linear: BcosUnnormedLinear,  # For PyTorch Linear layers
        }

        # Define layer configurations (type-based defaults)
        layer_configs = {
            BcosUnnormedLinear: {"b": b_linear, "bias": False},
            BcosConv2d_unnormed: {"b": b_conv2d, "bias": False},
        }

        def replacement_filter(layer_path: str, layer: nn.Module) -> bool:
            """Filter function to determine if a layer should be replaced"""
            # Example: Only replace layers that are not already B-COS layers
            # if "value" in layer_path:
            #     return False
            return True
                
        return cls(
            model=model,
            layer_mapping=layer_mapping,
            layer_configs=layer_configs,
            path_configs=path_specific_configs,
            replacement_filter=replacement_filter,
            add_conv_stem=add_conv_stem,
            to_patch_embedding_key="vit.embeddings.patch_embeddings.projection",
            conv_stem_norm_layer=conv_stem_norm_layer
            
        )
    
    def _update_num_channels_for_hf_embedding(self):
        """Update all relevant model configurations to expect 6 input channels"""
        updated_configs = []
        print(type(self.model))  
        # Update embeddings config if it exists separately
        if hasattr(self.model, 'vit') and hasattr(self.model.vit, 'embeddings'):
            if hasattr(self.model.vit.embeddings, 'patch_embeddings'):
                embeddings = self.model.vit.embeddings.patch_embeddings
                # Some models might store this in the embeddings directly
                if hasattr(embeddings, 'num_channels'):
                    embeddings.num_channels = 6
                    updated_configs.append("model.vit.embeddings.patch_embeddings.num_channels")
                else:
                    raise Exception(
                        "Model does not have 'num_channels' attribute in 'vit.embeddings.patch_embeddings'. "
                        "Ensure you are using a ViT model or similar architecture."
                    )
            else:
                raise Exception(
                    "Model does not have 'patch_embeddings' attribute in 'vit.embeddings'. "
                    "Ensure you are using a ViT model or similar architecture."
                )
        else:
            raise Exception(
                "Model does not have 'vit.embeddings' attribute. "
                "Ensure you are using a ViT model or similar architecture."
            )
        print(f"Updated configurations: {updated_configs}")

    def _extract_logits(self, x: torch.Tensor) -> torch.Tensor:
        """Extract logits from the model output"""
        if isinstance(x, ImageClassifierOutput):
            # For HuggingFace ViT models, extract logits directly
            return x.logits
        else:
            # For other models, just return the output
            return x
        
    def disable_cls_token(self):
        """Install a hook to disable CLS token by slicing it off after embeddings"""
        if hasattr(self.model, 'vit') and hasattr(self.model.vit, 'embeddings'):
            def remove_cls_hook(module, input_args, output):
                # output is the embeddings tensor with CLS token added
                if output is not None and output.dim() == 3 and output.size(1) > 1:
                    # Remove first token (CLS token)
                    return output[:, 1:, :]
                return output
            
            # Install the hook on the embeddings layer
            self._cls_removal_hook = self.model.vit.embeddings.register_forward_hook(remove_cls_hook)
            print("✓ Installed CLS token removal hook on embeddings")
            return self._cls_removal_hook
        else:
            raise Exception("Model does not have 'vit.embeddings' attribute")
    
    def enable_cls_token(self):
        """Remove the CLS token removal hook to restore normal behavior"""
        if hasattr(self, '_cls_removal_hook') and self._cls_removal_hook is not None:
            self._cls_removal_hook.remove()
            self._cls_removal_hook = None
            print("✓ Removed CLS token removal hook")
        else:
            print("No CLS removal hook to remove")

    def enable_attention_detaching(self):
        """Make attention modules inherit from DetachableModule and add detach hooks"""
        if hasattr(self.model, 'vit') and hasattr(self.model.vit, 'encoder'):
            from bcos.modules.common import DetachableModule
            
            self._attention_hooks = []
            
            # Convert all attention modules to DetachableModule and add hooks
            for layer_idx, layer in enumerate(self.model.vit.encoder.layer):
                if hasattr(layer, 'attention') and hasattr(layer.attention, 'attention'):
                    attention_module = layer.attention.attention
                    
                    # Mix in DetachableModule behavior without changing the class definition
                    # Add DetachableModule to the MRO by modifying __class__.__bases__
                    if DetachableModule not in attention_module.__class__.__mro__:
                        # Create a new class that inherits from both
                        original_class = attention_module.__class__
                        class_name = f"Detachable{original_class.__name__}"
                        
                        # Create new class with DetachableModule mixed in
                        new_class = type(class_name, (DetachableModule, original_class), {})
                        
                        # Change the instance's class
                        attention_module.__class__ = new_class
                        
                        # Initialize DetachableModule attributes if not present
                        if not hasattr(attention_module, 'detach'):
                            attention_module.detach = False  # Start disabled, will be controlled by BcosUtilMixin
                    
                    # Add hooks to key and query that respect the detach attribute
                    def create_detach_hook(module):
                        def detach_hook(mod, input, output):
                            if module.detach:
                                return output.detach()
                            return output
                        return detach_hook
                    
                    key_hook = attention_module.key.register_forward_hook(
                        create_detach_hook(attention_module)
                    )
                    self._attention_hooks.append(key_hook)
                
                    query_hook = attention_module.query.register_forward_hook(
                        create_detach_hook(attention_module)
                    )
                    self._attention_hooks.append(query_hook)
                    
                    print(f"✓ Mixed in DetachableModule and added detach hooks for layer {layer_idx}")
            
            print("✓ All attention modules are now DetachableModules with detach hooks")
        else:
            raise Exception("Model does not have the expected ViT encoder structure")
    
    # def disable_attention_detaching(self):
    #     """Remove detach hooks (DetachableModule behavior still remains)"""
    #     if hasattr(self, '_attention_hooks'):
    #         for hook in self._attention_hooks:
    #             hook.remove()
    #         self._attention_hooks = []
    #         print("✓ Removed detach hooks from attention modules")

    def _enable_mean_pooling_vit(self):
        """Replace ViT's classifier to use mean pooling instead of CLS token"""
        
        if hasattr(self.model, 'vit'):
            
            def mean_pooling_forward(pixel_values, **kwargs):
                # Get the base ViT outputs
                vit_outputs = self.model.vit(pixel_values, **kwargs)
                
                # Skip CLS token (first token) and apply mean pooling
                sequence_output = vit_outputs.last_hidden_state[:, :, :]  # Skip CLS
                pooled_output = sequence_output.mean(dim=1)  # Mean pool
                
                # Apply the classifier to pooled output
                logits = self.model.classifier(pooled_output)
                
                return ImageClassifierOutput(
                    loss=None,
                    logits=logits,
                    hidden_states=vit_outputs.hidden_states,
                    attentions=vit_outputs.attentions,
                )
            
            self.model.forward = mean_pooling_forward
            print("✓ Enabled mean pooling for ViT model")
