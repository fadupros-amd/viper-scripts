

import os
from torch import nn
import yaml
import torch

class ImagenetWrapper():
    def __init__(self, model):
        self.model = model
        self.get_mapping()
        self.convert_model()


    def get_mapping(self):
        """Get the mapping of layers in the model."""
        yaml_path = os.environ.get("IMAGENET200_LABEL_MAPPING_PATH")
        assert yaml_path is not None, "IMAGENET200_LABEL_MAPPING_PATH environment variable is not set"

        # Parse the imagenet200 integer-to-integer mapping
        self.imagenet200_to_imagenet_int_mapping = {}
        try:
            with open(yaml_path, 'r') as f:
                for line in f:
                    parts = line.strip().split()
                    if len(parts) == 2:
                        try:
                            imagenet200_label = int(parts[0])
                            standard_imagenet_label = int(parts[1])
                            self.imagenet200_to_imagenet_int_mapping[imagenet200_label] = standard_imagenet_label
                        except ValueError:
                            print(f"Skipping malformed line in {yaml_path}: Invalid integers in line {line.strip()}")
                    else:
                        print(f"Skipping malformed line in {yaml_path}: {line.strip()}")
        except FileNotFoundError:
            raise FileNotFoundError(f"Imagenet200 labels mapping file not found: {yaml_path}")
        except Exception as e:
            raise IOError(f"Error reading Imagenet200 labels mapping file {yaml_path}: {e}")

    
    
    def get_model(self):
        """Get the underlying model."""

        return self.model
    
    def convert_model(self):
        """Convert the model to filter ImageNet-1k output to ImageNet-200."""
        mapping = self.imagenet200_to_imagenet_int_mapping
        
        # Create tensor of ImageNet-1k indices that correspond to ImageNet-200 classes
        # Sort by ImageNet-200 labels to maintain order
        max_imagenet200_class = max(mapping.keys())
        imagenet1k_indices = []

        for imagenet200_class in range(max_imagenet200_class + 1):
            if imagenet200_class in mapping:
                imagenet1k_indices.append(mapping[imagenet200_class])
            else:
                raise ValueError(f"Missing mapping for ImageNet-200 class {imagenet200_class}")
            
        self.imagenet200_indices = torch.tensor(imagenet1k_indices, dtype=torch.long)
        
        # Store original forward method
        forward_method = getattr(self.model, "forward")
        setattr(self.model, "original_forward", forward_method)

        def new_forward(*args, **kwargs):
            output = self.model.original_forward(*args, **kwargs)
            
            indices = self.imagenet200_indices.to(output.device)
            
            # Filter to only ImageNet-200 classes using integer indices
            output_filtered = torch.index_select(output, 1, indices)
            
            return output_filtered

        setattr(self.model, "forward", new_forward)
    
        
        