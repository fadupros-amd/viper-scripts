from functools import partial
import warnings
import torch
import torch.nn as nn
import torch.optim as optim
import lightning.pytorch as pl
import torchmetrics # Make sure torchmetrics is installed (pip install torchmetrics)
from torchmetrics import Metric
import torchvision
from torchvision.models import resnet50
from lightning.pytorch.loggers import WandbLogger # Added for type hinting
from typing import List, OrderedDict, cast, Union, Optional, Any # Added for type casting and Union
from lightning.pytorch import Trainer # Added for type hinting Trainer
from lightning.pytorch.core.datamodule import LightningDataModule # Added for type hinting
from bcos.models.resnet import resnet50 as bcosresnet50
import bcos
from experiment.experiment import Experiment
from torch.nn import CrossEntropyLoss, BCELoss
from torch.optim.lr_scheduler import SequentialLR, LinearLR, CosineAnnealingLR
from bcos.modules.losses import UniformOffLabelsBCEWithLogitsLoss
from grid_pg.grid_pg import get_localization_score, strided_forward
from models.bcos_resnet import BcosResnet50_bottleneck, bcosresnet50_bottleneck
from captum.attr import LayerGradCam
from captum.attr import visualization as viz

from models.model_factory import ModelFactory
from models.model_factory_legacy import ModelFactoryLegacy
# import thunder
try:
    from lightning_fabric.utilities.rank_zero import rank_zero_only
except ImportError:
    # In newer versions of Lightning, rank_zero_only moved to lightning.pytorch
    from lightning.pytorch.utilities.rank_zero import rank_zero_only
import logging
import numpy as np
from lightning.pytorch.utilities.model_summary.model_summary import ModelSummary
import torch.nn.functional as F
from bcos.modules import norms
from torch import Tensor
from bcos.modules.bcosconv2d import NormedConv2d
import bcos
import torch.nn.utils.prune as prune
import traceback
import time
from metrics.qualitative import ContributionMetric
from modules.adapters.wrapper_base import ModelWrapperBase
# from modules.layerwise_freezing import AdaptiveAdapterFreezing
from modules.utils import double_conv_input_channels, double_conv_input_channels_then_convert_to_linear
from models.bcos_vit import FeedForward, apply_gradient_checkpointing, bcos_vit, SimpleViT
import os
from modules.adapters.lora import LoRAConfig
from models.utils import log_new_section, get_linear_layer, get_parameter_numbers, is_bcos, is_simple_vit, get_layer_from_experiment, test_bcos_model
from grid_pg.grid_pg_processor import GridPGProcessor
from visualization.visualization_processor import VisualizationProcessor
from pytorch_optimizer import SAM, RAdam, Ranger21
from lightning.pytorch.loggers.wandb import WandbLogger


# Suppress PIL EXIF warnings for corrupted image metadata
warnings.filterwarnings("ignore", message="Corrupt EXIF data.*", category=UserWarning, module="PIL.TiffImagePlugin")
warnings.filterwarnings("ignore", message="Corrupt EXIF data.*", category=UserWarning, module="PIL.ExifTags")

CLEAN_CACHE = True
DEFAULT_PRUNABLE_MODULES = (nn.Conv2d, nn.Linear, NormedConv2d)

# log = logging.getLogger(__name__)
log = logging.getLogger("lightning")   # or your own name

def create_warmup_cosine_scheduler(optimizer, total_epochs, warmup_epochs=5, warmup_start_factor=0.01, eta_min=0):
    warmup_scheduler = LinearLR(
        optimizer,
        start_factor=warmup_start_factor,
        total_iters=warmup_epochs
    )
    cosine_scheduler = CosineAnnealingLR(
        optimizer,
        T_max=total_epochs - warmup_epochs,
        eta_min=eta_min
    )
    scheduler = SequentialLR(
        optimizer,
        schedulers=[warmup_scheduler, cosine_scheduler],
        milestones=[warmup_epochs]
    )
    return scheduler


class BcosLightningModule(pl.LightningModule):
    
    def __init__(self, experiment: Experiment):
        super().__init__()
        self.save_hyperparameters()
        self.experiment = experiment
        self._loading_from_checkpoint = False  # Flag to prevent duplicate logging
        
        # Set up SAM configuration
        if getattr(experiment, 'use_sam', False):
            self.automatic_optimization = False
            self.use_sam = True
            log.info("🔧 SAM DEBUG: SAM enabled, automatic_optimization=False")
            warnings.warn("Using SAM optimizer. Automatic optimization is disabled. You must call `self.sam_step()` in your training step to use SAM correctly.", UserWarning)
        else:
            self.automatic_optimization = True
            self.use_sam = False
            log.info("🔧 SAM DEBUG: SAM disabled, automatic_optimization=True")

        
        # --- Model Creation will be done in setup() ---
        # This ensures self.logger is available for W&B logging
        self.model_factory: Optional[ModelFactoryLegacy | ModelFactory] = None
        self.model: Optional[nn.Module] = None  # Will be set in setup()
        self.total_params: int = 0
        self.trainable_params: int = 0
        
        self.logger: WandbLogger # Initialized by PyTorch Lightning Trainer
        
        
        # --- Initialize processors after model is created ---
        # These will be set up in setup() method
        self.grid_pg_processor = None
        self.visualization_processor = None

        self._get_metrics()
        self._get_loss()
        
        log_new_section("Initial setup finished", logger=log)

        # Add adaptive freezing if enabled
        # self.adaptive_freezing = None
        # if getattr(experiment, 'use_adaptive_freezing', False):
        #     log.info("Adaptive freezing is enabled. Initializing AdaptiveAdapterFreezing...")
        #     self.adaptive_freezing = AdaptiveAdapterFreezing(
        #         model=self.model,
        #         top_k=getattr(experiment, 'adaptive_freezing_top_k', 2),
        #         evaluation_frequency=getattr(experiment, 'adaptive_freezing_frequency', 1),
        #         smoothing_factor=getattr(experiment, 'adaptive_freezing_smoothing', 0.9),
        #         min_switch_threshold=getattr(experiment, 'adaptive_freezing_threshold', 0.05),
        #         warmup_steps=getattr(experiment, 'adaptive_freezing_warmup', 10)
        #     )

    # Legacy modification method removed - ModelFactory handles model modifications
    
    def setup(self, stage):
        self.trainer: Trainer # Type hint for self.trainer
        
        # --- Model Creation with Factory ---
        # Now self.log is available for W&B logging

        if self.experiment.model in ["vit", "BcosResNet50_bottleneck"]:
            factory_class = ModelFactoryLegacy
        else:
            factory_class = ModelFactory

        self.model_factory = factory_class(self.experiment, log=log)
        self.model: nn.Module = self.model_factory.create_model()
        
        # Get parameter counts
        total_params, trainable_params = self.get_total_parameter_count(), self.get_trainable_parameter_count()
        self.total_params = total_params
        self.trainable_params = trainable_params
        
        # Explicitly cast self.model to torch.nn.Module to help Pylance
        self.model = cast(torch.nn.Module, self.model)
        
        # --- Initialize GridPG Processor ---
        self.grid_pg_processor = GridPGProcessor(
            experiment=self.experiment,
            model=self.model,
            explain_fn=self.explain,
            is_bcos_fn=is_bcos,
            get_layer_fn=get_layer_from_experiment
        )

        # --- Initialize Visualization Processor ---
        self.visualization_processor = VisualizationProcessor(
            experiment=self.experiment,
            model=self.model,
            explain_fn=self.explain,
            forward_fn=self.forward,
            device=self.device,  # Use Lightning's device directly
            grid_pg_processor=self.grid_pg_processor
        )
        
        log_new_section("Model and processors setup complete", logger=log)
        
        self.log_model_architecture()
        self.log_model_parameters()
    
    
    # @rank_zero_only
    # def _setup_terminal_capture(self):
    #     """
    #     Capture print statements from rank 0 and redirect them to W&B.
    #     Only runs on rank 0 to avoid duplicate logging in distributed training.
    #     """
    #     import sys
    #     from io import StringIO
        
    #     if not hasattr(self, '_original_stdout'):
    #         self._original_stdout = sys.stdout
    #         self._captured_output = StringIO()
            
    #         class TeeOutput:
    #             def __init__(self, original, captured, lightning_module):
    #                 self.original = original
    #                 self.captured = captured  
    #                 self.lightning_module = lightning_module
                
    #             def write(self, text):
    #                 # Write to original stdout (terminal)
    #                 self.original.write(text)
    #                 self.original.flush()
                    
    #                 # Also capture for W&B (only non-empty, meaningful text)
    #                 if text.strip() and not text.isspace():
    #                     try:
    #                         # Direct W&B logging without wb_log helper
    #                         lm = self.lightning_module
    #                         if hasattr(lm, 'logger') and lm.logger and hasattr(lm.logger, 'experiment'):
    #                             lm.logger.experiment.log({
    #                                 "log/terminal": f"Terminal: {text.strip()}",
    #                                 "trainer/global_step": lm.global_step
    #                             })
    #                     except:
    #                         pass  # Silently ignore W&B logging errors
                
    #             def flush(self):
    #                 self.original.flush()
                    
    #             def __getattr__(self, name):
    #                 return getattr(self.original, name)
            
    #         # Only redirect if we have a working W&B logger
    #         if self.logger and hasattr(self.logger, 'experiment'):
    #             sys.stdout = TeeOutput(self._original_stdout, self._captured_output, self)
    
    def configure_model(self):

        self.model = self.model.to(self.experiment.model_precision)
        # Usage in your model creation:
        if self.experiment.use_gradient_checkpointing:
            self.model = apply_gradient_checkpointing(self.model, FeedForward)
            
        if self.experiment.compile:
            self.model = torch.compile(
                self.model, 
                mode=self.experiment.compile_mode, 
                fullgraph=self.experiment.compile_fullgraph, 
                dynamic=self.experiment.compile_dynamic,
            )
    
    # def on_fit_start(self):
        
    #     log.info("Running B-COS sanity check on_fit_start...") # Good to log!
    #     test_bcos_model(self.model, self.device)
    #     log.info("B-COS sanity check complete. Zeroing gradients before actual training.")

    #     # Get the optimizer(s) configured in configure_optimizers() (probably unecessary but safety first)
    #     optimizers = self.optimizers()
    #     if not isinstance(optimizers, list):
    #         optimizers = [optimizers]

    #     for opt in optimizers:
    #         if opt is not None: # Check if optimizer exists
    #             opt.zero_grad()
    
    @rank_zero_only
    def on_fit_end(self):
        self.eval()  # Ensure model is in eval mode
        failed = 0
        for i in range(5):
            log.info(f"Running B-COS sanity check on_fit_end, iteration {i+1}...")
            # Test the model with the current device and num_classes
            # This will also log the results to W&B if available
            try:
                test_bcos_model(self.model, self.device, num_labels=self.experiment.num_classes)
                log.info(f"✅ B-COS sanity check iteration {i+1} passed")
            except Exception as e:
                raise e
                log.error(f"❌ Error during B-COS sanity check on_fit_end: {e}")
                failed = failed + 1
        if failed:
            raise RuntimeError(f"B-COS sanity check failed {failed} times. Please check your model configuration.")

        super().on_fit_end()
        
    
    # def on_train_epoch_start(self):
    #     self.frozen_parameters_sanity_check()
    #     test_bcos_model(self.model, self.device)
    #     return super().on_train_epoch_start()

    # def on_validation_epoch_start(self):
    #     # Generate the high-confidence GridPG dataset before each validation epoch
    #     # Assumes confidence_threshold is available in the experiment config
    #     confidence_threshold = self.experiment.confidence_threshold # Use a default if not in config
    #     if hasattr(self.trainer, 'datamodule') and hasattr(self.trainer.datamodule, 'generate_high_confidence_gridpg_dataset'):
    #         self.trainer.datamodule.generate_high_confidence_gridpg_dataset(self, confidence_threshold)
    #         # Check if pg_set_val exists and is not None before getting its length
    #         if hasattr(self.trainer.datamodule, 'pg_set_val') and self.trainer.datamodule.pg_set_val is not None:
    #             self.log("val_pg_samples", len(self.trainer.datamodule.pg_set_val), on_epoch=True, logger=True)
    #         else:
    #             self.log("val_pg_samples", 0, on_epoch=True, logger=True)
            
    #     else:
    #         # Log a warning if the datamodule or method is not found
    #         warnings.warn("DataModule or generate_high_confidence_gridpg_dataset method not found. Dynamic dataset generation skipped.")

    @property
    def base_model(self) -> nn.Module:
        """Returns the base model, which is the model without any modifications."""
        if self.model_factory is None:
            raise RuntimeError("Model factory not initialized. Make sure setup() has been called.")
        return self.model_factory.base_model

    @property
    def name_mapping_registry(self):
        """Returns the name mapping registry if available"""
        if self.model_factory is None:
            return None
        return self.model_factory.name_mapping_registry

    def get_original_parameter_names(self, wrapped_names: set) -> set:
        """Convert wrapped parameter names back to original names"""
        if self.name_mapping_registry is None:
            return wrapped_names
        
        original_names = set()
        for wrapped_name in wrapped_names:
            original_name = self.name_mapping_registry.get_original_name(wrapped_name)
            original_names.add(original_name)
        return original_names

    def get_wrapped_parameter_names(self, original_names: set) -> set:
        """Convert original parameter names to wrapped names"""
        if self.name_mapping_registry is None:
            return original_names
        
        wrapped_names = set()
        for original_name in original_names:
            wrapped_name = self.name_mapping_registry.get_current_name(original_name)
            wrapped_names.add(wrapped_name)
        return wrapped_names

    @rank_zero_only
    def log_model_architecture(self):
        log.info("--- Model Architecture without Trainability ---")
        log.info(self.model)
        log.info("--- Model Architecture with Trainability ---")
        # Check if the model is a compiled module and log the original module if it is
        model_to_log = self.model
        if hasattr(self.model, '_orig_mod'):
            log.info("Logging original module architecture (model is compiled).")
            model_to_log = self.model._orig_mod

        # Ensure we have a proper nn.Module
        model_to_log = cast(nn.Module, model_to_log)

        # Log model architecture overview to W&B if available
        if self.logger and hasattr(self.logger, 'experiment'):
            self.logger.experiment.log({
                "log/info": "--- Model Architecture Overview ---",
                "trainer/global_step": self.global_step
            })
        
        # Log model architecture with trainability information
        self._log_model_with_trainability(model_to_log)
        
        # Add summary of trainable parameters
        total_params = sum(p.numel() for p in model_to_log.parameters())
        trainable_params = sum(p.numel() for p in model_to_log.parameters() if p.requires_grad)
        frozen_params = total_params - trainable_params
        
        log.info("--- Trainability Summary ---")
        log.info(f"Total Parameters: {self._format_param_count(total_params)}")
        log.info(f"Trainable Parameters: {self._format_param_count(trainable_params)} ({100*trainable_params/total_params:.1f}%)")
        log.info(f"Frozen Parameters: {self._format_param_count(frozen_params)} ({100*frozen_params/total_params:.1f}%)")
        
        # self.model = self.model.eval()
        #summary(self.model, depth=7)#, input_size=(self.experiment.batch_size, 6, 224, 224))  
            # rand_input = torch.randn((1, 6, 224, 224), requires_grad=False, dtype=torch.float32)
            # out = self.model(rand_input)

        log.info("------------------------")

    def _log_model_with_trainability(self, model: nn.Module, prefix="", depth=0, max_depth=6):
        """
        Log model architecture with trainability indicators (compact version).
        
        Args:
            model: The model or module to log
            prefix: Prefix for indentation
            depth: Current depth in the model hierarchy
            max_depth: Maximum depth to traverse
        """
        # Get module info
        module_name = model.__class__.__name__
        
        # Count trainable and total parameters in this module (including children)
        total_params_recursive = sum(p.numel() for p in model.parameters())
        trainable_params_recursive = sum(p.numel() for p in model.parameters() if p.requires_grad)
        
        # Count direct parameters (not including children)
        total_params_direct = sum(p.numel() for p in model.parameters(recurse=False))
        trainable_params_direct = sum(p.numel() for p in model.parameters(recurse=False) if p.requires_grad)
        
        # Skip modules without parameters and basic containers unless they're important
        skip_no_params = total_params_recursive == 0 and module_name not in ['Attention', 'FeedForward', 'Encoder', 'Transformer']
        
        # Determine trainability status for display (simplified)
        if total_params_recursive == 0:
            if skip_no_params:
                return  # Skip logging empty modules
            train_status = ""
            param_info = ""
        elif trainable_params_recursive == 0:
            train_status = " [FROZEN]"
            param_info = self._format_param_count(total_params_recursive)
        elif trainable_params_recursive == total_params_recursive:
            train_status = " [TRAINABLE]" 
            param_info = self._format_param_count(total_params_recursive)
        else:
            # Show ratio for mixed modules
            ratio = f"{trainable_params_recursive/1e6:.1f}M/{total_params_recursive/1e6:.1f}M"
            train_status = f" [MIXED: {ratio}]"
            param_info = ""
        
        # For leaf modules with direct parameters, show simpler status
        if total_params_direct > 0:
            if trainable_params_direct == 0:
                train_status = " [FROZEN]"
            elif trainable_params_direct == total_params_direct:
                train_status = " [TRAINABLE]"
            else:
                train_status = f" [PARTIAL]"
            param_info = self._format_param_count(total_params_direct)
        
        # Log this module
        log.info(f"{prefix}{module_name}{train_status}{param_info}")
        
        # Recursively log children if within depth limit
        if depth < max_depth:
            children = list(model.named_children())
            for name, child in children:
                child_prefix = prefix + "|  "
                
                # Show LoRA adapter details more compactly
                if 'lora' in name.lower():
                    # For LoRA modules, show key info in one line
                    child_total = sum(p.numel() for p in child.parameters())
                    child_trainable = sum(p.numel() for p in child.parameters() if p.requires_grad)
                    if child_trainable > 0:
                        status = "TRAINABLE" if child_trainable == child_total else "MIXED"
                        log.info(f"{child_prefix}({name}) LoRA [{status}] {self._format_param_count(child_total)}")
                    continue
                
                # Show names for important modules only
                show_name = any(key in name.lower() for key in ['attention', 'mlp', 'norm', 'embed', 'qkv', 'out'])
                if show_name:
                    log.info(f"{child_prefix}({name})")
                    child_prefix += "  "
                
                self._log_model_with_trainability(child, child_prefix, depth + 1, max_depth)
    
    def _format_param_count(self, param_count: int) -> str:
        """Format parameter count for display."""
        if param_count >= 1e6:
            return f" ({param_count/1e6:.1f}M params)"
        elif param_count >= 1e3:
            return f" ({param_count/1e3:.1f}K params)"
        else:
            return f" ({param_count} params)"

    @rank_zero_only 
    def log_model_parameters(self):
        # Use ModelFactory to get parameter counts

        # Convert parameter counts to millions with two decimal places
        total_params_m = self.total_params / 1e6
        trainable_params_m = self.trainable_params / 1e6
        non_trainable_params_m = (self.total_params - self.trainable_params) / 1e6

        # Log parameter counts to wandb
        self.logger.experiment.config.update({
            "model_total_params": total_params_m,
            "model_trainable_params": trainable_params_m,
            "model_non_trainable_params": non_trainable_params_m
        })

        #self.model_factory._log_detailed_freezing_status()
    
    def frozen_parameters_sanity_check(self):
        """
        Checks if the frozen parameters are actually frozen.
        Raises an exception if any frozen parameter is not frozen.
        """
        if self.model_factory is None:
            return  # Skip check if model not initialized yet

        total_params, trainable_params = self.get_total_parameter_count(), self.get_trainable_parameter_count()
        assert self.total_params == total_params, f"Total parameters changed during training: {self.total_params} != {total_params}"
        assert self.trainable_params == trainable_params, f"Trainable parameters changed during training: {self.trainable_params} != {trainable_params}"


    # Legacy methods removed - ModelFactory handles all parameter loading and state dict operations
    # The following methods have been moved to ModelFactory:
    # - filter_state_dict
    # - get_pretrained_statedict  
    # - get_pretrained_model
    # - rename_state_dict_torchhub_resnet
    # - rename_state_dict_pytorch_vit
    # - replace_convolution_by_6_channel
    # - replace_to_patch_embedding_by_6_channels
    # - load_params_from_checkpoint
    # - check_if_valid_and_add



    # Legacy freezing methods removed - ModelFactory handles all freezing operations
    # The following methods have been moved to ModelFactory:
    # - freeze_parameters_and_set_to_eval_from_names
    # - validate_frozen_parameters
    # - validate_module_eval_mode
    # - convert_name_based_to_object_based_freezing
    # - freeze_parameters_by_original_names
    # - freeze_modules_by_original_names

    def _compute_grad_norm(self, optimizer):
        """Compute the total gradient norm for all parameters in the optimizer."""
        norms = []
        for g in optimizer.param_groups:
            for p in g["params"]:
                if p.grad is not None:
                    # Explicitly detach and clone to prevent memory accumulation
                    norm = p.grad.detach().clone().norm(2)
                    norms.append(norm)
        if not norms:
            return torch.tensor(0.0, device=self.device, dtype=torch.float32)
        
        # Compute total norm and immediately detach to break any remaining graph connections
        total_norm = torch.norm(torch.stack(norms), 2).detach()
        
        # Clean up intermediate tensors
        del norms
        
        return total_norm

    def on_before_optimizer_step(self, optimizer):
        # Compute pre-clip gradient norm (before gradient clipping)
        grad_norm = self._compute_grad_norm(optimizer)
        # self.grad_norm_preclip_metric.update(grad_norm.item())  # Use .item() to extract scalar value
        self.log("grad_norm_preclip", grad_norm, on_step=False, on_epoch=True, sync_dist=True, logger=True)
        
        # Clean up
        del grad_norm

    def on_after_optimizer_step(self, optimizer):
        # Compute post-clip gradient norm
        grad_norm = self._compute_grad_norm(optimizer)
        # self.grad_norm_postclip_metric.update(grad_norm.item())  # Use .item() to extract scalar value
        self.log("grad_norm_postclip", grad_norm, on_step=False, on_epoch=True, sync_dist=True, logger=True)
        
        # Clean up
        del grad_norm

    
    def train(self, mode: bool = True):
        """
        Override to ensure our frozen parameters (and BatchNorm evals) are reapplied
        immediately after train(mode) toggles all submodules back to train().
        """
        # 1) switch entire model into train() / eval() per mode
        super().train(mode)

        # 2) if entering train mode, re-apply freezing via ModelFactory (if available)
        if mode and self.experiment.freeze_pretrained_weights and self.model_factory is not None:
            self.model_factory.apply_train_mode_freezing()
        return self

    
    def forward(self, x):
        logits = self.model(x)
        # Skip unnecessary max computation that's not used
        # pred_max, pred_index = torch.max(logits, dim=1)
        # print(f"Pred max is {pred_max} with index {pred_index} ")
        return logits
    
    def _unpack_batch(self, batch):
        """Supports batches as tuple/list (inputs, targets) or dict with common keys."""
        if isinstance(batch, dict):
            x = batch.get("image")
            y = batch.get("label")
            if x is None or y is None:
                raise ValueError("Batch dict missing 'image'/'label' (or aliases) keys")
            return x, y
        if isinstance(batch, (tuple, list)):
            if len(batch) >= 2:
                return batch[0], batch[1]
        raise TypeError(f"Unsupported batch type: {type(batch)}")
                                         
    def _common_step(self, batch, batch_idx):
        '''
        Common step for both training and validation. Calculates loss and predictions.
        '''
        inputs, targets = self._unpack_batch(batch)
        logits = self.forward(inputs)
        loss = self.criterion(logits, targets)
        
        preds = self._get_preds(logits)
                    
        return loss, preds, targets
    
    def _get_preds(self, logits: torch.Tensor):
        return torch.argmax(logits, dim=1)

    def sam_step(self, batch, batch_idx):
        '''
        SAM step for training with improved memory management.
        '''
        optimizer = self.optimizers()
        
        # Handle both single optimizer and list of optimizers
        if isinstance(optimizer, list):
            optimizer = optimizer[0]

        assert isinstance(optimizer, SAM), "Optimizer must be an instance of SAM for SAM step."

        # first forward-backward pass
        loss1, preds1, targets1 = self._common_step(batch, batch_idx)
        self.manual_backward(loss1)
        optimizer.first_step(zero_grad=True)
        
        # Clear intermediate tensors to prevent memory leak
        del loss1, preds1, targets1  # Release first pass tensors
        if torch.cuda.is_available() and CLEAN_CACHE:
            torch.cuda.empty_cache()

        # second forward-backward pass
        loss2, preds2, targets2 = self._common_step(batch, batch_idx)
        self.manual_backward(loss2)
        optimizer.second_step(zero_grad=True)

        # For SAM (manual optimization), we can detach since gradients are handled manually
        # This helps prevent memory accumulation after manual backward passes
        loss_detached = loss2.detach() if hasattr(loss2, 'detach') else loss2
        preds_detached = preds2.detach() if hasattr(preds2, 'detach') else preds2  
        targets_detached = targets2.detach() if hasattr(targets2, 'detach') else targets2

        # Clean up original tensors
        del loss2, preds2, targets2

        return loss_detached, preds_detached, targets_detached



    def training_step(self, batch, batch_idx):

        if self.use_sam:
            loss, preds, targets = self.sam_step(batch, batch_idx)
        else:
            loss, preds, targets = self._common_step(batch, batch_idx)
            
        # Create detached copies for logging only (don't modify the original loss)
        loss_for_logging = loss.detach() if hasattr(loss, 'detach') else loss
        preds_for_metrics = preds.detach() if hasattr(preds, 'detach') else preds
        targets_for_metrics = targets.detach() if hasattr(targets, 'detach') else targets

        # Compute metrics with detached tensors
        metrics = self.train_metrics(preds_for_metrics, targets_for_metrics)

        # Log loss and accuracy for training
        self.log("train_loss", loss_for_logging, on_step=False, on_epoch=True, logger=True, sync_dist=True, prog_bar=False)
        self.log_dict(metrics, on_step=False, on_epoch=True, logger=True, sync_dist=True, prog_bar=False)

        # Clean up only the detached copies used for logging
        del loss_for_logging, preds_for_metrics, targets_for_metrics, metrics

        # Return original loss with gradients intact for Lightning's automatic optimization
        return loss


    def on_validation_epoch_start(self):
        '''
        Reset metrics.
        '''
        self.count_grid_samples = 0
        # Reset Grid PG metrics for the new epoch
        self.val_pg_score_metric.reset()
        self.high_confidence_samples_metric.reset()
        
        # Skip cache clearing on APUs - can hurt performance with unified memory
        # if torch.cuda.is_available():
        #     torch.cuda.empty_cache()

    def validation_step(self, batch, batch_idx, dataloader_idx=0):
        # Validation on the standard validation set
        #print(len(batch))
        #raise Exception(f"batch has type {type(batch)} with length {len(batch)}")
        if dataloader_idx == 0:
            loss, preds, targets = self._common_step(batch, batch_idx)
            # print(f"Debug (Validation): targets dtype: {targets.dtype}, min: {targets.min()}, max: {targets.max()}")
            metrics = self.val_metrics(preds.clone(), targets.clone())

            # Log loss and accuracy for validation
            self.log("val_loss", loss, on_step=False, on_epoch=True, logger=True, sync_dist=True, prog_bar=True)
            self.log_dict(metrics, on_step=False, on_epoch=True, logger=True, sync_dist=True, prog_bar=True)
            
            # inputs, targets = self._unpack_batch(batch)
            #for i in range(inputs.shape[0]):
            #self._compute_explanation_cosine_similarity_metric(inputs, idx = targets)
            
            #self.log("val_contribution_score", self.contribution_metric, on_epoch=True, prog_bar = True)
        
        # Validation on the Grid PG dataset 
        elif dataloader_idx == 1:
            if self.grid_pg_processor is None:
                # Return a zero loss if processor not ready
                return torch.tensor(0.0, device=self.device)
                
            inputs, targets = self._unpack_batch(batch)
            
            # Use GridPGProcessor for validation
            total_pg_score, num_confident_samples = self.grid_pg_processor.process_validation_step(inputs, targets)
            
            # Update TorchMetrics - they handle distributed sync and NaN values automatically
            if total_pg_score is None:
                total_pg_score_metric = torch.nan
            else:
                # Detach to prevent memory leaks from gradient accumulation
                total_pg_score_metric = float(total_pg_score)
                
            self.val_pg_score_metric.update(total_pg_score_metric)
            # Note: For MeanMetric with nan_strategy='ignore', we don't need to update with NaN
            # It will automatically ignore missing values from ranks with no confident samples
            
            # Detach sample count to prevent memory issues
            samples_detached = int(num_confident_samples) 
            self.high_confidence_samples_metric.update(samples_detached)
            
            # Log the metrics - TorchMetrics will handle the distributed aggregation
            self.log("val_pg_score", self.val_pg_score_metric, on_step=False, on_epoch=True, logger=True, prog_bar=True)
            self.log("high_confidence_samples", self.high_confidence_samples_metric, on_step=False, on_epoch=True, logger=True, prog_bar=False)

            # Always return a loss tensor for Lightning (use 0.0 when no confident samples)
            loss_value = total_pg_score if total_pg_score is not None else 0.0
            loss = torch.tensor(loss_value, device=self.device)
            
        else:
            raise NotImplementedError("Dataloader index out-of-range")
        
        return loss

    
    def on_train_epoch_end(self):
        # Skip frequent cache clearing on APUs - unified memory architecture makes this less beneficial
        # and can actually hurt performance due to memory bandwidth competition
        # if torch.cuda.is_available():
        #     torch.cuda.empty_cache()
        
        # Reset gradient norm metrics for next epoch
        # self.grad_norm_preclip_metric.reset()
        # self.grad_norm_postclip_metric.reset()
        
        # if self.trainer.world_size > 1:
        #     torch.distributed.barrier()
        return super().on_train_epoch_end()
    
    def on_validation_epoch_end(self):
        """
        Clean up memory after validation epoch completes.
        """
        # Final cleanup after all validation processing is complete
        if torch.cuda.is_available() and CLEAN_CACHE:
            torch.cuda.empty_cache()
        
        return super().on_validation_epoch_end()

    # def _compute_explanation_cosine_similarity_metric(self, data: Tensor, idx: None | int):
    #     ''' 
    #     Computes the cosine similarity between the flattened explanation and image. Both are filtered by the contribution map to suppresso irrelevant parts, i.e. enforce similarity between important parts.
    #     '''

    #     layer = get_layer_from_experiment(self.experiment, self.model)
    #     expl_out: dict = self.explain(data, mode="native", layer = layer, device=str(self.device), explain_class = idx, to_numpy=False) 
    #     #print(expl_out["contribution_map"].shape)
    #     contribution_map: Tensor = expl_out["contribution_map"]
    #     explanation: Tensor = expl_out["explanation"]
        
    #     self.contribution_metric.update(original_image = data.requires_grad_(True), explanation = explanation, contribution_map = contribution_map)
    #     #self.log("train_contribution_score", self.contribution_metric)
    #     return


    def configure_optimizers(self):
        if self.model_factory is None:
            raise RuntimeError("Model factory not initialized. Make sure setup() has been called.")
            
        trainable_params = self.get_trainable_parameters()

        if self.experiment.optimizer.lower() == "AdamW".lower():
            param_dict = {
                "lr": self.experiment.lr,
                "weight_decay": self.experiment.weight_decay
            }
            base_optimizer = optim.AdamW(trainable_params, **param_dict)

        elif self.experiment.optimizer.lower() == "SGD".lower():
            param_dict = {
                "lr": self.experiment.lr,
                "momentum": self.experiment.momentum,
                "weight_decay": self.experiment.weight_decay
            }
            base_optimizer = optim.SGD(trainable_params, **param_dict)
        
        elif self.experiment.optimizer.lower() == "RAdam".lower():
            param_dict = {
                "lr": self.experiment.lr,
                "weight_decay": self.experiment.weight_decay
            }
            base_optimizer = RAdam(trainable_params, **param_dict)
        
        elif self.experiment.optimizer.lower() == "Ranger21".lower():
            param_dict = {
                "lr": self.experiment.lr,
                "weight_decay": self.experiment.weight_decay,
                "agc_clipping_value": self.experiment.agc_clipping_value
            }
            base_optimizer = Ranger21(trainable_params, num_iterations=self.experiment.epochs, **param_dict)
            
        else:
            raise NotImplementedError(f"Optimizer {self.experiment.optimizer} is not implemented.")
        
        if self.experiment.use_sam:
            optimizer_class = base_optimizer.__class__
            optimizer = SAM(
                trainable_params,
                base_optimizer=optimizer_class,
                adaptive=False,  # Changed from True - adaptive SAM is much slower
                **param_dict
            )
            base_optimizer = optimizer.base_optimizer
            self.use_sam = self.experiment.use_sam
        else:
            optimizer = base_optimizer

        # Only use external scheduler for optimizers that don't have built-in scheduling
        # Ranger21 has its own sophisticated scheduling, so we skip external scheduling for it
        if self.experiment.optimizer.lower() == "Ranger21".lower():
            # Ranger21 handles its own learning rate scheduling internally
            return [optimizer]
        else:
            # Use warmup + cosine scheduling for other optimizers
            scheduler = create_warmup_cosine_scheduler(
                optimizer,
                total_epochs=self.experiment.epochs,
                warmup_epochs=self.experiment.warmup_epochs,
                warmup_start_factor=0.01,
                eta_min=0
            )
            return [optimizer], [scheduler]
    
    def _get_metrics(self):
        # --- Metrics ---
        train_accuracy: Metric = torchmetrics.Accuracy(task="multiclass", num_classes=self.experiment.num_classes)
        val_accuracy: Metric = torchmetrics.Accuracy(task="multiclass", num_classes=self.experiment.num_classes)
        #self.contribution_metric: Metric = ContributionMetric(threshold=self.experiment.explanation_metric_threshold)

        # Grid PG metrics - using MeanMetric to handle NaN values properly in distributed training
        self.val_pg_score_metric = torchmetrics.MeanMetric(nan_strategy='ignore')  # Ignores NaN values
        self.high_confidence_samples_metric = torchmetrics.SumMetric()  # Sums across ranks

        # Gradient norm metrics - initialize with a dummy value to avoid warnings
        # self.grad_norm_preclip_metric = torchmetrics.MeanMetric()
        # self.grad_norm_postclip_metric = torchmetrics.MeanMetric()
        
        # Initialize with a dummy value to prevent the "compute before update" warning
        # self.grad_norm_preclip_metric.update(0.0)
        # self.grad_norm_postclip_metric.update(0.0)
        # # Reset immediately to clear the dummy values
        # self.grad_norm_preclip_metric.reset()
        # self.grad_norm_postclip_metric.reset()

        self.train_metrics = torchmetrics.MetricCollection([train_accuracy], postfix="_train")
        self.val_metrics = torchmetrics.MetricCollection([val_accuracy], postfix="_val")
        self.count_grid_samples = 0
    
    def _get_loss(self):
        loss_name = self.experiment.loss
        if loss_name == "CE":
            self.criterion = CrossEntropyLoss()
        elif loss_name == "UniformBCE":
            self.criterion = UniformOffLabelsBCEWithLogitsLoss()
        else:
            raise NotImplementedError("Loss not yet implemented.")

    def explain(self, x: torch.Tensor, mode="native", layer=None, device="cpu", explain_class = None, to_numpy = True, map_size = 1):
        '''
        Computes explanation
        '''
        orig_model = getattr(self.model, '_orig_mod', self.model)

        orig_model.eval()
        orig_model.zero_grad()
        
        if hasattr(orig_model, 'explain'):
            # Apply 3-to-6 channel transformation if efficient_bcos is enabled and input is 3-channel
            if x.shape[1] == 3:
                assert hasattr(orig_model, 'add_inverse'), "Model must have add_inverse method for efficient_bcos explanations"

                x = orig_model.add_inverse(x)
            

            input_x = x.detach().clone()  # Clone input to avoid modifying original tensor
            input_x.requires_grad = True  # Ensure input requires grad for explanation
            

            # map_size = 2 if is_simple_vit(self.model) else 1
            #map_size = 1

            # if mode == "batch":
            #     expl_out = self.batch_explain(x, idx=explain_class, device=device)
            # else:
            expl_out = self.model.explain(input_x, idx=explain_class, to_numpy = to_numpy, map_size = map_size) # type: ignore

        else:
            assert layer != None, "Explain method requires a layer for GradCam"

            with torch.no_grad():
                logits = self.forward(x)
                
            
            if explain_class == None:
                prediction = self._get_preds(logits=logits)
            else:
                prediction = explain_class

            layergradcam = LayerGradCam(orig_model, layer=layer)
            
            # Use clone().detach() to avoid potential side effects
            map = layergradcam.attribute(x.clone().detach(), target=prediction, relu_attributions=True)
            map = F.interpolate(map, size=x.shape[-1], mode="bilinear")
            

            if to_numpy:
                expl_out = {
                    # Move explanation to CPU before returning
                    "prediction": prediction.detach().cpu(),
                    "contribution_map": map.detach().cpu(),
                }

        return expl_out

    def batch_explain(self, in_tensor, idx=None, **grad2img_kwargs):
        """
        Generates an explanation for the given input tensor.
        This is not a generic explanation method, but rather a helper for simply getting explanations.
        It is intended for simple use cases (simple exploration, debugging, etc.).

        Parameters
        ----------
        in_tensor : Tensor
            The input tensor to explain. Must be 4-dimensional and have batch size of 1.
        idx : int, optional
            The index of the output to explain. If None, the prediction is explained.
        grad2img_kwargs : Any
            Additional keyword arguments passed to `gradient_to_image` method
            for generating the explanation.

        Examples
        --------
        Here is an example of how to use this method to generate and visualize an explanation and a contribution map:

        >>> model = ...  # instantiate some B-cos model
        >>> img = ...  # instantiate some input image tensor
        >>> expl_out = model.explain(img)
        >>> expl_out["prediction"]
        932

        >>> import matplotlib.pyplot as plt
        >>> plt.imshow(expl_out["explanation"])
        >>> plt.show()  # show the explanation

        >>> model.plot_contribution_map(expl_out["contribution_map"])
        >>> plt.show()  # show the contribution map

        Warnings
        --------
        This method is NOT optimized for speed.
        Also, on a more general note: Care should be taken when generating explanations during training,
        as the gradients might be different from during inference.
        """
        if in_tensor.ndim == 3:
            raise ValueError("Expected 4-dimensional input tensor")
        if not in_tensor.requires_grad:
            warnings.warn(
                "Input tensor did not require grad! Has been set automatically to True!"
            )
            in_tensor.requires_grad = True  # nonsense otherwise

        result = dict()
        with torch.enable_grad(), self.model.explanation_mode():
            # out has dimensions [B, C] where c are the number of classes
            out = self.model(in_tensor)  # noqa
            pred_out = out.max(1)
            # result["prediction"] = pred_out.indices

            # select output (logit) to explain
            if idx is None:  # explain prediction
                to_be_explained_logit = pred_out.values
                result["explained_class_idx"] = pred_out
            else:  # user specified idx
                # For each sample in batch get the correct logit
                idx = idx.unsqueeze(1)
                to_be_explained_logit = torch.gather(out, dim=1, index=idx)
                result["explained_class_idx"] = idx
            
            result["predictions"] = pred_out
            
            gradient = torch.ones_like(to_be_explained_logit, device=to_be_explained_logit.device) # Ensure gradient is on same device
            # Calculate gradients of the selected logits w.r.t. the input tensor

            # Inside your batch_explain method, before the .backward() call:


            to_be_explained_logit.backward(inputs=[in_tensor], gradient=gradient)

            # to_be_explained_logit.backward(inputs=[in_tensor])

            # get weights and contribution map
            result["dynamic_linear_weights"] = in_tensor.grad
            result["contribution_map"] = (in_tensor * in_tensor.grad).sum(1).unsqueeze(1)
            #print(f"DEBUG: Contribution map shape: {result['contribution_map'].shape}")
            # generate (color) explanation
            # result["explanation"] = self.model.gradient_to_image(
            #     in_tensor[0], in_tensor.grad[0], **grad2img_kwargs
            # )

        return result

    @rank_zero_only
    def _log_contribution_images(self):
        """
        Generate and log contribution images using VisualizationProcessor.
        """
        if self.visualization_processor is None:
            return  # Skip if processor not ready
            
        self.visualization_processor.log_contribution_images(
            trainer=self.trainer,
            logger=self.logger,
            current_epoch=self.current_epoch
        )


    def predict(self, x):
        logits = self.forward(x)
        return self._get_preds(logits)

    # Delegation methods for advanced freezing functionality
    def freeze_by_group(self, group_name: str):
        """Freeze all modules in a specific group (delegates to ModelFactory)"""
        if self.model_factory is None:
            raise RuntimeError("Model factory not initialized. Make sure setup() has been called.")
        return self.model_factory.freeze_by_group(group_name)
    
    def freeze_by_pattern(self, pattern: str):
        """Freeze modules whose names match a pattern (delegates to ModelFactory)"""
        if self.model_factory is None:
            raise RuntimeError("Model factory not initialized. Make sure setup() has been called.")
        return self.model_factory.freeze_by_pattern(pattern)
    
    def unfreeze_all(self):
        """Unfreeze all parameters (delegates to ModelFactory)"""
        if self.model_factory is None:
            raise RuntimeError("Model factory not initialized. Make sure setup() has been called.")
        return self.model_factory.unfreeze_all()

    def get_trainable_parameters(self) -> List[torch.nn.Parameter]:
        assert self.model is not None, "Model must be created before getting parameters"
        return [p for p in self.model.parameters() if p.requires_grad]

    def get_total_parameters(self) -> List[torch.nn.Parameter]:
        assert self.model is not None, "Model must be created before getting parameters"
        return [p for p in self.model.parameters()]
    
    def get_trainable_parameter_count(self) -> int:
        """
        Returns the number of trainable parameters in the model.
        """
        trainable_params = self.get_trainable_parameters()
        return sum(p.numel() for p in trainable_params)
    
    def get_total_parameter_count(self) -> int:
        """
        Returns the total number of parameters in the model.
        """
        total_params = self.get_total_parameters()
        return sum(p.numel() for p in total_params)