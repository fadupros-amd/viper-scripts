# model_factory.py
from peft import PeftModel
import torch
import torch.nn as nn
import torchvision
from typing import Optional, Dict, Any, Set, List
from functools import partial
from collections import OrderedDict
import warnings

from transformers import ViTForImageClassification

from experiment.experiment import Experiment
from models.bcos_wrapper import BcosWrapper
from models.hf_vit_for_classification_wrapper import HFViTForClassificationWrapper
from models.imagenet_model_wrapper import ImagenetWrapper
from models.utils import get_act_layer, get_linear_layer, get_norm
from modules.adapters.lora_modifier import apply_lora_to_model, LoRAConfig
from modules.adapters.modifier_base import ModelModifierBase
from models.bcos_resnet import BcosResnet50_bottleneck, bcosresnet50_bottleneck
from bcos.models.resnet import resnet50 as bcosresnet50
from models.bcos_vit import SimpleViT, apply_gradient_checkpointing, bcos_vit
from modules.utils import double_conv_input_channels, double_conv_input_channels_then_convert_to_linear
from models.utils import log_new_section
import logging

class ModelFactory:
    """Factory class for creating, modifying, and managing models with freezing capabilities"""
    
    def __init__(self, experiment: Experiment, log: Optional[logging.Logger]  = None):
        self.experiment = experiment
        self.log = log 
        self.model: Optional[nn.Module] = None
        
        
    def create_model(self) -> nn.Module:
        """Create and fully configure the model according to experiment settings"""
        log_new_section("Creating model with ModelFactory", logger=self.log)
        
        # Step 1: Create base model
        self.model = self._get_pretrained_model()

        if self._is_vit():
            # if isinstance(self.model, ViTForImageClassification):
            vit_conv_stem_norm_layer = get_norm(self.experiment.vit_conv_stem_norm_layer)
            self.model = HFViTForClassificationWrapper.create_vit_wrapper(self.model, b_linear=self.experiment.b, b_classifier=self.experiment.b_classifier, b_conv2d=self.experiment.b, add_conv_stem=self.experiment.vit_conv_stem, conv_stem_norm_layer=vit_conv_stem_norm_layer) 
            # else: # TODO
                # raise NotImplementedError("Only HuggingFace ViT models are currently supported in this factory.")
        else:
            raise NotImplementedError("Only ViT models are currently supported in this factory.")
        
        # Apply PEFT if requested
        if self.experiment.use_peft:
            self.model = self._apply_peft_to_model(self.model)
        
        # Step 7: Log final model status
        self._log_model_creation_summary()
        
        self.log.info("Model creation and configuration complete")
        return self.model
    

    def _apply_peft_to_model(self, model: nn.Module) -> nn.Module:
        """Apply HuggingFace PEFT adapters to the entire model."""
        try:
            from peft import get_peft_model, LoraConfig, AdaLoraConfig, PromptEncoderConfig, PromptTuningConfig, ShiraConfig, PrefixTuningConfig
            
            # Try to import VeRA
            try:
                from peft import VeraConfig
            except ImportError:
                try:
                    from peft.tuners.vera import VeraConfig
                except ImportError:
                    VeraConfig = None
                    if self.log:
                        self.log.warning("VeraConfig not available in this PEFT version. Please update PEFT for VeRA support.")
            
            # Try to import RandLoRA
            try:
                from peft import LoKrConfig  # RandLoRA is implemented as LoKrConfig in PEFT
            except ImportError:
                try:
                    from peft.tuners.lokr import LoKrConfig
                except ImportError:
                    LoKrConfig = None
                    if self.log:
                        self.log.warning("LoKrConfig (RandLoRA) not available in this PEFT version. Please update PEFT for RandLoRA support.")
            
            # Try to import FourierFT
            try:
                from peft import FourierFTConfig
            except ImportError:
                try:
                    from peft.tuners.fourierft import FourierFTConfig
                except ImportError:
                    FourierFTConfig = None
                    if self.log:
                        self.log.warning("FourierFTConfig not available in this PEFT version. Please update PEFT for FourierFT support.")
                        
        except ImportError:
            raise ImportError("You must install the 'peft' library to use PEFT adapters. Run 'pip install peft transformers'.")
        
        if self.experiment.peft_config is None or 'strategy' not in self.experiment.peft_config:
            raise ValueError("If use_peft=True, you must provide a peft_config dict with a 'strategy' key.")
        
        strategy = self.experiment.peft_config['strategy']
        config_kwargs = {k: v for k, v in self.experiment.peft_config.items() if k != 'strategy'}
        
        # Map string to config class
        config_map = {
            'LoraConfig': LoraConfig,
            'AdaLoraConfig': AdaLoraConfig,
            'PromptEncoderConfig': PromptEncoderConfig,
            'PromptTuningConfig': PromptTuningConfig,
            "ShiraConfig": ShiraConfig,
            "PrefixTuningConfig": PrefixTuningConfig,
        }
        
        # Add Shira if available
        if ShiraConfig is not None:
            config_map['ShiraConfig'] = ShiraConfig
            
        # Add VeRA if available
        if VeraConfig is not None:
            config_map['VeraConfig'] = VeraConfig
            
        # Add RandLoRA (LoKr) if available
        if LoKrConfig is not None:
            config_map['LoKrConfig'] = LoKrConfig
            config_map['RandLoRAConfig'] = LoKrConfig  # Alias for easier usage
            
        # Add FourierFT if available
        if FourierFTConfig is not None:
            config_map['FourierFTConfig'] = FourierFTConfig
        
        if strategy not in config_map:
            raise ValueError(f"Unknown PEFT strategy: {strategy}. Supported: {list(config_map.keys())}")
        
        # Handle structured Shira masks
        if strategy == "ShiraConfig" and 'mask_type' in config_kwargs:
            mask_type = config_kwargs.get('mask_type', 'random')
            if mask_type != 'random':
                # Import structured mask functions
                try:
                    from models.structured_shira_masks import get_structured_mask_function
                    
                    # Get the structured mask function
                    structured_mask_fn = get_structured_mask_function(mask_type)
                    
                    # Create the config without mask_type (not a valid ShiraConfig parameter)
                    shira_kwargs = {k: v for k, v in config_kwargs.items() if k != 'mask_type'}
                    peft_cfg = config_map[strategy](**shira_kwargs)
                    
                    # Set the custom mask function
                    peft_cfg.mask_fn = structured_mask_fn
                    
                    if self.log:
                        self.log.info(f"Using structured Shira mask: {mask_type}")
                    
                except ImportError as e:
                    if self.log:
                        self.log.warning(f"Failed to import structured mask functions: {e}. Falling back to random mask.")
                    peft_cfg = config_map[strategy](**config_kwargs)
                except Exception as e:
                    if self.log:
                        self.log.warning(f"Failed to setup structured mask '{mask_type}': {e}. Falling back to random mask.")
                    peft_cfg = config_map[strategy](**config_kwargs)
            else:
                peft_cfg = config_map[strategy](**config_kwargs)
        else:
            peft_cfg = config_map[strategy](**config_kwargs)
        
        if self.log:
            self.log.info(f"Applying PEFT strategy: {strategy}")
            if 'target_modules' in config_kwargs:
                self.log.info(f"Target modules: {config_kwargs['target_modules']}")
        
        # Add a minimal config attribute if the model doesn't have one (required by PEFT)
        if not hasattr(model, 'config'):
            # Create a config class that behaves like both a namespace and a dictionary
            class ModelConfig:
                def __init__(self, **kwargs):
                    for key, value in kwargs.items():
                        setattr(self, key, value)
                        
                def get(self, key, default=None):
                    return getattr(self, key, default)
                    
                def __getitem__(self, key):
                    return getattr(self, key)
                    
                def __setitem__(self, key, value):
                    setattr(self, key, value)
                    
                def __contains__(self, key):
                    return hasattr(self, key)
            
            # Create a minimal config that PEFT can use
            model.config = ModelConfig(
                model_type="custom_vit" if hasattr(model, 'transformer') else "custom",
                hidden_size=getattr(model, 'patch_dim', 768),  # Try to get patch_dim, default to 768
                num_attention_heads=getattr(model, 'heads', 12),  # Try to get heads, default to 12
                num_hidden_layers=getattr(model, 'depth', 12),  # Try to get depth, default to 12
            )
            if self.log:
                self.log.info("Added minimal config attribute to model for PEFT compatibility")
        
        try:
            model = get_peft_model(model, peft_cfg)
            if self.log:
                self.log.info("PEFT applied successfully")
        except Exception as e:
            error_msg = f"Failed to apply PEFT to model: {e}"
            if self.log:
                self.log.error(error_msg)
            raise RuntimeError(error_msg)
        
        return model
    
    def _log_model_creation_summary(self):
        """Log summary of model creation including architecture and initial status"""
        log_new_section("Model Creation Summary", logger=self.log)
        
        # Log basic model information
        total_params = sum(p.numel() for p in self.model.parameters())
        trainable_params = sum(p.numel() for p in self.model.parameters() if p.requires_grad)
        
        self.log.info(f"Model Architecture: {self.experiment.model}")
        self.log.info(f"Total parameters: {total_params:,}")
        self.log.info(f"Trainable parameters: {trainable_params:,}")
        self.log.info(f"Frozen parameters: {total_params - trainable_params:,}")
        
        # Log whether weights were loaded
        if self.experiment.pretrained_weights:
            self.log.info(f"Pretrained weights loaded from: {self.experiment.pretrained_weights}")
        else:
            self.log.info("No pretrained weights loaded (training from scratch)")
        
        # Log freezing configuration
        if self.experiment.freeze_pretrained_weights:
            self.log.info("Pretrained weight freezing is ENABLED")
        else:
            self.log.info("Pretrained weight freezing is DISABLED")
        
        # Log modification information
        if self.experiment.use_lora:
            self.log.info(f"LoRA modification applied with rank {self.experiment.lora_rank}")
         # Log compilation status
        if self.experiment.compile:
            self.log.info(f"Model compiled with mode: {self.experiment.compile_mode}")
        else:
            self.log.info("Model compilation disabled")
    
        
    
    
    def _get_pretrained_model(self, verbose: bool = False) -> nn.Module:
        """Load pretrained model from checkpoint or hub"""
        model_reference = self.experiment.pretrained_weights.split("#")
        try:
            repo, name, weights = model_reference
        except:
            repo, name = model_reference
            weights = None

        
        try:
            if repo.lower() == "pytorch_builtin":
                model = torchvision.models.__dict__[name](weights=weights)
            elif repo.lower() == "hf" or repo.lower() == "huggingface":
                # Load HuggingFace model using our utility
                model = self._get_hf_vit_for_classification(name)
            else:
                model = torch.hub.load(repo, name, pretrained=True)


            if verbose:
                self.log.info(f"Loaded model {name} from torch hub repo {repo}")

        except Exception as e:
            raise Exception(f"Model {name} could not be loaded from repo {repo}.") from e
        
        if hasattr(model, "_orig_mod"):
            # If the model is wrapped, get the original module
            model = model._orig_mod
                   
        return model
        
    def _get_hf_vit_for_classification(self, name):
        try:
            from transformers import ViTForImageClassification
            # from models.hf_vit import ViTForImageClassification
        except ImportError:
            raise ImportError("transformers required: pip install transformers")
        
        model = ViTForImageClassification.from_pretrained(name)
        
        return model

    def _is_vit(self) -> bool:
        """Check if the model is a ViT model"""
        model = self.model
        return hasattr(model, 'patch_dim') or hasattr(model, 'transformer') or isinstance(model, SimpleViT) or "vit" in self.experiment.pretrained_weights


    # def _log_module_loading_status(self, trained_state_dict: Dict[str, torch.Tensor],
    #                                missing_keys: List[str], unexpected_keys: List[str]):
    #     """Log detailed information about which modules were loaded from pretrained weights"""
    #     log_new_section("Module Loading Status Report", logger=self.log)
        
    #     # Get all model parameter names
    #     model_param_names = set(dict(self.model.named_parameters()).keys())
    #     loaded_param_names = set(trained_state_dict.keys())
        
    #     # Calculate loaded parameters
    #     actually_loaded = model_param_names.intersection(loaded_param_names)
        
    #     self.log.info(f"Parameter Loading Summary:")
    #     self.log.info(f"  Total model parameters: {len(model_param_names)}")
    #     self.log.info(f"  Pretrained parameters available: {len(loaded_param_names)}")
    #     self.log.info(f"  Successfully loaded parameters: {len(actually_loaded)}")
    #     self.log.info(f"  Missing parameters: {len(missing_keys)}")
    #     self.log.info(f"  Unexpected parameters: {len(unexpected_keys)}")
        
    #     # Group loaded parameters by module
    #     loaded_modules = {}
    #     for param_name in actually_loaded:
    #         module_name = '.'.join(param_name.split('.')[:-1])  # Remove parameter name
    #         if module_name not in loaded_modules:
    #             loaded_modules[module_name] = []
    #         loaded_modules[module_name].append(param_name.split('.')[-1])  # Just parameter name
        
    #     # Log loaded modules
    #     if loaded_modules:
    #         self.log.info(f"Loaded modules ({len(loaded_modules)} modules):")
    #         for module_name, params in sorted(loaded_modules.items()):
    #             if module_name:  # Skip empty module names
    #                 self.log.info(f"  {module_name}: {params}")
        
    #     # Log missing keys with module grouping
    #     if missing_keys:
    #         self.log.info(f"Missing parameters ({len(missing_keys)} total):")
    #         missing_modules = {}
    #         for key in missing_keys:
    #             module_name = '.'.join(key.split('.')[:-1])
    #             if module_name not in missing_modules:
    #                 missing_modules[module_name] = []
    #             missing_modules[module_name].append(key.split('.')[-1])
            
    #         for module_name, params in sorted(missing_modules.items()):
    #             if module_name:
    #                 self.log.info(f"  {module_name}: {params}")
        
    #     # Log unexpected keys with module grouping
    #     if unexpected_keys:
    #         self.log.info(f"Unexpected parameters ({len(unexpected_keys)} total):")
    #         unexpected_modules = {}
    #         for key in unexpected_keys:
    #             module_name = '.'.join(key.split('.')[:-1])
    #             if module_name not in unexpected_modules:
    #                 unexpected_modules[module_name] = []
    #             unexpected_modules[module_name].append(key.split('.')[-1])
            
    #         for module_name, params in sorted(unexpected_modules.items()):
    #             if module_name:
    #                 self.log.info(f"  {module_name}: {params}")
