# model_factory.py
from peft import PeftModel
import torch
import torch.nn as nn
import torchvision
from typing import Optional, Dict, Any, Set, List
from functools import partial
from collections import OrderedDict
import warnings

from experiment.experiment import Experiment
from models.imagenet_model_wrapper import ImagenetWrapper
from models.utils import get_act_layer, get_linear_layer
from modules.adapters.lora_modifier import apply_lora_to_model, LoRAConfig
from modules.adapters.modifier_base import ModelModifierBase
from models.bcos_resnet import BcosResnet50_bottleneck, bcosresnet50_bottleneck
from bcos.models.resnet import resnet50 as bcosresnet50
from models.bcos_vit import SimpleViT, apply_gradient_checkpointing, bcos_vit
from modules.utils import double_conv_input_channels, double_conv_input_channels_then_convert_to_linear
from models.utils import log_new_section
import logging

class ModelFactoryLegacy:
    """Factory class for creating, modifying, and managing models with freezing capabilities"""
    
    def __init__(self, experiment: Experiment, log: Optional[logging.Logger]  = None):
        self.experiment = experiment
        self.log = log 
        self.model: Optional[nn.Module] = None
        self.model_type = None
        self.finished_loading_weights = False
        
        # Object-based freezing system (kept for compatibility, but flags are primary)
        self.frozen_modules: Set[nn.Module] = set()
        self.eval_modules: Set[nn.Module] = set()
        self.use_object_based_freezing = False
        self.log.warning("Using object-based freezing system - this is kept for compatibility but flags are primary now.")

    def create_model(self) -> nn.Module:
        """Create and fully configure the model according to experiment settings"""
        log_new_section("Creating model with ModelFactory", logger=self.log)
        
        # Step 1: Create base model
        self.model = self._create_base_model()
        
        # Step 2: Setup object-based freezing system
        self._setup_object_based_freezing()
        
        # Step 3: Load pretrained weights if specified
        if self.experiment.pretrained_weights:
            self._load_pretrained_weights()

        # Step 4: Apply modifications (LoRA, etc.) after loading weights
        self.model = self._apply_modifications()
        
        # Step 5: Apply freezing if specified (flags survive model modifications)
        self.apply_freezing(report=True)

        # Step 6: Apply compilation if requested
        # DONT DO THIS HERE: this can cause problems in DDP
        # if self.experiment.compile:
        #     self.model = torch.compile(
        #         self.model, 
        #         mode=self.experiment.compile_mode, 
        #         fullgraph=self.experiment.compile_fullgraph, 
        #         dynamic=self.experiment.compile_dynamic,
        #     )
        
        # Step 7: Log final model status
        self._log_model_creation_summary()
        
        self.log.info("Model creation and configuration complete")
        return self.model
    
    def _create_base_model(self) -> nn.Module:
        """Create the base model architecture"""
        log_new_section("Creating base model architecture", logger=self.log)
        model_name = self.experiment.model
        assert isinstance(model_name, str), f"Model name must be a string but got {(model_name)}"

        convolution = getattr(self.experiment, "convolution", "BcosConv2d")
        overwrite_b_for_layer = getattr(self.experiment, "overwrite_b_for_layer", None)

        if model_name == "ResNet50":
            model = resnet50(num_classes=self.experiment.num_classes)
            
        elif model_name == "BcosResNet50":
            model = bcosresnet50(num_classes=self.experiment.num_classes)

        elif "#" in model_name.lower():
            model_repo, model_name = model_name.split("#")
            model = torch.hub.load(model_repo, model_name)
            # if self.experiment.dataset.lower() == "TinyImagenet".lower():
            #     model_wrapper = ImagenetWrapper(model)
            #     model = model_wrapper.get_model()

        elif model_name == "BcosResNet50_bottleneck":
            model = bcosresnet50_bottleneck(
                num_classes=self.experiment.num_classes,
                b_bottleneck=self.experiment.b_adapter,
                b_classifier=self.experiment.b_classifier,
                bottleneck=self.experiment.adapter,
                efficient_bcos=self.experiment.efficient_bcos,
                block_class=self.experiment.block_class,
                b=self.experiment.b,
                act_layer=self.experiment.act_layer,
                insert_adapter_layers=self.experiment.insert_adapter_layers,
                enable_bottleneck_layers=self.experiment.enable_bottleneck_layers,
                remove_adapter_skip_connections=self.experiment.remove_adapter_skip_connections,
                add_initial_adapter=self.experiment.add_initial_adapter,
                convolution=convolution,
                overwrite_b_for_layer=overwrite_b_for_layer,
                conv_adapter_style=self.experiment.conv_adapter_style,
                conv_adapter_act_layer=self.experiment.conv_adapter_act_layer,
                conv_adapter_factor=self.experiment.conv_adapter_factor,
                conv_adapter_kernel_size=self.experiment.conv_adapter_kernel_size,
                conv_adapter_pos=self.experiment.conv_adapter_position,
                conv_adapter_b=self.experiment.conv_adapter_b,
                norm_layer=self.experiment.norm_layer,
                concept_layer_factor=self.experiment.concept_layer_factor,
                concept_layer_b=self.experiment.concept_layer_b,
                concept_layer_use=self.experiment.concept_layer_use,
                dynamic_bias=self.experiment.dynamic_bias,
                dynamic_bias_b=self.experiment.dynamic_bias_b,
                conv_wise_adapter_mode=self.experiment.conv_wise_adapter_mode,
            )
        elif model_name.lower() == "vit".lower():
            model = bcos_vit(
                patch_size=self.experiment.vit_patch_size,
                dim=self.experiment.vit_dim,
                depth=self.experiment.vit_depth,
                heads=self.experiment.vit_num_heads,
                mlp_dim=self.experiment.vit_mlp_dim,
                conv_stem=self.experiment.vit_conv_stem,
                norm_layer=self.experiment.norm_layer,
                act_layer=self.experiment.act_layer,
                b=self.experiment.b,
                b_classifier=self.experiment.b_classifier,
                num_classes=self.experiment.num_classes,
                image_size=self.experiment.image_size,
                linear_layer=self.experiment.linear_layer,
                attention_mode=self.experiment.attention_mode,
                conv_2d_layer=self.experiment.vit_conv_stem_layer,
            )
        else:
            raise NotImplementedError(f"Model {model_name} not yet implemented")
        
        model.train()

        return model
    
    def _apply_modifications(self) -> nn.Module:
        """Apply modifications like LoRA to the model"""
        log_new_section("Applying modifications to the base model", logger=self.log)
        
        if self.experiment.pretrained_weights:
            assert self.finished_loading_weights, \
                "Model weights must be loaded before applying modifications"
        
        model = self.model
        
        # Apply modifications in specified order
        for mod_name in self.experiment.modification_order:
            if mod_name == "lora" and self.experiment.use_lora:
                linear_layer_class = get_linear_layer(self.experiment.linear_layer)
                act_layer = get_act_layer(self.experiment.lora_act_layer)
                
                linear_layer_class = partial(linear_layer_class, b=self.experiment.lora_b)
                lora_config = LoRAConfig(
                    r=self.experiment.lora_rank,
                    lora_alpha=self.experiment.lora_alpha,
                    linear_layer=linear_layer_class,
                    use_layer_b=self.experiment.lora_use_layer_b,
                    act_layer= act_layer,
                    depth = self.experiment.lora_depth,
                    use_input_norm=self.experiment.lora_use_input_norm,
                    initialization_mode=self.experiment.lora_initialization_mode,
                    neat= self.experiment.lora_use_neat,
                    target_modules=self.experiment.lora_target_modules,
                    mode=self.experiment.lora_mode,
                    
                )
                model = apply_lora_to_model(model, lora_config, log=self.log)
        
        # Apply PEFT if requested
        if self.experiment.use_peft:
            model = self._apply_peft_to_model(model)
        
        return model

    def _apply_peft_to_model(self, model: nn.Module) -> nn.Module:
        """Apply HuggingFace PEFT adapters to the entire model."""
        try:
            from peft import get_peft_model, LoraConfig, AdaLoraConfig, PromptEncoderConfig, PromptTuningConfig, ShiraConfig, PrefixTuningConfig
            
            # Try to import VeRA
            try:
                from peft import VeraConfig
            except ImportError:
                try:
                    from peft.tuners.vera import VeraConfig
                except ImportError:
                    VeraConfig = None
                    if self.log:
                        self.log.warning("VeraConfig not available in this PEFT version. Please update PEFT for VeRA support.")
            
            # Try to import RandLoRA
            try:
                from peft import LoKrConfig  # RandLoRA is implemented as LoKrConfig in PEFT
            except ImportError:
                try:
                    from peft.tuners.lokr import LoKrConfig
                except ImportError:
                    LoKrConfig = None
                    if self.log:
                        self.log.warning("LoKrConfig (RandLoRA) not available in this PEFT version. Please update PEFT for RandLoRA support.")
            
            # Try to import FourierFT
            try:
                from peft import FourierFTConfig
            except ImportError:
                try:
                    from peft.tuners.fourierft import FourierFTConfig
                except ImportError:
                    FourierFTConfig = None
                    if self.log:
                        self.log.warning("FourierFTConfig not available in this PEFT version. Please update PEFT for FourierFT support.")
                        
        except ImportError:
            raise ImportError("You must install the 'peft' library to use PEFT adapters. Run 'pip install peft transformers'.")
        
        if self.experiment.peft_config is None or 'strategy' not in self.experiment.peft_config:
            raise ValueError("If use_peft=True, you must provide a peft_config dict with a 'strategy' key.")
        
        strategy = self.experiment.peft_config['strategy']
        config_kwargs = {k: v for k, v in self.experiment.peft_config.items() if k != 'strategy'}
        
        # Map string to config class
        config_map = {
            'LoraConfig': LoraConfig,
            'AdaLoraConfig': AdaLoraConfig,
            'PromptEncoderConfig': PromptEncoderConfig,
            'PromptTuningConfig': PromptTuningConfig,
            "ShiraConfig": ShiraConfig,
            "PrefixTuningConfig": PrefixTuningConfig,
        }
        
        # Add Shira if available
        if ShiraConfig is not None:
            config_map['ShiraConfig'] = ShiraConfig
            
        # Add VeRA if available
        if VeraConfig is not None:
            config_map['VeraConfig'] = VeraConfig
            
        # Add RandLoRA (LoKr) if available
        if LoKrConfig is not None:
            config_map['LoKrConfig'] = LoKrConfig
            config_map['RandLoRAConfig'] = LoKrConfig  # Alias for easier usage
            
        # Add FourierFT if available
        if FourierFTConfig is not None:
            config_map['FourierFTConfig'] = FourierFTConfig
        
        if strategy not in config_map:
            raise ValueError(f"Unknown PEFT strategy: {strategy}. Supported: {list(config_map.keys())}")
        
        # Handle structured Shira masks
        if strategy == "ShiraConfig" and 'mask_type' in config_kwargs:
            mask_type = config_kwargs.get('mask_type', 'random')
            if mask_type != 'random':
                # Import structured mask functions
                try:
                    from models.structured_shira_masks import get_structured_mask_function
                    
                    # Get the structured mask function
                    structured_mask_fn = get_structured_mask_function(mask_type)
                    
                    # Create the config without mask_type (not a valid ShiraConfig parameter)
                    shira_kwargs = {k: v for k, v in config_kwargs.items() if k != 'mask_type'}
                    peft_cfg = config_map[strategy](**shira_kwargs)
                    
                    # Set the custom mask function
                    peft_cfg.mask_fn = structured_mask_fn
                    
                    if self.log:
                        self.log.info(f"Using structured Shira mask: {mask_type}")
                    
                except ImportError as e:
                    if self.log:
                        self.log.warning(f"Failed to import structured mask functions: {e}. Falling back to random mask.")
                    peft_cfg = config_map[strategy](**config_kwargs)
                except Exception as e:
                    if self.log:
                        self.log.warning(f"Failed to setup structured mask '{mask_type}': {e}. Falling back to random mask.")
                    peft_cfg = config_map[strategy](**config_kwargs)
            else:
                peft_cfg = config_map[strategy](**config_kwargs)
        else:
            peft_cfg = config_map[strategy](**config_kwargs)
        
        if self.log:
            self.log.info(f"Applying PEFT strategy: {strategy}")
            if 'target_modules' in config_kwargs:
                self.log.info(f"Target modules: {config_kwargs['target_modules']}")
        
        # Add a minimal config attribute if the model doesn't have one (required by PEFT)
        if not hasattr(model, 'config'):
            # Create a config class that behaves like both a namespace and a dictionary
            class ModelConfig:
                def __init__(self, **kwargs):
                    for key, value in kwargs.items():
                        setattr(self, key, value)
                        
                def get(self, key, default=None):
                    return getattr(self, key, default)
                    
                def __getitem__(self, key):
                    return getattr(self, key)
                    
                def __setitem__(self, key, value):
                    setattr(self, key, value)
                    
                def __contains__(self, key):
                    return hasattr(self, key)
            
            # Create a minimal config that PEFT can use
            model.config = ModelConfig(
                model_type="custom_vit" if hasattr(model, 'transformer') else "custom",
                hidden_size=getattr(model, 'patch_dim', 768),  # Try to get patch_dim, default to 768
                num_attention_heads=getattr(model, 'heads', 12),  # Try to get heads, default to 12
                num_hidden_layers=getattr(model, 'depth', 12),  # Try to get depth, default to 12
            )
            if self.log:
                self.log.info("Added minimal config attribute to model for PEFT compatibility")
        
        try:
            model = get_peft_model(model, peft_cfg)
            if self.log:
                self.log.info("PEFT applied successfully")
        except Exception as e:
            error_msg = f"Failed to apply PEFT to model: {e}"
            if self.log:
                self.log.error(error_msg)
            raise RuntimeError(error_msg)
        
        return model
    
    def _setup_object_based_freezing(self):
        """Setup flag-based freezing system"""
        self.frozen_modules = set()  # Keep for compatibility, but flags are primary
        self.eval_modules = set()
        
        # Use flag-based freezing which is robust to model modifications
        self.use_object_based_freezing = True
        if self.log:
            self.log.info("Using flag-based freezing (robust to model modifications)")
    
    def _load_pretrained_weights(self):
        """Load pretrained weights and setup freezing"""
        log_new_section("Loading parameters from checkpoint", logger=self.log)
        
        frozen_layers_list = getattr(self.experiment, "define_frozen_layers", None)
        
        # Get pretrained state dict with all transformations
        trained_state_dict = self._get_pretrained_statedict(verbose=True)

        if trained_state_dict is None:
            self.log.error("Failed to load pretrained state dict")
            return
        
        self.log.info(f"Final transformed state dict has {len(trained_state_dict)} keys")
        
        # Load the state dict
        try:
            missing_keys, unexpected_keys = self.model.load_state_dict(trained_state_dict, strict=False)
            self.log.info("Weights were loaded successfully.")
            
            # Log detailed module loading information
            self._log_module_loading_status(trained_state_dict, missing_keys, unexpected_keys)
                    
        except RuntimeError as e:
            self.log.error(f"Parameters from state dict could not be loaded: {e}")
            raise e
        
        # Setup freezing based on experiment settings
        self._setup_module_freezing_from_pretrained(trained_state_dict, frozen_layers_list)
        
        self.log.info("Frozen parameters loaded from the pretrained model.")
        self.finished_loading_weights = True
    
    def _setup_module_freezing_from_pretrained(self, trained_state_dict: Dict[str, torch.Tensor], frozen_layers_list: Optional[List[str]]):
        """Mark modules to be frozen using flags - simple and robust approach"""
        
        # Helper function to check if we should process this module based on layer filtering
        def should_process_module(module_name: str) -> bool:
            if isinstance(frozen_layers_list, list):
                layer_prefix = module_name.split(".")[0]
                return layer_prefix in frozen_layers_list
            return True
        
        # Helper function to check if a module has parameters loaded from checkpoint
        def module_has_pretrained_params(module_name: str) -> bool:
            return any(key.startswith(module_name + ".") for key in trained_state_dict.keys())
        
        # Helper function to check if we should freeze a specific module
        def should_freeze_module(module_name: str, module: nn.Module) -> bool:
            # Skip classifier modules if not replacing
            if module_name.startswith("fc") or module_name.startswith("linear_head"):
                return False
            
            # Check specific module types and experiment settings
            if "bn" in module_name:
                # Batch norms can be frozen if explicitly requested
                return self.experiment.freeze_pretrained_batchnorms
            elif ".norm" in module_name:
                return self.experiment.freeze_layer_norms
            elif "to_patch_embedding" in module_name:
                return self.experiment.freeze_patch_embeddings
            else:
                return True
        
        # Helper function to check if we should set module to eval mode
        def should_eval_module(module_name: str, module: nn.Module) -> bool:
            if "bn" in module_name:
                # Batch norms can be frozen if explicitly requested
                return self.experiment.set_pretrained_batchnorms_to_eval
            else:
                return False
        
        # Mark modules for freezing using flags
        if self.experiment.freeze_pretrained_weights:
            for module_name, module in self.model.named_modules():
                if not module_name:  # Skip root module
                    continue
                
                # Check if this module should be processed based on layer filtering
                if not should_process_module(module_name):
                    continue
                
                # Check if this module has parameters from the pretrained model
                if not module_has_pretrained_params(module_name):
                    continue
                
                # Check if we should freeze this specific module
                if should_freeze_module(module_name, module):
                    setattr(module, '_should_freeze', True)
        
        # Mark modules for eval mode using flags
        if self.experiment.set_pretrained_batchnorms_to_eval:
            for module_name, module in self.model.named_modules():
                if not module_name:  # Skip root module
                    continue
                
                # Check if this module should be processed based on layer filtering
                if not should_process_module(module_name):
                    continue
                
                # Check if this module has parameters from the pretrained model
                if not module_has_pretrained_params(module_name):
                    continue
                
                # Check if we should set this module to eval mode
                if should_eval_module(module_name, module):
                    setattr(module, '_should_eval', True)
    
    # Freezing control methods
    def apply_freezing(self, report: bool = False):
        """Apply freezing using module flags - works even after model modifications"""
        if report: 
            log_new_section("Applying Freezing", logger=self.log)
        
        frozen_count = 0
        eval_count = 0
        frozen_modules = []
        eval_modules = []
        
        # Apply freezing and eval based on flags
        for module_name, module in self.model.named_modules():
            if not module_name:  # Skip root module
                continue
                
            # Check if module should be frozen
            if getattr(module, '_should_freeze', False):
                frozen_modules.append(module_name)
                for param in module.parameters(recurse=False):  # Only direct parameters, not children
                    if param.requires_grad:
                        param.requires_grad = False
                        frozen_count += 1
            
            # Check if module should be in eval mode
            if getattr(module, '_should_eval', False):
                eval_modules.append(module_name)
                if module.training:
                    module.eval()
                    eval_count += 1
        
        if report:
            if self.log:
                self.log.info(f"Flag-based freezing: Frozen {frozen_count} parameters in {len(frozen_modules)} modules")
                self.log.info(f"Flag-based freezing: Set {len(eval_modules)} modules to eval mode")
                if frozen_modules:
                    self.log.info("Frozen modules:")
                    for module in frozen_modules:
                        self.log.info(f"  - {module}")
                if eval_modules:
                    self.log.info("Eval modules:")
                    for module in eval_modules:
                        self.log.info(f"  - {module}")
                self._log_detailed_freezing_status()
    
    def _log_detailed_freezing_status(self):
        """Log detailed status of all modules: frozen, trainable, and eval mode"""
        if not self.log:
            return
            
        log_new_section("Detailed Module Status Report", logger=self.log)
        
        frozen_modules = []
        trainable_modules = []
        eval_modules = []
        train_modules = []
        
        # Collect module information
        for name, module in self.model.named_modules():
            if name:  # Skip empty names (root module)
                module_has_params = any(p.requires_grad for p in module.parameters(recurse=False))
                module_frozen = any(not p.requires_grad for p in module.parameters(recurse=False))
                
                # Track frozen vs trainable
                if module_frozen and module_has_params:
                    frozen_modules.append(name)
                elif module_has_params:
                    trainable_modules.append(name)
                
                # Track eval vs training mode
                if not module.training:
                    eval_modules.append(name)
                else:
                    train_modules.append(name)
        
        # Log module counts
        self.log.info(f"Module Status Summary:")
        self.log.info(f"  Modules with frozen parameters: {len(frozen_modules)}")
        self.log.info(f"  Modules with trainable parameters: {len(trainable_modules)}")
        self.log.info(f"  Modules in eval mode: {len(eval_modules)}")
        self.log.info(f"  Modules in training mode: {len(train_modules)}")
        
        # Log detailed lists (one per line for better overview)
        if frozen_modules:
            self.log.info("Frozen modules:")
            for module in frozen_modules:
                self.log.info(f"  - {module}")
        
        if trainable_modules:
            self.log.info("Trainable modules:")
            for module in trainable_modules:
                self.log.info(f"  - {module}")
        
        if eval_modules:
            self.log.info("Eval mode modules:")
            for module in eval_modules:
                self.log.info(f"  - {module}")
        
        # Log parameter counts
        total_params = sum(p.numel() for p in self.model.parameters())
        trainable_params = sum(p.numel() for p in self.model.parameters() if p.requires_grad)
        frozen_params = total_params - trainable_params
        
        self.log.info(f"Parameter Counts:")
        self.log.info(f"  Total parameters: {total_params:,}")
        self.log.info(f"  Trainable parameters: {trainable_params:,}")
        self.log.info(f"  Frozen parameters: {frozen_params:,}")
        self.log.info(f"  Trainable percentage: {100 * trainable_params / total_params:.1f}%")
    
    def _log_model_creation_summary(self):
        """Log summary of model creation including architecture and initial status"""
        log_new_section("Model Creation Summary", logger=self.log)
        
        # Log basic model information
        total_params = sum(p.numel() for p in self.model.parameters())
        trainable_params = sum(p.numel() for p in self.model.parameters() if p.requires_grad)
        
        self.log.info(f"Model Architecture: {self.experiment.model}")
        self.log.info(f"Total parameters: {total_params:,}")
        self.log.info(f"Trainable parameters: {trainable_params:,}")
        self.log.info(f"Frozen parameters: {total_params - trainable_params:,}")
        
        # Log whether weights were loaded
        if self.experiment.pretrained_weights:
            self.log.info(f"Pretrained weights loaded from: {self.experiment.pretrained_weights}")
        else:
            self.log.info("No pretrained weights loaded (training from scratch)")
        
        # Log freezing configuration
        if self.experiment.freeze_pretrained_weights:
            self.log.info("Pretrained weight freezing is ENABLED")
        else:
            self.log.info("Pretrained weight freezing is DISABLED")
        
        # Log modification information
        if self.experiment.use_lora:
            self.log.info(f"LoRA modification applied with rank {self.experiment.lora_rank}")
         # Log compilation status
        if self.experiment.compile:
            self.log.info(f"Model compiled with mode: {self.experiment.compile_mode}")
        else:
            self.log.info("Model compilation disabled")
    
    # Advanced freezing methods
    def freeze_by_group(self, group_name: str):
        """Freeze all modules in a specific group"""
        if hasattr(self.model, 'get_layer_groups'):
            groups = getattr(self.model, 'get_layer_groups')()
            if group_name in groups:
                self.frozen_modules.update(groups[group_name])
                self.log.info(f"Added {len(groups[group_name])} modules from group '{group_name}' to freeze list")
    
    def freeze_by_pattern(self, pattern: str):
        """Freeze modules whose names match a pattern"""
        if hasattr(self.model, 'get_modified_modules'):
            modified_modules = getattr(self.model, 'get_modified_modules')()
            matching_modules = [module for name, module in modified_modules.items() if pattern in name]
            self.frozen_modules.update(matching_modules)
            self.log.info(f"Added {len(matching_modules)} modules matching pattern '{pattern}' to freeze list")
    
    def add_modules_to_freeze(self, modules):
        """Mark modules to be frozen using flags"""
        if isinstance(modules, nn.Module):
            modules = [modules]
        for module in modules:
            setattr(module, '_should_freeze', True)
    
    def add_modules_to_eval(self, modules):
        """Mark modules to be set to eval mode using flags"""
        if isinstance(modules, nn.Module):
            modules = [modules]
        for module in modules:
            setattr(module, '_should_eval', True)
    
    def unfreeze_all(self):
        """Unfreeze all parameters and clear freeze flags"""
        for param in self.model.parameters():
            param.requires_grad = True
        
        # Clear all freeze flags
        for module in self.model.modules():
            if hasattr(module, '_should_freeze'):
                delattr(module, '_should_freeze')
        
        self.frozen_modules.clear()
        if self.log:
            self.log.info("Unfroze all parameters and cleared freeze flags")
    
    def set_all_to_train(self):
        """Set all modules to training mode and clear eval flags"""
        self.model.train()
        
        # Clear all eval flags
        for module in self.model.modules():
            if hasattr(module, '_should_eval'):
                delattr(module, '_should_eval')
        
        self.eval_modules.clear()
        if self.log:
            self.log.info("Set all modules to training mode and cleared eval flags")
    
    # Utility methods for the lightning module
    @property
    def base_model(self) -> nn.Module:
        """Returns the base model, handling compiled models"""
        if hasattr(self.model, '_orig_mod'):
            return self.model._orig_mod
        return self.model
    
    @property
    def name_mapping_registry(self):
        """Returns the name mapping registry if available"""
        if hasattr(self.model, '_name_mapping_registry'):
            return getattr(self.model, '_name_mapping_registry')
        return None
    
    def get_parameter_counts(self):
        """Get total and trainable parameter counts"""
        # if isinstance(self.model, PeftModel):
        #     self.model.print_trainable_parameters()
        #     raise Exception("Cannot get parameter counts for PEFT models directly. Use the base model instead.")
        total_params = sum(p.numel() for p in self.model.parameters())
        trainable_params = sum(p.numel() for p in self.model.parameters() if p.requires_grad)
        return total_params, trainable_params
    
    # State dict handling methods (keeping the existing logic)
    def _get_pretrained_statedict(self, verbose: bool = False, convert_state_dict: bool = True):
        """Get pretrained state dict with all necessary transformations"""
        model = self._get_pretrained_model(verbose=verbose)
        # Handle case where model is actually a state_dict (for HF models)
        if isinstance(model, dict):
            # HF loader returns state_dict directly, not a model object
            state_dict = model
        else:
            if isinstance(model, nn.Sequential):
                model = model[0]
            # print(model)
            state_dict = model.state_dict()
        
        if convert_state_dict:
            if self.model_type == "pytorch_vit":
                state_dict = self._rename_state_dict_pytorch_vit(state_dict)
            elif self.model_type == "torchhub":
                state_dict = self._rename_state_dict_torchhub_resnet(state_dict)
                state_dict = self._rename_old_conv_adapters(state_dict)
            elif self.model_type == "hf_vit":
                state_dict = self._convert_hf_to_simplevit_state_dict(state_dict)

        # Apply modifier mappings BEFORE filtering
        if self.name_mapping_registry is not None:
            if verbose:
                self.log.info("Applying modifier name mappings to pretrained state dict")
            original_keys = set(state_dict.keys())
            state_dict = self.name_mapping_registry.transform_state_dict(
                state_dict, original_to_current=True
            )
            transformed_keys = set(state_dict.keys())
            if verbose:
                self.log.info(f"Modifier mappings: {len(original_keys)} -> {len(transformed_keys)} keys")

        # Apply experiment-specific filtering
        if not self.experiment.replace_classifier_by_pretrained:
            if verbose:
                self.log.info("Classifier is not replaced by pretrained weights")
            state_dict = {k: v for k, v in state_dict.items() 
                         if not (k.startswith("fc.") or k.startswith("linear_head."))}
        
        if self.experiment.norm_layer.lower() in ["dynamictanh", "tanh"]:
            if verbose:
                self.log.info(f"Removed norm information because norm was {self.experiment.norm_layer}")
            state_dict = {k: v for k, v in state_dict.items() if "bn" not in k}
        
        # Filter out to_patch_embedding when using convolutional stem
        if isinstance(self.base_model, SimpleViT) and self.experiment.vit_conv_stem is not None:
            if verbose and self.log:
                self.log.info("Filtering out to_patch_embedding weights due to convolutional stem usage")
            state_dict = {k: v for k, v in state_dict.items() 
                         if not k.startswith("to_patch_embedding.")}
        
        filtered_state_dict = self._filter_state_dict(state_dict, verbose=verbose)
        # print("State dict keys before filtering:")
        # for k in filtered_state_dict.keys():
        #     print(k)
        # raise Exception("State dict keys before filtering printed above. Check if they match the model's expected keys.")

        # Apply model-specific transformations
        if self.model_type == "torchhub":
            filtered_state_dict = self._replace_convolution_by_6_channel(filtered_state_dict)
        if isinstance(self.base_model, SimpleViT) and self.experiment.vit_conv_stem is None:
            # Only apply 6-channel transformation if NOT using convolutional stem
            filtered_state_dict = self.replace_to_patch_embedding_by_6_channels(filtered_state_dict)
        
        return filtered_state_dict
    
    def replace_to_patch_embedding_by_6_channels(self, state_dict):
        """
        Replaces the patch embedding layer in a ViT model's state_dict to accept 6-channel input.
        This is useful for models that are adapted to work with 6-channel input data.
        """
        for k, v in state_dict.items():
            if k.startswith("to_patch_embedding.linear.linear.weight"):
                v = double_conv_input_channels_then_convert_to_linear(v)
                state_dict[k] = v
        return state_dict
    
    
    def _get_pretrained_model(self, verbose: bool = False):
        """Load pretrained model from checkpoint or hub"""
        if self.experiment.pretrained_weights.endswith(".ckpt"):
            # Import here to avoid circular imports
            from models.lightning_module import BcosLightningModule
            module = BcosLightningModule.load_from_checkpoint(
                self.experiment.pretrained_weights, suppress_init_logging=True
            )
            model = module.model
            self.model_type = "own"
            if verbose:
                self.log.info(f"Loaded model from checkpoint: {self.experiment.pretrained_weights}")
        else:
            model_reference = self.experiment.pretrained_weights.split("#")
            try:
                repo, name, weights = model_reference
            except:
                repo, name = model_reference
                weights = None

            
            try:
                if repo.lower() == "pytorch_builtin":
                    model = torchvision.models.__dict__[name](weights=weights)
                elif repo.lower() == "hf" or repo.lower() == "huggingface":
                    # Load HuggingFace model using our utility
                    from .transformation.hf_weights_loader import load_hf_vit_weights
                    model = load_hf_vit_weights(name)
                    self.model_type = "hf_vit"
                else:
                    model = torch.hub.load(repo, name, pretrained=True)

                if not self.model_type:
                    if "bcos" in repo:
                        self.model_type = "bcos"
                    elif "pytorch_builtin" in repo.lower() and "vit" in name.lower():
                        self.model_type = "pytorch_vit"
                    else:
                        self.model_type = "torchhub"

                if verbose:
                    self.log.info(f"Loaded model {name} from torch hub repo {repo}")
            except Exception as e:
                raise Exception(f"Model {name} could not be loaded from repo {repo}.") from e
        
        model = model._orig_mod if hasattr(model, "_orig_mod") else model
        
        if verbose:
            self.log.info(f"Model_type is {self.model_type}")
            # self.log.info(f"Model architecture: {model}")
           
        return model
    
    def _filter_state_dict(self, state_dict: dict, verbose: bool = False):
        """Filter state dict to match current model"""
        if verbose:
            self.log.info("Start filtering state_dict")

        model_keys = set(self.base_model.state_dict().keys())
        checkpoint_keys = set(state_dict.keys())
        
        # matched_keys = sorted(list(model_keys.intersection(checkpoint_keys)))
        # missing_keys = sorted(list(model_keys - checkpoint_keys))
        # unexpected_keys = sorted(list(checkpoint_keys - model_keys))
        
        # Filter out bias-only unexpected keys
        keys_wo_bias = [k for k in checkpoint_keys if not k.endswith("bias")]
        if len(keys_wo_bias) != len(checkpoint_keys):
            self.log.warning("Some unexpected keys were filtered out because they end with 'bias'")
        
        # if verbose:
        #     if matched_keys:
        #         self.log.info(f"Matching keys found: {len(matched_keys)}")
        #     if unexpected_keys:
        #         self.log.info(f"Unexpected keys found: {len(unexpected_keys)}")
        #     if missing_keys:
        #         self.log.info(f"Missing keys in checkpoint: {len(missing_keys)}")
        
        filtered_state_dict = OrderedDict()
        for k, v in state_dict.items():
            if k in keys_wo_bias:
                filtered_state_dict[k] = v

        return filtered_state_dict

    def _convert_hf_to_simplevit_state_dict(self, hf_state_dict: dict) -> dict:
        """Convert HuggingFace ViT state dict to SimpleViT format"""
        from .transformation.hf_weights_loader import convert_hf_to_simplevit_state_dict
        return convert_hf_to_simplevit_state_dict(hf_state_dict)

    def _rename_state_dict_pytorch_vit(self, state_dict):
        """Rename PyTorch ViT state dict to match B-COS naming"""

        # Replace encoder layers
        state_dict = {k.replace("encoder.layers.", "transformer."): v for k, v in state_dict.items()}
        state_dict = {k.replace("encoder_layer_", "encoder_"): v for k, v in state_dict.items()}

        # Replace linear layers
        state_dict = {k.replace(".mlp.0.", ".ff.net.linear1."): v for k, v in state_dict.items()}
        state_dict = {k.replace(".mlp.3.", ".ff.net.linear2."): v for k, v in state_dict.items()}
        state_dict = {k.replace(".weight", ".linear.weight"): v for k, v in state_dict.items()}

        # Replace attention layers
        state_dict = {k.replace(".self_attention.", ".attn."): v for k, v in state_dict.items()}
        state_dict = {k.replace(".in_proj_weight", ".to_qkv.linear.weight"): v for k, v in state_dict.items()}
        state_dict = {k.replace(".out_proj.", ".to_out."): v for k, v in state_dict.items()}

        # Replace other components
        state_dict = {k.replace(".ln_1.linear.", ".attn.norm."): v for k, v in state_dict.items()}
        state_dict = {k.replace(".ln_2.linear.", ".ff.net.norm."): v for k, v in state_dict.items()}
        state_dict = {k.replace("conv_proj.", "to_patch_embedding.linear."): v for k, v in state_dict.items()}
        
        # Replace classifier also replaces the norm
        state_dict = {k.replace("heads.head", "linear_head.linear"): v for k, v in state_dict.items()}
        state_dict = {k.replace("encoder.ln.linear", "linear_head.norm"): v for k, v in state_dict.items()}

        return state_dict
    
    def _rename_old_conv_adapters(self, state_dict):
        """Rename old convolutional adapter state dict keys to match new naming"""
        new_state_dict = {}
        for k, v in state_dict.items():
            if k.startswith(".conv_adapter."):
                # Replace conv_adapter with conv_adapter_linear
                k_new = k.replace(".conv_adapter.", ".conv_adapter_res_parallel.")
                new_state_dict[k_new] = v
                print(f"Renaming {k} to {k_new}") if k.startswith(".conv_adapter.") else None
            else:
                new_state_dict[k] = v
        return new_state_dict
    
    def _rename_state_dict_torchhub_resnet(self, state_dict):
        """Rename TorchHub ResNet state dict to match B-COS naming"""
        new_state_dict = {}
        for k, v in state_dict.items():
            if k.startswith("layer"):
                k_split = k.split(".")
                layers, blocks = k_split[:2], k_split[2:]
                layers = f"layer{int(layers[1])+1}"
                k_merged = ".".join([layers] + blocks)
                new_state_dict[k_merged] = v
            else:
                new_state_dict[k] = v
        
        old_state_dict = new_state_dict
        new_state_dict = {}
        for k, v in old_state_dict.items():
            if k.endswith("weight") and ("conv" in k or "downsample.0" in k or k.startswith("fc")):
                k_split = k.split(".")
                k_split = k_split[:-1] + ["linear"] + k_split[-1:]
                k_merged = ".".join(k_split)
                new_state_dict[k_merged] = v
            else:
                new_state_dict[k] = v

        return new_state_dict
    
    def _replace_convolution_by_6_channel(self, state_dict):
        """Replace first convolution to accept 6 channels"""
        for k, v in state_dict.items():
            if k.startswith("conv1."):
                v = double_conv_input_channels(v)
                state_dict[k] = v
        return state_dict

    def apply_train_mode_freezing(self):
        """Apply freezing when entering train mode (called from LightningModule.train())"""
        if self.experiment.freeze_pretrained_weights:
            self.apply_freezing()
    
    def _log_module_loading_status(self, trained_state_dict: Dict[str, torch.Tensor], 
                                   missing_keys: List[str], unexpected_keys: List[str]):
        """Log detailed information about which modules were loaded from pretrained weights"""
        log_new_section("Module Loading Status Report", logger=self.log)
        
        # Get all model parameter names
        model_param_names = set(dict(self.model.named_parameters()).keys())
        loaded_param_names = set(trained_state_dict.keys())
        
        # Calculate loaded parameters
        actually_loaded = model_param_names.intersection(loaded_param_names)
        
        self.log.info(f"Parameter Loading Summary:")
        self.log.info(f"  Total model parameters: {len(model_param_names)}")
        self.log.info(f"  Pretrained parameters available: {len(loaded_param_names)}")
        self.log.info(f"  Successfully loaded parameters: {len(actually_loaded)}")
        self.log.info(f"  Missing parameters: {len(missing_keys)}")
        self.log.info(f"  Unexpected parameters: {len(unexpected_keys)}")
        
        # Group loaded parameters by module
        loaded_modules = {}
        for param_name in actually_loaded:
            module_name = '.'.join(param_name.split('.')[:-1])  # Remove parameter name
            if module_name not in loaded_modules:
                loaded_modules[module_name] = []
            loaded_modules[module_name].append(param_name.split('.')[-1])  # Just parameter name
        
        # Log loaded modules
        if loaded_modules:
            self.log.info(f"Loaded modules ({len(loaded_modules)} modules):")
            for module_name, params in sorted(loaded_modules.items()):
                if module_name:  # Skip empty module names
                    self.log.info(f"  {module_name}: {params}")
        
        # Log missing keys with module grouping
        if missing_keys:
            self.log.info(f"Missing parameters ({len(missing_keys)} total):")
            missing_modules = {}
            for key in missing_keys:
                module_name = '.'.join(key.split('.')[:-1])
                if module_name not in missing_modules:
                    missing_modules[module_name] = []
                missing_modules[module_name].append(key.split('.')[-1])
            
            for module_name, params in sorted(missing_modules.items()):
                if module_name:
                    self.log.info(f"  {module_name}: {params}")
        
        # Log unexpected keys with module grouping
        if unexpected_keys:
            self.log.info(f"Unexpected parameters ({len(unexpected_keys)} total):")
            unexpected_modules = {}
            for key in unexpected_keys:
                module_name = '.'.join(key.split('.')[:-1])
                if module_name not in unexpected_modules:
                    unexpected_modules[module_name] = []
                unexpected_modules[module_name].append(key.split('.')[-1])
            
            for module_name, params in sorted(unexpected_modules.items()):
                if module_name:
                    self.log.info(f"  {module_name}: {params}")
