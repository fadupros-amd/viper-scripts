"""
Structured sparsity mask functions for Shira PEFT adapters.

This module provides various structured sparsity patterns that can be used
with Shira adapters as alternatives to random sparsity patterns.
"""

import torch
import torch.nn as nn
from typing import Optional, Tuple, Union
import math


def magnitude_based_mask(base_layer: nn.Module, r: int, percentile: float = 95.0, **kwargs) -> torch.Tensor:
    """
    Create a mask based on weight magnitudes - selects parameters with highest absolute values.
    
    Args:
        base_layer: The linear layer where the shira adapter will be attached
        r: Parameter for determining number of parameters (same as LoRA sizing)
        percentile: Percentile threshold for magnitude selection (default: 95.0)
        
    Returns:
        mask: Binary mask tensor of same shape as base_layer.weight
    """
    weights = base_layer.weight.data
    shape = weights.shape
    num_shira_weights = r * (shape[0] + shape[1])
    
    # Ensure we don't exceed total parameters
    total_params = weights.numel()
    num_shira_weights = min(num_shira_weights, total_params)
    
    # Get magnitude-based indices
    weight_magnitudes = torch.abs(weights.view(-1))
    _, top_indices = torch.topk(weight_magnitudes, num_shira_weights)
    
    # Create mask
    mask = torch.zeros_like(weights.view(-1))
    mask[top_indices] = 1.0
    mask = mask.view(shape)
    
    return mask.to(weights.dtype).to(weights.device)


def block_sparse_mask(base_layer: nn.Module, r: int, block_size: int = 4, **kwargs) -> torch.Tensor:
    """
    Create a block-structured sparse mask with square blocks.
    
    Args:
        base_layer: The linear layer where the shira adapter will be attached
        r: Parameter for determining number of parameters
        block_size: Size of square blocks (default: 4)
        
    Returns:
        mask: Binary mask tensor with block-structured sparsity
    """
    weights = base_layer.weight.data
    shape = weights.shape
    num_shira_weights = r * (shape[0] + shape[1])
    
    # Calculate number of blocks needed
    total_elements_per_block = block_size * block_size
    num_blocks_needed = max(1, num_shira_weights // total_elements_per_block)
    
    # Calculate how many blocks fit in each dimension
    blocks_out = shape[0] // block_size
    blocks_in = shape[1] // block_size
    total_possible_blocks = blocks_out * blocks_in
    
    # Limit to available blocks
    num_blocks_needed = min(num_blocks_needed, total_possible_blocks)
    
    # Create mask
    mask = torch.zeros_like(weights)
    
    if num_blocks_needed > 0:
        # Randomly select block positions
        block_indices = torch.randperm(total_possible_blocks)[:num_blocks_needed]
        
        for block_idx in block_indices:
            # Convert linear block index to 2D coordinates
            block_row = block_idx // blocks_in
            block_col = block_idx % blocks_in
            
            # Calculate actual pixel coordinates
            start_row = block_row * block_size
            end_row = min(start_row + block_size, shape[0])
            start_col = block_col * block_size
            end_col = min(start_col + block_size, shape[1])
            
            # Fill the block
            mask[start_row:end_row, start_col:end_col] = 1.0
    
    return mask.to(weights.dtype).to(weights.device)


def channel_wise_mask(base_layer: nn.Module, r: int, mode: str = "output", **kwargs) -> torch.Tensor:
    """
    Create channel-wise structured sparsity (select entire rows or columns).
    
    Args:
        base_layer: The linear layer where the shira adapter will be attached
        r: Parameter for determining number of parameters
        mode: "output" for output channels (rows), "input" for input channels (cols)
        
    Returns:
        mask: Binary mask with channel-wise structure
    """
    weights = base_layer.weight.data
    shape = weights.shape
    num_shira_weights = r * (shape[0] + shape[1])
    
    mask = torch.zeros_like(weights)
    
    if mode == "output":
        # Select entire output channels (rows)
        num_channels = min(num_shira_weights // shape[1], shape[0])
        if num_channels > 0:
            selected_channels = torch.randperm(shape[0])[:num_channels]
            mask[selected_channels, :] = 1.0
    elif mode == "input":
        # Select entire input channels (columns)
        num_channels = min(num_shira_weights // shape[0], shape[1])
        if num_channels > 0:
            selected_channels = torch.randperm(shape[1])[:num_channels]
            mask[:, selected_channels] = 1.0
    else:
        raise ValueError(f"Unknown mode: {mode}. Use 'output' or 'input'")
    
    return mask.to(weights.dtype).to(weights.device)


def structured_random_mask(base_layer: nn.Module, r: int, 
                          pattern: str = "strips", 
                          orientation: str = "horizontal",
                          strip_width: int = 2,
                          **kwargs) -> torch.Tensor:
    """
    Create structured random patterns (strips, checkerboard, etc.).
    
    Args:
        base_layer: The linear layer where the shira adapter will be attached
        r: Parameter for determining number of parameters
        pattern: "strips", "checkerboard", "diagonal"
        orientation: "horizontal", "vertical", "both" (for strips)
        strip_width: Width of strips (default: 2)
        
    Returns:
        mask: Binary mask with structured random pattern
    """
    weights = base_layer.weight.data
    shape = weights.shape
    num_shira_weights = r * (shape[0] + shape[1])
    
    mask = torch.zeros_like(weights)
    
    if pattern == "strips":
        if orientation in ["horizontal", "both"]:
            # Horizontal strips
            num_strips = max(1, shape[0] // strip_width)
            selected_strips = torch.randperm(num_strips)[:max(1, num_shira_weights // (strip_width * shape[1]))]
            for strip_idx in selected_strips:
                start_row = strip_idx * strip_width
                end_row = min(start_row + strip_width, shape[0])
                mask[start_row:end_row, :] = 1.0
                
        if orientation in ["vertical", "both"]:
            # Vertical strips
            num_strips = max(1, shape[1] // strip_width)
            selected_strips = torch.randperm(num_strips)[:max(1, num_shira_weights // (strip_width * shape[0]))]
            for strip_idx in selected_strips:
                start_col = strip_idx * strip_width
                end_col = min(start_col + strip_width, shape[1])
                mask[:, start_col:end_col] = 1.0
                
    elif pattern == "checkerboard":
        # Checkerboard pattern
        check_size = strip_width
        for i in range(0, shape[0], check_size):
            for j in range(0, shape[1], check_size):
                if (i // check_size + j // check_size) % 2 == 0:
                    end_i = min(i + check_size, shape[0])
                    end_j = min(j + check_size, shape[1])
                    mask[i:end_i, j:end_j] = 1.0
                    
    elif pattern == "diagonal":
        # Diagonal bands
        for diag_offset in range(-shape[0], shape[1], strip_width * 2):
            diag_mask = torch.eye(shape[0], shape[1], dtype=weights.dtype, device=weights.device)
            if diag_offset != 0:
                if diag_offset > 0:
                    diag_mask = torch.roll(diag_mask, diag_offset, dims=1)
                else:
                    diag_mask = torch.roll(diag_mask, -diag_offset, dims=0)
            mask += diag_mask
            
    # Ensure we don't exceed the target number of parameters
    if mask.sum() > num_shira_weights:
        flat_mask = mask.view(-1)
        indices = torch.nonzero(flat_mask).squeeze()
        if len(indices.shape) > 0:
            selected_indices = indices[torch.randperm(len(indices))[:num_shira_weights]]
            new_mask = torch.zeros_like(flat_mask)
            new_mask[selected_indices] = 1.0
            mask = new_mask.view(shape)
    
    return mask.to(weights.dtype).to(weights.device)


def attention_head_mask(base_layer: nn.Module, r: int, 
                       num_heads: int = 12, 
                       head_dim: int = 64,
                       selected_heads: Optional[list] = None,
                       **kwargs) -> torch.Tensor:
    """
    Create masks that respect attention head structure (for transformer models).
    
    Args:
        base_layer: The linear layer (should be attention projection)
        r: Parameter for determining number of parameters
        num_heads: Number of attention heads
        head_dim: Dimension per head
        selected_heads: Specific heads to select (if None, select randomly)
        
    Returns:
        mask: Binary mask respecting attention head boundaries
    """
    weights = base_layer.weight.data
    shape = weights.shape
    num_shira_weights = r * (shape[0] + shape[1])
    
    mask = torch.zeros_like(weights)
    
    # Assume the weight matrix is organized as [num_heads * head_dim, input_dim]
    expected_output_dim = num_heads * head_dim
    
    if shape[0] != expected_output_dim:
        # Fallback to random if dimensions don't match expected structure
        indices = torch.randperm(weights.numel())[:num_shira_weights]
        flat_mask = torch.zeros(weights.numel(), dtype=weights.dtype, device=weights.device)
        flat_mask[indices] = 1.0
        return flat_mask.view(shape)
    
    if selected_heads is None:
        # Determine how many heads to select based on target parameters
        params_per_head = head_dim * shape[1]
        num_selected_heads = min(num_shira_weights // params_per_head, num_heads)
        if num_selected_heads == 0:
            num_selected_heads = 1
        selected_heads = torch.randperm(num_heads)[:num_selected_heads].tolist()
    
    # Create mask for selected heads
    for head_idx in selected_heads:
        start_dim = head_idx * head_dim
        end_dim = min(start_dim + head_dim, shape[0])
        mask[start_dim:end_dim, :] = 1.0
    
    return mask.to(weights.dtype).to(weights.device)


def hybrid_structured_mask(base_layer: nn.Module, r: int,
                          magnitude_ratio: float = 0.5,
                          block_size: int = 4,
                          **kwargs) -> torch.Tensor:
    """
    Combine magnitude-based and block-structured sparsity.
    
    Args:
        base_layer: The linear layer where the shira adapter will be attached
        r: Parameter for determining number of parameters
        magnitude_ratio: Ratio of parameters to select by magnitude (rest by blocks)
        block_size: Size of blocks for structured component
        
    Returns:
        mask: Binary mask combining magnitude and structural patterns
    """
    weights = base_layer.weight.data
    shape = weights.shape
    num_shira_weights = r * (shape[0] + shape[1])
    
    # Split parameters between magnitude and block selection
    mag_params = int(num_shira_weights * magnitude_ratio)
    block_params = num_shira_weights - mag_params
    
    # Get magnitude-based mask
    weight_magnitudes = torch.abs(weights.view(-1))
    _, top_mag_indices = torch.topk(weight_magnitudes, mag_params)
    mag_mask = torch.zeros_like(weights.view(-1))
    mag_mask[top_mag_indices] = 1.0
    mag_mask = mag_mask.view(shape)
    
    # Get block-based mask for remaining parameters
    remaining_weights = weights * (1 - mag_mask)  # Exclude already selected
    block_mask = block_sparse_mask(
        type('Layer', (), {'weight': type('Weight', (), {'data': remaining_weights})})(),
        block_params // (shape[0] + shape[1]) + 1,  # Approximate r for remaining params
        block_size
    )
    
    # Combine masks
    combined_mask = torch.clamp(mag_mask + block_mask, 0, 1)
    
    # Ensure we don't exceed target parameters
    if combined_mask.sum() > num_shira_weights:
        flat_mask = combined_mask.view(-1)
        indices = torch.nonzero(flat_mask).squeeze()
        if len(indices.shape) > 0:
            selected_indices = indices[torch.randperm(len(indices))[:num_shira_weights]]
            new_mask = torch.zeros_like(flat_mask)
            new_mask[selected_indices] = 1.0
            combined_mask = new_mask.view(shape)
    
    return combined_mask.to(weights.dtype).to(weights.device)


# Dictionary mapping mask type names to functions
STRUCTURED_MASK_FUNCTIONS = {
    'magnitude': magnitude_based_mask,
    'block': block_sparse_mask,
    'channel_output': lambda base_layer, r, **kwargs: channel_wise_mask(base_layer, r, mode="output", **kwargs),
    'channel_input': lambda base_layer, r, **kwargs: channel_wise_mask(base_layer, r, mode="input", **kwargs),
    'strips_horizontal': lambda base_layer, r, **kwargs: structured_random_mask(base_layer, r, pattern="strips", orientation="horizontal", **kwargs),
    'strips_vertical': lambda base_layer, r, **kwargs: structured_random_mask(base_layer, r, pattern="strips", orientation="vertical", **kwargs),
    'checkerboard': lambda base_layer, r, **kwargs: structured_random_mask(base_layer, r, pattern="checkerboard", **kwargs),
    'diagonal': lambda base_layer, r, **kwargs: structured_random_mask(base_layer, r, pattern="diagonal", **kwargs),
    'attention_heads': attention_head_mask,
    'hybrid': hybrid_structured_mask,
}


def get_structured_mask_function(mask_type: str):
    """
    Get a structured mask function by name.
    
    Args:
        mask_type: Name of the mask type
        
    Returns:
        Mask function that can be used with Shira
    """
    if mask_type not in STRUCTURED_MASK_FUNCTIONS:
        available = list(STRUCTURED_MASK_FUNCTIONS.keys())
        raise ValueError(f"Unknown structured mask type: {mask_type}. Available: {available}")
    
    return STRUCTURED_MASK_FUNCTIONS[mask_type]
