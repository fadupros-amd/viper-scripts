from logging import Logger
import math
from typing import Any, Callable, List, Optional, Type, Union

import numpy as np
from pytorch_lightning import LightningModule
from pytorch_lightning.utilities import rank_zero_only
#from bcos import BcosUtilMixin
from utils.explanations import BcosUtilMixin
from modules.adapters.conv_adapter import ConvAdapter
#from models.utils import BcosifierMixin

import torch
from torch import nn
from bcos.models.resnet import LogitLayer, BasicBlock#, BcosConv2d
from modules.bcos_conv import BcosConv2d
from bcos.modules import NoBias, norms
from modules.norms.batchnorm_uncentered import BatchNormUncentered2d
from modules.norms.layernorm import DetachableLayerNorm
from torchvision.ops import StochasticDepth

from modules.bcos_conv import BcosConv2d_unnormed
from modules.blocks import Bottleneck, BottleneckReLU, AdapterBottleneck, conv1x1, conv3x3

from utils.norms import DynamicTanh

from modules.concept_layer import ConceptLayer
from modules.defaults import DEFAULT_ACT_LAYER, DEFAULT_CONV_LAYER, DEFAULT_CONV_LAYER_ADAPTER, DEFAULT_NORM_LAYER
from modules.bcos_linear import BcosLinear, BcosUnnormedLinear

from lightning.pytorch.utilities.model_summary.model_summary import ModelSummary
from bcos.modules.common import BcosSequential
from modules.activations import DetachableGELU
from transformers import ViTModel

def get_bottleneck(bottleneck):
    # if bottleneck == "bottleneck_d1":
    #     bottleneck_class = Bottleneck_d1
    # elif bottleneck == "reversebottleneck_d3":
    #     bottleneck_class = ReverseBottleneck_d3
    # elif bottleneck == "bottleneck_d3":
    #     bottleneck_class = Bottleneck_d3
    if bottleneck == "bottleneck_relu":
        bottleneck_class = BottleneckReLU
    elif bottleneck == "bottleneck":
        bottleneck_class = Bottleneck
    elif bottleneck == "adapterbottleneck":
        bottleneck_class = AdapterBottleneck
    elif bottleneck == None or bottleneck == "None":
        bottleneck_class = None
    else:
        raise Exception(f"Bottleneck_class {bottleneck} does not exist.")
    return bottleneck_class

def get_norm(name):
    if name.lower() == "BatchNormUncentered2d".lower():
        return NoBias(BatchNormUncentered2d)
    elif name.lower() == "tanh":
        return torch.nn.Tanh
    elif name.lower() == "DynamicTanh".lower():
        return DynamicTanh
    elif name.lower() == "LayerNorm".lower():
        return NoBias(DetachableLayerNorm)
    else:
        raise Exception(f"Norm {name} not yet implemented.")


def get_linear_layer(name) -> Type[Union[BcosLinear, BcosUnnormedLinear]]:
    if name.lower() == "BcosLinear".lower():
        return BcosLinear
    elif name.lower() == "BcosUnnormedLinear".lower():
        return BcosUnnormedLinear
    else:
        raise Exception(f"Norm {name} not yet implemented.")

def get_conv(conv):
    if conv.lower() == "BcosConv2d".lower():
        return BcosConv2d
    elif conv.lower() == "BcosConv2d_unnormed".lower():
        return BcosConv2d_unnormed
    elif conv.lower() == "BcosConv2d_unnormed_adapter".lower():
        raise Exception("BcosConv2d_unnormed_adapter is not supported anymore, use BcosConv2d_unnormed instead.")
    else:
        raise Exception(f"Unkown name for convolution: {conv}")

def get_act_layer(act_layer):
    if act_layer == None:
        return None
    elif act_layer.lower() == "relu":
        return nn.ReLU
    elif act_layer.lower() == "silu":
        return nn.SiLU
    elif act_layer.lower() == "gelu":
        return DetachableGELU
    elif act_layer.lower() == "identity":
        return nn.Identity
    elif act_layer.lower() == "None".lower():
        return None
    else:
        raise Exception(f"Unknown activation layer: {act_layer}")

class LayerBGetter():
    '''
    Small getter for retrieving the layer-specific b value (if applicable). Otherwise returns the layer-default value.
    '''
    def __init__(self, overwrite_b_for_layer, default_layer_b):
        print(overwrite_b_for_layer)
        self.default_layer_b = default_layer_b
        self.overwrite_b_for_layer = overwrite_b_for_layer

    def by_name(self, layer_name):
        b = self.overwrite_b_for_layer.get(layer_name, self.default_layer_b) if self.overwrite_b_for_layer else self.default_layer_b
        print(f"Checking b value, was: {b} for layer {layer_name}")
        return b
    

def log_new_section(message: str, logger: Logger = None) -> None:
    """
    Logs a new section with a specific indentation level.
    """
    logger.info("\n------------")
    logger.info(f"{message}")  # Replace with your logging method if needed
    logger.info("------------\n")


def get_parameter_numbers(model: LightningModule) -> tuple[int, int]:
    summary = ModelSummary(model, max_depth=-1) # Use -1 or appropriate depth
    total_params = summary.total_parameters
    trainable_params = summary.trainable_parameters
    return total_params, trainable_params

def is_bcos(model) -> bool:
    """
    Check if a model is a B-cos model.
    
    Args:
        model: The model to check
        
    Returns:
        bool: True if the model is a B-cos model, False otherwise
    """
    # Get the base model if it's wrapped (e.g., by torch.compile)
    base_model = getattr(model, '_orig_mod', model)
    
    if isinstance(base_model, BcosSequential):
        return is_bcos(base_model[0])
    
    
    # Check if the model has B-cos specific attributes or is from bcos library
    return hasattr(base_model, 'explain') or 'bcos' in str(type(base_model)).lower()


def is_simple_vit(model) -> bool:
    """
    Check if a model is a Simple Vision Transformer.
    
    Args:
        model: The model to check
        
    Returns:
        bool: True if the model is a Simple ViT, False otherwise
    """
    # Get the base model if it's wrapped
    base_model = getattr(model, '_orig_mod', model)
    
    # Check if it's a SimpleViT or similar ViT model
    return 'simplevit' in str(type(base_model)).lower() or 'vit' in str(type(base_model)).lower()

def is_vit(model) -> bool:
    if is_simple_vit(model):
        return True
    
    if issubclass(type(model), ViTModel):
        return True

    if hasattr(model, "model"):
        return is_vit(model.model)
    
    return False

def get_layer_from_experiment(experiment, model):
    """
    Get the appropriate layer from a model based on experiment configuration.
    
    Args:
        experiment: The experiment configuration object
        model: The model to extract layer from
        
    Returns:
        The layer to use for explanations (e.g., for GradCAM)
    """
    # Get the base model if it's wrapped
    base_model = getattr(model, '_orig_mod', model)
    
    # For ResNet models, typically use the last convolutional layer before the classifier
    if hasattr(base_model, 'layer4'):
        return base_model.layer4
    elif hasattr(base_model, 'features'):
        # For other CNN architectures with a 'features' attribute
        return base_model.features[-1]
    elif hasattr(base_model, 'blocks'):
        # For Vision Transformers
        return base_model.blocks[-1]
    else:
        # Fallback: return the model itself (may not work for all cases)
        return base_model


@rank_zero_only
def test_bcos_model(test_model, device, num_labels = 200):                                                              

    if not is_bcos(test_model): 
        print(f"Model on device {device} is not a bcos model: no sanity check.")
        return


    # test_model = getattr(test_model, "_orig_mod", test_model)
    # setup model for evaluation mode                                                         
    test_model.eval()         

    # can replace the below as: with test_model.explanation_mode():                                                         
    with test_model.explanation_mode():                                                                                                                                   
        # setting up the remaining test                                                           
        im_var = torch.randn((1, 3, 224, 224)).clone().detach().requires_grad_(True).to(device)                                               
        im_var = torch.cat([im_var, 1-im_var], dim=1)  # Create a 6-channel input for B-cos

        tgt = np.random.randint(num_labels) 
        if hasattr(test_model, "forward_test"):
            print("Using forward_test method for B-cos model")
            # If the model has a forward_test method, use it
            out = test_model.forward_test(im_var)[0, tgt]   
        else:
            # Otherwise, use the standard forward method                                                    
            out = test_model(im_var)[0, tgt]    
            
        im_var_grad, = torch.autograd.grad(
                outputs=out,            # The scalar output we're differentiating
                inputs=im_var,        # The input we want the gradient w.r.t.
                retain_graph=None,    # Default is usually fine; no need to keep graph for this
                create_graph=False    #x^ No need for higher-order derivatives here
            )
        # out.sum().backward() 
        # im_var_grad = im_var.grad
                                                        

        contrib_sum = (im_var*im_var_grad).sum()
        logit_bias = test_model.logit_layer.logit_bias
        out = out - logit_bias
        result = torch.allclose(out.to(torch.float32), contrib_sum.to(torch.float32), atol=1e-4)
        print(f"Sanity check resulted in {result} with output ",  out.item()," and contribution product ", contrib_sum.item())                                             
        print(f"Difference in sanity check was {out.item() - contrib_sum.item()}")                                             
        assert result, "Sanity fails :( "  
        print(f"Sanity check succeeded for model on device {device}.")