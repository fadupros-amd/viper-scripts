from bcos.modules import DetachableModule
import torch
import numpy as np

class DetachableGELU(DetachableModule):
    def forward(self, x):
        gate = 0.5 * (1 + torch.erf(x/torch.sqrt(torch.tensor(2.0))))
        if self.detach:
            gate = gate.detach()
        return gate * x