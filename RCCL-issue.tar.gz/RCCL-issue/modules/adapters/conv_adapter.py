from torch import nn
import torch.nn.functional as F
import torch
from modules.conv import conv1x1, conv3x3, DEFAULT_CONV_LAYER
from modules.bcos_conv import BcosConv2d_unnormed
from modules.legacy.defaults import DEFAULT_ACT_LAYER, DEFAULT_CONV_LAYER, DEFAULT_CONV_LAYER_ADAPTER, DEFAULT_NORM_LAYER

class ConvAdapter(nn.Module):
    """
    Design 2 v4
    """
    def __init__(self, inplanes, outplanes, width, 
                 kernel_size=3, padding=1, stride=1, groups=1, dilation=1, norm_layer=None, act_layer=None, conv_layer = DEFAULT_CONV_LAYER_ADAPTER, b:int = 1, **kwargs):
        super().__init__()

        if norm_layer is None:
            norm_layer = nn.Identity
        if act_layer is None:
            act_layer = nn.Identity

        groups = int(min(groups, inplanes))
        width = int(width)
        #print(f"In channels were {inplanes} with outplanes {outplanes} and width {width} and groups {groups}")

        # self.act = nn.SiLU()

        # depth-wise conv
        self.conv1 = conv_layer(inplanes, width, kernel_size=kernel_size, stride=stride, groups=groups, padding=padding, dilation=int(dilation), b=b)
        #self.conv1 = nn.Conv2d(inplanes, width, kernel_size=kernel_size, stride=stride, groups=groups, padding=padding, dilation=int(dilation))
        self.act = act_layer()

        # poise-wise conv
        self.conv2 = conv_layer(width, outplanes, kernel_size=1, stride=1, b=b)
        #self.alpha = nn.Parameter(1.0 * torch.ones((1, outplanes, 1, 1)), requires_grad=True)
        #self.conv2 = nn.Conv2d(width, outplanes, kernel_size=1, stride=1)

    
    def forward(self, x):
        out = self.conv1(x)
        # out = self.norm(out)
        out = self.act(out)
        out = self.conv2(out)
        #out = out * self.alpha
        return out

class DynamicBias(nn.Module):
    """
    Dynamic bias layer that learns a bias term for each channel.
    """
    def __init__(self, num_channels, b=1, factor=16):
        super().__init__()
        width = num_channels//factor
        self.pool = nn.AdaptiveAvgPool2d((1, 1)) 
        self.down = BcosConv2d_unnormed(num_channels, width, b=b, kernel_size=1)
        self.up = BcosConv2d_unnormed(width, num_channels, b=b,  kernel_size=1)  # Use a 1x1 convolution to learn the bias
        

    def forward(self, x):
        out = self.pool(x)  # Global average pooling
        out = self.down(out) # Apply the linear layer to learn the bias
        out = self.up(out)
        return out + x # Add the learned bias to the input