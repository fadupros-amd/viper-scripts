# lora_adapters.py
from functools import partial
import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Optional, Union
import math
from modules.bcos_linear import BcosLinear, BcosUnnormedLinear

class LoRALayer(nn.Module):
    """Base LoRA layer implementation"""
    def __init__(
        self,
        r: int,
        lora_alpha: int,
        lora_dropout: float = 0.0,
        merge_weights: bool = True,
        initialization_mode = "kaiming-uniform",
        b = 2,
    ):
        super().__init__()
        self.r = r
        self.lora_alpha = lora_alpha
        self.lora_dropout = nn.Dropout(p=lora_dropout) if lora_dropout > 0.0 else nn.Identity()
        self.merge_weights = merge_weights
        self.merged = False
        self.initialization_mode = initialization_mode
        
    def reset_parameters(self):
        """Initialize LoRA parameters"""

        assert getattr(self, 'lora_A', None) is not None, "LoRA A matrix must be defined before resetting parameters."
        assert getattr(self, 'lora_B', None) is not None, "LoRA B matrix must be defined before resetting parameters."

        initialization_mode = self.initialization_mode.lower()
        if initialization_mode in ["kaiming-uniform", "kaiming_uniform"]:
            fnA = partial(nn.init.kaiming_uniform_, a=math.sqrt(5))
            fnB = fnA
        elif initialization_mode in ["xavier-uniform", "xavier_uniform"]:
            fnA = nn.init.xavier_uniform_
            fnB = fnA
        elif initialization_mode == "normal":
            fnA = nn.init.normal_
            fnB = fnA
        elif initialization_mode == "standard":
            fnA = partial(nn.init.kaiming_uniform, a=math.sqrt(5))
            fnB = nn.init.zeros_
        else:
            raise ValueError(f"Unknown initialization mode: {self.initialization_mode}")
        
        # Initialize LoRA A matrix
        if hasattr(self, 'lora_A'):
            fnA(self.lora_A.linear.weight)
        else:
            raise AttributeError("LoRA A matrix is not defined. Ensure it is initialized in the subclass.")
        if hasattr(self, 'lora_B'):
            fnB(self.lora_B.linear.weight)
        else:
            raise AttributeError("LoRA B matrix is not defined. Ensure it is initialized in the subclass.")
        
        if hasattr(self, "hidden_layers"):
            if self.hidden_layers is not None:
                for layer in self.hidden_layers:
                    print(f"Resetting parameters for hidden layer: {layer}")
                    if hasattr(layer, 'linear'):
                        fnA(layer.linear.weight)
                
        else:
            raise AttributeError("Hidden layers are not defined. Ensure they are initialized in the subclass.")


class LoRALinear(LoRALayer):
    """LoRA adaptation for Linear layers"""
    def __init__(
        self,
        base_layer: nn.Module,
        r: int = 16,
        lora_alpha: int = 16,
        lora_dropout: float = 0.0,
        merge_weights: bool = True,
        linear_layer: Union[BcosLinear, BcosUnnormedLinear] = BcosUnnormedLinear,
        act_layer: Optional[nn.Module] = None,
        depth: int = 0,
        use_input_norm: bool = False,
        initialization_mode: str = "kaiming_uniform",
        **kwargs
    ):
        super().__init__(r, lora_alpha, lora_dropout, merge_weights, initialization_mode)
        
        # Store reference to base layer
        self.base_layer = base_layer
        self.in_features = base_layer.in_features
        self.out_features = base_layer.out_features
        self.depth = depth
        self.use_input_norm = use_input_norm
        self.linear_layer = linear_layer
        self.r = r
        
        # LoRA parameters
        if r > 0:
            # Optional input normalization for gradient stabilization
            if self.use_input_norm:
                self.input_norm = nn.LayerNorm(self.in_features)
            
            self.lora_A = linear_layer(self.in_features, r, bias=False)
            
            if act_layer:
                self.activation = act_layer()
            else:
                self.activation = nn.Identity()
            
            self.hidden_layers = nn.ModuleList()
            
            # Add depth layers if specified
            for d in range(depth):
                self.hidden_layers.append(linear_layer(r, r, bias=False))
                if act_layer:
                    self.hidden_layers.append(act_layer())
                else:
                    self.hidden_layers.append(nn.Identity())

            self.lora_B = linear_layer(r, self.out_features, bias=False)
            self.scaling = self.lora_alpha / self.r

            self.reset_parameters()

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # Base layer computation
        result = self.base_layer(x)
        
        # Add LoRA adaptation if not merged
        if self.r > 0 and not self.merged:
            # Apply input normalization if enabled
            lora_input = x
            if self.use_input_norm:
                lora_input = self.input_norm(x)
            
            lora_result = self.lora_A(self.lora_dropout(lora_input))
            lora_result = self.activation(lora_result)

            # Pass through hidden layers if any
            for layer in self.hidden_layers:
                lora_result = layer(lora_result)
            
            # Final LoRA computation
            lora_result = self.lora_B(lora_result)

            # print(f"Result shape before LoRA add: {result.shape}")
            result = result + lora_result * self.scaling
            
        return result
    
    def merge(self):
        """Merge LoRA weights into base layer"""
        if self.depth > 0:
            raise NotImplementedError("Merging with depth layers is not implemented.")
        if self.merge_weights and not self.merged:
            if self.r > 0:
                # Compute LoRA weight matrix
                lora_weight = self.lora_B.linear.weight @ self.lora_A.linear.weight * self.scaling
                # Add to base layer weights
                self.base_layer.weight.data += lora_weight
                self.merged = True
    
    def unmerge(self):
        """Unmerge LoRA weights from base layer"""
        if self.depth > 0:
            raise NotImplementedError("Merging with depth layers is not implemented.")
        if self.merge_weights and self.merged:
            if self.r > 0:
                lora_weight = self.lora_B.linear.weight @ self.lora_A.linear.weight * self.scaling
                self.base_layer.weight.data -= lora_weight
                self.merged = False

# class DoRALinear(LoRALayer):
#     def __init__(self, base_layer, r=16, lora_alpha=16, **kwargs):
#         super().__init__(r, lora_alpha, **kwargs)
#         self.base_layer = base_layer
#         self.in_features = base_layer.in_features
#         self.out_features = base_layer.out_features
        
#         if r > 0:
#             # Use standard linear layers for LoRA matrices
#             self.lora_A = nn.Linear(self.in_features, r, bias=False)
#             self.lora_B = nn.Linear(r, self.out_features, bias=False)
#             self.scaling = lora_alpha / r
            
#             # DoRA magnitude parameter
#             self.m = nn.Parameter(
#                 self.base_layer.linear.weight.norm(p=2, dim=0, keepdim=True)
#             )
            
#             self.reset_parameters()
    
#     def forward(self, x):
#         if self.r == 0:
#             return self.base_layer(x)
        
#         # Compute LoRA matrices
#         lora = self.lora_B.weight @ self.lora_A.weight
        
#         # DoRA decomposition
#         base_weight = self.base_layer.linear.weight
#         numerator = base_weight + self.scaling * lora
#         denominator = numerator.norm(p=2, dim=0, keepdim=True)
#         directional_component = numerator / denominator
#         new_weight = self.m * directional_component
        
#         # Apply B-cos transformation to the result
#         # This preserves the base layer's B-cos properties
#         temp_linear = type(self.base_layer.linear)(
#             self.in_features, self.out_features, bias=False
#         )
#         temp_linear.weight.data = new_weight
        
#         # Create temporary BcosLinear with same parameters
#         temp_bcos = type(self.base_layer)(
#             self.in_features, self.out_features, 
#             b=self.base_layer.b, **self.base_layer.extra_kwargs
#         )
#         temp_bcos.linear = temp_linear
        
#         return temp_bcos(x)

class DoRALinear(LoRALayer):
    """DoRA adapter with in-place weight modification"""
    def __init__(
        self,
        base_layer: nn.Module,
        r: int = 16,
        lora_alpha: int = 16,
        lora_dropout: float = 0.0,
        merge_weights: bool = True,
        linear_layer: Union[BcosLinear, BcosUnnormedLinear] = BcosUnnormedLinear,
        act_layer: Optional[nn.Module] = None,
        depth: int = 0,
        use_input_norm: bool = False,
        initialization_mode: str = "kaiming_uniform",
        **kwargs
    ):
        self.hidden_layers = None
        assert act_layer is None, "DoRA does not support activation layers"
        assert depth == 0, "DoRA does not support depth layers"
        assert use_input_norm is False, "DoRA does not support input normalization"

        super().__init__(r, lora_alpha, lora_dropout, merge_weights, initialization_mode)
        

        self.base_layer = base_layer
        self.in_features = base_layer.in_features
        self.out_features = base_layer.out_features
        self.hidden_layers = None
        
        if r > 0:
            # Use the same linear layer type as base layer for LoRA components
            # This preserves the architectural consistency
            self.lora_A = linear_layer(
                self.in_features, r, bias=False
            )
            self.lora_B = linear_layer(
                r, self.out_features, bias=False
            )
            self.scaling = lora_alpha / r
            
            # DoRA magnitude parameter - initialize from base layer weights
            with torch.no_grad():
                self.m = nn.Parameter(
                    base_layer.linear.weight.norm(p=2, dim=0, keepdim=True).clone()
                )
            
            self.reset_parameters()

    
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        if self.r == 0:
            return self.base_layer(x)
        
        # Temporarily modify the base layer's weights
        original_weight = self.base_layer.linear.weight.data.clone()
        
        try:
            # Apply DoRA modification
            lora_delta = self.lora_B.linear.weight @ self.lora_A.linear.weight * self.scaling
            combined_weight = original_weight + lora_delta
            
            # DoRA decomposition
            weight_norm = combined_weight.norm(p=2, dim=0, keepdim=True)
            directional_component = combined_weight / (weight_norm + 1e-8)
            dora_weight = self.m * directional_component
            
            # Temporarily replace weights
            self.base_layer.linear.weight.data = dora_weight
            
            # Forward pass with modified weights
            result = self.base_layer(x)
            
        finally:
            # Restore original weights
            self.base_layer.linear.weight.data = original_weight
            
        return result


class NEATLoRALinear(LoRALinear):
    def __init__(
        self,
        *args,
        **kwargs
    ):
        super().__init__(
            *args,
            **kwargs
        )
        if self.r > 0:
            self.lora_B = self.linear_layer(self.r, self.in_features, bias=False)
        self.reset_parameters()
    
    def forward(self, x):
        assert self.r > 0, "NEATLoRALinear requires r > 0"

        W = self.base_layer.linear.weight
        # print(f"Base layer weight shape: {W.shape}")
        # Ax and dropout
        lora_matrix = self.lora_dropout(self.lora_A(x))
        # print(f"LoRA A output shape: {lora_matrix.shape}")

        # act(Ax)
        lora_matrix = self.activation(lora_matrix)

        # h(act(Ax))
        for layer in self.hidden_layers:
            lora_matrix = layer(lora_matrix)
        # print(f"LoRA hidden layer output shape: {lora_matrix.shape}")

        # B(h(act(Ax))) * scale
        lora_matrix = self.lora_B(lora_matrix)
        lora_matrix = lora_matrix * self.scaling
        # print(f"LoRA B output shape: {lora_matrix.shape}")

        # W * B(h(act(Ax)))
        lora_matrix = self.base_layer(lora_matrix)

        # Wx
        linear_out = self.base_layer(x)

        return lora_matrix + linear_out



class LoRAConfig:
    """Configuration class for LoRA adapters"""
    def __init__(
        self,
        r: int = 16,
        lora_alpha: int = 16,
        lora_dropout: float = 0.0,
        target_modules: Optional[list] = None,
        merge_weights: bool = True,
        enable_lora: bool = True,
        linear_layer: Union[BcosLinear, BcosUnnormedLinear] = BcosUnnormedLinear,
        use_layer_b: bool = False,
        act_layer: Optional[str] = None,
        depth: int = 0,
        use_input_norm: bool = False,
        initialization_mode: str = "kaiming_uniform",
        neat: bool = False,
        mode: str = "lora",
    ):
        dora = mode.lower()=="dora"
        assert not (neat and dora), "Cannot use both NEAT and DORA at the same time"
        assert not (dora and depth != 0), "DORA does not support depth layers"

        self.r = r
        self.lora_alpha = lora_alpha
        self.lora_dropout = lora_dropout
        self.target_modules = target_modules if target_modules is not None else ["to_qkv", "to_out", "linear1", "linear2"]
        self.merge_weights = merge_weights
        self.enable_lora = enable_lora
        self.linear_layer = linear_layer
        self.use_layer_b = use_layer_b
        self.act_layer = act_layer
        self.depth = depth
        self.use_input_norm = use_input_norm
        self.initialization_mode = initialization_mode
        self.neat = neat
        self.mode = mode

def apply_lora_to_linear(module: nn.Module, config: LoRAConfig) -> nn.Module:
    """Replace linear layer with LoRA-enabled version"""
    if isinstance(module, (BcosLinear, BcosUnnormedLinear)) and config.enable_lora:
        # If B of layer should be used
        linear_layer = config.linear_layer
        if config.use_layer_b:
            linear_layer = partial(config.linear_layer, b=module.b)

        args = {
            'base_layer': module,
            'r': config.r,
            'lora_alpha': config.lora_alpha,
            'lora_dropout': config.lora_dropout,
            'merge_weights': config.merge_weights,
            'linear_layer': linear_layer,
            'act_layer': config.act_layer,
            'depth': config.depth,
            'use_input_norm': config.use_input_norm,
            'initialization_mode': config.initialization_mode
        }

        if config.neat:
            return NEATLoRALinear(**args)
        elif config.mode == "dora":
            return DoRALinear(**args)
        else:
            return LoRALinear(**args)
        
    return module
