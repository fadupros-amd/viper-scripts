# lora_vit_wrapper.py
import torch
import torch.nn as nn
from typing import Optional, Dict, Any, Union, List

from modules.bcos_linear import BcosLinear, BcosUnnormedLinear
from .lora import LoRAConfig, LoRALinear, apply_lora_to_linear
from .wrapper_base import ModelWrapperBase

class LoRAViTWrapper(ModelWrapperBase):
    """Clean wrapper to add LoRA capabilities to any ViT model"""
    
    def __init__(
        self,
        base_model: nn.Module,
        lora_config: LoRAConfig,
        log: Optional[Any] = None
    ):
        super().__init__(base_model, log=log)
        self.lora_config = lora_config
        self.lora_layers = {}
        
        # Apply LoRA using the generic base class method
        name_mapping = self._apply_modifications_recursive(
            target_modules=self.lora_config.target_modules,
            module_filter_fn=self._should_apply_modification,
            modification_fn=self._apply_modification_to_module
        )
        self._record_name_changes(name_mapping)
        
        if self.log: 
            self.log.info(f"Applied LoRA to {len(self.lora_layers)} layers in the model.")
            self.log.info(f"Recorded {len(name_mapping)} parameter name changes due to LoRA.")
    
    def _should_apply_modification(self, module_name: str, module: nn.Module) -> bool:
        """Determine if LoRA should be applied to this module"""
        # Only target BcosLinear/BcosUnnormedLinear, not regular nn.Linear or internal layers
        if not isinstance(module, (BcosLinear, BcosUnnormedLinear)):
            return False
        
        # Check if module name matches target patterns
        for target in self.lora_config.target_modules:
            if target in module_name:
                # Additional check: make sure we're not targeting internal .linear layers
                if module_name.endswith('.linear'):
                    print(f"LoRA skipping internal layer: {module_name}")
                    return False
                print(f"LoRA target match: {module_name} matches pattern '{target}'")
                return True
        
        # Debug: Print non-matches for BcosLinear layers
        print(f"LoRA no match: {module_name} (BcosLinear layer, but no target match)")
        return False
    
    def _apply_modification_to_module(self, module: nn.Module) -> nn.Module:
        """Apply LoRA to a specific module"""
        lora_layer = apply_lora_to_linear(module, self.lora_config)
        if lora_layer != module:  # LoRA was actually applied
            # Store the LoRA layer for later access
            self.lora_layers[f"{id(module)}"] = lora_layer  # Use id temporarily
        return lora_layer
    
    def _create_parameter_mapping(
        self, 
        module_name: str, 
        original_param_names: List[str], 
        new_param_names: List[str]
    ) -> Dict[str, str]:
        """
        Create parameter name mapping for LoRA modifications.
        Override the base class method with LoRA-specific logic.
        """
        mapping = {}
        
        for original_name in original_param_names:
            # Extract the parameter suffix (e.g., "weight", "bias")
            param_suffix = original_name.split(".")[-1]
            
            # LoRA-specific patterns for finding the new location
            possible_new_names = [
                # LoRA wraps the original layer in base_layer
                f"{module_name}.base_layer.{param_suffix}",
                f"{module_name}.base_layer.linear.{param_suffix}",
                # Fallback to direct mapping
                original_name,
            ]
            
            # Find the first matching new name
            for possible_name in possible_new_names:
                if possible_name in new_param_names:
                    mapping[original_name] = possible_name
                    if self.log:
                        self.log.debug(f"LoRA mapped: {original_name} -> {possible_name}")
                    break
            else:
                # If no direct mapping found, log warning
                if self.log:
                    self.log.warning(f"Could not find LoRA mapping for {original_name}")
                    self.log.debug(f"Available new names: {new_param_names}")
        
        return mapping
    
    def merge_lora_weights(self):
        """Merge all LoRA weights into base model"""
        for lora_layer in self.lora_layers.values():
            if hasattr(lora_layer, 'merge'):
                lora_layer.merge()
    
    def unmerge_lora_weights(self):
        """Unmerge all LoRA weights from base model"""
        for lora_layer in self.lora_layers.values():
            if hasattr(lora_layer, 'unmerge'):
                lora_layer.unmerge()
    
    def get_trainable_parameters(self):
        """Get only LoRA parameters for training"""
        params = []
        for layer in self.lora_layers.values():
            if hasattr(layer, 'lora_A'):
                params.extend(layer.lora_A.parameters())
            if hasattr(layer, 'lora_B'):
                params.extend(layer.lora_B.parameters())
        return params
    
    def freeze_base_model(self):
        """Freeze base model parameters, keep only LoRA trainable"""
        for param in self.base_model.parameters():
            param.requires_grad = False
        
        # Ensure LoRA parameters are trainable
        for param in self.get_trainable_parameters():
            param.requires_grad = True
    
    def print_trainable_parameters(self):
        """Print training parameter statistics"""
        total_params = sum(p.numel() for p in self.base_model.parameters())
        lora_params = sum(p.numel() for p in self.get_trainable_parameters())
        
        print(f"Total parameters: {total_params:,}")
        print(f"LoRA parameters: {lora_params:,}")
        print(f"Trainable parameters: {lora_params / total_params * 100:.2f}%")
