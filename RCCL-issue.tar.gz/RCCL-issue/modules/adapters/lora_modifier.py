# lora_modifier.py
import torch
import torch.nn as nn
from typing import Optional, Dict, Any, Union, List

from modules.bcos_linear import BcosLinear, BcosUnnormedLinear
from .lora import LoRAConfig, LoRALinear, apply_lora_to_linear
from .modifier_base import ModelModifierBase

class LoRAModelModifier(ModelModifierBase):
    """Modifies a model in-place to add LoRA capabilities, then returns the modified model"""
    
    def __init__(self, lora_config: LoRAConfig, log: Optional[Any] = None):
        super().__init__(log=log)
        self.lora_config = lora_config
    
    def _should_modify_module(self, module_name: str, module: nn.Module) -> bool:
        """Determine if LoRA should be applied to this module"""
        if not isinstance(module, (BcosLinear, BcosUnnormedLinear, nn.Linear)):
            return False
            
        # Check if module name matches target patterns
        for target in self.lora_config.target_modules:
            if target in module_name:
                return True
        return False
    
    def _modify_module(self, module: nn.Module, module_name: str) -> nn.Module:
        """Apply LoRA to a specific module"""
        return apply_lora_to_linear(module, self.lora_config)
    
    def _group_module(self, module_name: str, module: nn.Module):
        """Group LoRA modules by their location in the model"""
        super()._group_module(module_name, module)  # Default grouping by type
        
        # Additional LoRA-specific grouping
        if 'attention' in module_name.lower():
            if 'attention_modules' not in self.layer_groups:
                self.layer_groups['attention_modules'] = []
            self.layer_groups['attention_modules'].append(module)
        
        if 'mlp' in module_name.lower() or 'feedforward' in module_name.lower():
            if 'mlp_modules' not in self.layer_groups:
                self.layer_groups['mlp_modules'] = []
            self.layer_groups['mlp_modules'].append(module)
        
        # Group by layer number if possible
        try:
            # Extract layer number from names like "layers.0.attention" or "blocks.1.mlp"
            parts = module_name.split('.')
            for i, part in enumerate(parts):
                if part.isdigit():
                    layer_num = int(part)
                    group_name = f'layer_{layer_num}'
                    if group_name not in self.layer_groups:
                        self.layer_groups[group_name] = []
                    self.layer_groups[group_name].append(module)
                    break
        except (ValueError, IndexError):
            pass  # No layer number found
    
    def _create_parameter_mapping(
        self, 
        module_name: str, 
        original_param_names: List[str], 
        new_param_names: List[str]
    ) -> Dict[str, str]:
        """Create parameter name mapping for LoRA modifications"""
        mapping = {}
        
        for original_name in original_param_names:
            # Extract the parameter suffix (e.g., "weight", "bias")
            param_suffix = original_name.split(".")[-1]
            
            # LoRA-specific patterns for finding the new location
            possible_new_names = [
                # LoRA wraps the original layer in base_layer
                f"{module_name}.base_layer.{param_suffix}",
                f"{module_name}.base_layer.linear.{param_suffix}",
                # Fallback to direct mapping
                original_name,
            ]
            
            # Find the first matching new name
            for possible_name in possible_new_names:
                if possible_name in new_param_names:
                    mapping[original_name] = possible_name
                    if self.log:
                        self.log.debug(f"LoRA mapped: {original_name} -> {possible_name}")
                    break
            else:
                # If no direct mapping found, log warning
                if self.log:
                    self.log.warning(f"Could not find LoRA mapping for {original_name}")
                    self.log.debug(f"Available new names: {new_param_names}")
        
        return mapping
    
    def _add_methods_to_model(self, model: nn.Module):
        """Add LoRA-specific methods to the model"""
        super()._add_methods_to_model(model)  # Add base methods
        
        def merge_lora_weights():
            """Merge all LoRA weights into base model"""
            modifier_info = getattr(model, '_modifier_info', {})
            lora_info = modifier_info.get('LoRAModelModifier', {})
            for lora_layer in lora_info.get('modified_modules', {}).values():
                if hasattr(lora_layer, 'merge'):
                    lora_layer.merge()
        
        def unmerge_lora_weights():
            """Unmerge all LoRA weights from base model"""
            modifier_info = getattr(model, '_modifier_info', {})
            lora_info = modifier_info.get('LoRAModelModifier', {})
            for lora_layer in lora_info.get('modified_modules', {}).values():
                if hasattr(lora_layer, 'unmerge'):
                    lora_layer.unmerge()
        
        def get_lora_parameters():
            """Get only LoRA parameters for training"""
            params = []
            modifier_info = getattr(model, '_modifier_info', {})
            lora_info = modifier_info.get('LoRAModelModifier', {})
            for layer in lora_info.get('modified_modules', {}).values():
                if hasattr(layer, 'lora_A'):
                    params.extend(layer.lora_A.parameters())
                if hasattr(layer, 'lora_B'):
                    params.extend(layer.lora_B.parameters())
            return params
        
        def freeze_base_model():
            """Freeze base model parameters, keep only LoRA trainable"""
            for param in model.parameters():
                param.requires_grad = False
            
            # Ensure LoRA parameters are trainable
            for param in get_lora_parameters():
                param.requires_grad = True
        
        def print_lora_parameters():
            """Print LoRA parameter statistics"""
            total_params = sum(p.numel() for p in model.parameters())
            lora_params = sum(p.numel() for p in get_lora_parameters())
            
            print(f"Total parameters: {total_params:,}")
            print(f"LoRA parameters: {lora_params:,}")
            print(f"Trainable parameters: {lora_params / total_params * 100:.2f}%")
        
        # Attach LoRA-specific methods
        setattr(model, 'merge_lora_weights', merge_lora_weights)
        setattr(model, 'unmerge_lora_weights', unmerge_lora_weights)
        setattr(model, 'get_lora_parameters', get_lora_parameters)
        setattr(model, 'freeze_base_model', freeze_base_model)
        setattr(model, 'print_lora_parameters', print_lora_parameters)


def apply_lora_to_model(model: nn.Module, lora_config: LoRAConfig, log: Optional[Any] = None) -> nn.Module:
    """Convenience function to apply LoRA to a model and return the modified model"""
    modifier = LoRAModelModifier(lora_config, log)
    return modifier.apply_to_model(model)
