# modifier_base.py
import torch.nn as nn
from typing import Optional, Dict, Any, List, Callable, Set
from abc import ABC, abstractmethod

class ModelModifierBase(ABC):
    """Base class for all model modifiers that provides common functionality"""
    
    def __init__(self, log: Optional[Any] = None):
        self.log = log
        self.modified_modules: Dict[str, nn.Module] = {}  # name -> modified module
        self.original_modules: Dict[str, nn.Module] = {}  # name -> original module  
        self.parameter_mapping: Dict[str, str] = {}  # original_param -> new_param
        self.layer_groups: Dict[str, List[nn.Module]] = {}  # group_name -> list of modules
    
    def apply_to_model(self, model: nn.Module) -> nn.Module:
        """Apply modifications to the model in-place and return the modified model"""
        # Apply modifications
        name_mapping = self._apply_modifications_recursive(model)
        
        # Store mapping on the model for later use
        self._store_mappings_on_model(model, name_mapping)
        
        # Add modifier-specific methods to the model
        self._add_methods_to_model(model)
        
        if self.log: 
            self.log.info(f"Applied {self.__class__.__name__} to {len(self.modified_modules)} modules.")
            self.log.info(f"Recorded {len(name_mapping)} parameter name changes.")
        
        return model
    
    def _apply_modifications_recursive(self, model: nn.Module) -> Dict[str, str]:
        """Apply modifications recursively to the model"""
        name_mapping = {}
        
        def _apply_recursive(module, prefix=""):
            for name, child in module.named_children():
                full_name = f"{prefix}.{name}" if prefix else name
                
                # Check if this module should be modified
                if self._should_modify_module(full_name, child):
                    # Store original module
                    self.original_modules[full_name] = child
                    
                    # Capture parameter names before modification
                    original_param_names = []
                    for param_name, param in child.named_parameters():
                        original_param_names.append(f"{full_name}.{param_name}")
                    
                    # Apply modification
                    modified_module = self._modify_module(child, full_name)
                    
                    if modified_module != child:  # Modification was applied
                        if self.log: 
                            self.log.info(f"Applying {self.__class__.__name__} to {full_name}")
                        
                        # Replace the original module with the modified module
                        setattr(module, name, modified_module)
                        self.modified_modules[full_name] = modified_module
                        
                        # Capture parameter names after modification
                        new_param_names = []
                        for param_name, param in modified_module.named_parameters():
                            new_param_names.append(f"{full_name}.{param_name}")
                        
                        # Create mapping from original to new parameter names
                        module_mapping = self._create_parameter_mapping(
                            full_name, original_param_names, new_param_names
                        )
                        name_mapping.update(module_mapping)
                        
                        # Group modules for easier management
                        self._group_module(full_name, modified_module)
                
                # Recursively apply to children
                _apply_recursive(child, full_name)
        
        _apply_recursive(model)
        return name_mapping
    
    @abstractmethod
    def _should_modify_module(self, module_name: str, module: nn.Module) -> bool:
        """Determine if this module should be modified"""
        pass
    
    @abstractmethod
    def _modify_module(self, module: nn.Module, module_name: str) -> nn.Module:
        """Apply the modification to the module"""
        pass
    
    def _create_parameter_mapping(
        self, 
        module_name: str, 
        original_param_names: List[str], 
        new_param_names: List[str]
    ) -> Dict[str, str]:
        """
        Create parameter name mapping for a modified module.
        Can be overridden by subclasses for specific mapping logic.
        """
        mapping = {}
        
        for original_name in original_param_names:
            # Extract the parameter suffix (e.g., "weight", "bias")
            param_suffix = original_name.split(".")[-1]
            
            # Try common patterns for finding the new location
            possible_new_names = [
                # Direct mapping (no structure change)
                original_name,
                # Common wrapper patterns
                f"{module_name}.base_layer.{param_suffix}",
                f"{module_name}.base_layer.linear.{param_suffix}",
                f"{module_name}.original.{param_suffix}",
                f"{module_name}.wrapped.{param_suffix}",
            ]
            
            # Find the first matching new name
            for possible_name in possible_new_names:
                if possible_name in new_param_names:
                    mapping[original_name] = possible_name
                    if self.log:
                        self.log.debug(f"Mapped: {original_name} -> {possible_name}")
                    break
            else:
                # If no direct mapping found, log warning
                if self.log:
                    self.log.warning(f"Could not find mapping for {original_name}")
                    self.log.debug(f"Available new names: {new_param_names}")
        
        return mapping
    
    def _group_module(self, module_name: str, module: nn.Module):
        """Group modules for easier management. Can be overridden by subclasses."""
        # Default grouping by module type
        module_type = type(module).__name__
        if module_type not in self.layer_groups:
            self.layer_groups[module_type] = []
        self.layer_groups[module_type].append(module)
    
    def _store_mappings_on_model(self, model: nn.Module, name_mapping: Dict[str, str]):
        """Store mappings and module references on the model"""
        # Store parameter name mapping
        existing_mapping = getattr(model, '_parameter_name_mapping', {})
        existing_mapping.update(name_mapping)
        setattr(model, '_parameter_name_mapping', existing_mapping)
        
        # Store modifier info
        modifier_info = getattr(model, '_modifier_info', {})
        modifier_class_name = self.__class__.__name__
        modifier_info[modifier_class_name] = {
            'modified_modules': self.modified_modules,
            'original_modules': self.original_modules,
            'layer_groups': self.layer_groups,
            'parameter_mapping': name_mapping
        }
        setattr(model, '_modifier_info', modifier_info)
    
    def _add_methods_to_model(self, model: nn.Module):
        """Add common methods to the model. Can be extended by subclasses."""
        # Add freeze/unfreeze methods based on object references
        def freeze_modules_by_group(group_name: str):
            """Freeze all modules in a specific group"""
            modifier_info = getattr(model, '_modifier_info', {})
            for modifier_name, info in modifier_info.items():
                if group_name in info['layer_groups']:
                    for module in info['layer_groups'][group_name]:
                        for param in module.parameters():
                            param.requires_grad = False
        
        def unfreeze_modules_by_group(group_name: str):
            """Unfreeze all modules in a specific group"""
            modifier_info = getattr(model, '_modifier_info', {})
            for modifier_name, info in modifier_info.items():
                if group_name in info['layer_groups']:
                    for module in info['layer_groups'][group_name]:
                        for param in module.parameters():
                            param.requires_grad = True
        
        def freeze_modules_by_name_pattern(pattern: str):
            """Freeze modules whose names match a pattern"""
            modifier_info = getattr(model, '_modifier_info', {})
            for modifier_name, info in modifier_info.items():
                for module_name, module in info['modified_modules'].items():
                    if pattern in module_name:
                        for param in module.parameters():
                            param.requires_grad = False
        
        def get_modifier_info():
            """Get information about all applied modifiers"""
            return getattr(model, '_modifier_info', {})
        
        def get_modified_modules(modifier_name: Optional[str] = None):
            """Get modified modules, optionally filtered by modifier name"""
            modifier_info = getattr(model, '_modifier_info', {})
            if modifier_name:
                return modifier_info.get(modifier_name, {}).get('modified_modules', {})
            else:
                all_modules = {}
                for info in modifier_info.values():
                    all_modules.update(info['modified_modules'])
                return all_modules
        
        def get_layer_groups(modifier_name: Optional[str] = None):
            """Get layer groups, optionally filtered by modifier name"""
            modifier_info = getattr(model, '_modifier_info', {})
            if modifier_name:
                return modifier_info.get(modifier_name, {}).get('layer_groups', {})
            else:
                all_groups = {}
                for info in modifier_info.values():
                    for group_name, modules in info['layer_groups'].items():
                        if group_name not in all_groups:
                            all_groups[group_name] = []
                        all_groups[group_name].extend(modules)
                return all_groups
        
        # Attach methods to the model
        setattr(model, 'freeze_modules_by_group', freeze_modules_by_group)
        setattr(model, 'unfreeze_modules_by_group', unfreeze_modules_by_group)
        setattr(model, 'freeze_modules_by_name_pattern', freeze_modules_by_name_pattern)
        setattr(model, 'get_modifier_info', get_modifier_info)
        setattr(model, 'get_modified_modules', get_modified_modules)
        setattr(model, 'get_layer_groups', get_layer_groups)
