import torch.nn as nn
from typing import Dict, List, Tuple, Optional, Any, Callable
from collections import OrderedDict
from abc import ABC, abstractmethod

class NameMappingRegistry:
    """Registry to track parameter name changes across multiple wrappers"""
    
    def __init__(self):
        self.mappings: List[Dict[str, str]] = []  # List of mappings in order applied
        self.reverse_mappings: List[Dict[str, str]] = []  # Reverse mappings for efficiency
    
    def add_mapping(self, name_mapping: Dict[str, str]):
        """Add a name mapping from a wrapper (original_name -> new_name)"""
        self.mappings.append(name_mapping.copy())
        # Create reverse mapping (new_name -> original_name)
        reverse_mapping = {v: k for k, v in name_mapping.items()}
        self.reverse_mappings.append(reverse_mapping)
    
    def get_original_name(self, current_name: str) -> str:
        """Get the original parameter name from the current wrapped name"""
        # Apply reverse mappings in reverse order (most recent first)
        name = current_name
        for reverse_mapping in reversed(self.reverse_mappings):
            if name in reverse_mapping:
                name = reverse_mapping[name]
        return name
    
    def get_current_name(self, original_name: str) -> str:
        """Get the current parameter name from the original name"""
        # Apply mappings in order
        name = original_name
        for mapping in self.mappings:
            if name in mapping:
                name = mapping[name]
                break
        return name
    
    def transform_state_dict(self, state_dict: Dict[str, Any], original_to_current: bool = True) -> Dict[str, Any]:
        """Transform state dict keys between original and current names"""
        new_state_dict = {}
        
        for key, value in state_dict.items():
            if original_to_current:
                new_key = self.get_current_name(key)
            else:
                new_key = self.get_original_name(key)
            new_state_dict[new_key] = value
        
        return new_state_dict
    
    def clear(self):
        """Clear all mappings"""
        self.mappings.clear()
        self.reverse_mappings.clear()

class ModelWrapperBase(nn.Module):
    """Base class for model wrappers that provides delegation to base model"""
    
    def __init__(self, base_model: nn.Module, log=None):
        super().__init__()
        self.base_model: nn.Module = base_model
        self.log = log
        
        # Initialize or inherit name mapping registry
        if hasattr(base_model, '_name_mapping_registry'):
            self._name_mapping_registry = base_model._name_mapping_registry
        else:
            self._name_mapping_registry = NameMappingRegistry()
            # Set registry on base model so it can be accessed from lightning module
            setattr(self.base_model, '_name_mapping_registry', self._name_mapping_registry)
    
    def _record_name_changes(self, name_mapping: Dict[str, str]):
        """Record parameter name changes caused by this wrapper"""
        if self.log:
            self.log.info(f"Recording {len(name_mapping)} parameter name changes")
            for old_name, new_name in name_mapping.items():
                self.log.debug(f"  {old_name} -> {new_name}")
        
        self._name_mapping_registry.add_mapping(name_mapping)
    
    def get_original_parameter_name(self, wrapped_name: str) -> str:
        """Get the original parameter name from the wrapped name"""
        return self._name_mapping_registry.get_original_name(wrapped_name)
    
    def get_wrapped_parameter_name(self, original_name: str) -> str:
        """Get the wrapped parameter name from the original name"""
        return self._name_mapping_registry.get_current_name(original_name)
    
    def transform_state_dict_for_loading(self, state_dict: Dict[str, Any]) -> Dict[str, Any]:
        """Transform state dict keys from original names to current wrapped names"""
        return self._name_mapping_registry.transform_state_dict(state_dict, original_to_current=True)
    
    def transform_state_dict_for_saving(self, state_dict: Dict[str, Any]) -> Dict[str, Any]:
        """Transform state dict keys from current wrapped names to original names"""
        return self._name_mapping_registry.transform_state_dict(state_dict, original_to_current=False)

    def forward(self, *args, **kwargs):
        """
        Forward pass through the base model.
        This method can be overridden in subclasses to add custom behavior.
        """
        return self.base_model(*args, **kwargs)
    
    # def explain(self, *args, **kwargs):
    #     """
    #     Delegates explain method to the base model, but ensures the wrapper's forward pass is used.
    #     This allows the wrapper to be used seamlessly with explainable AI methods.
    #     """
    #     # Temporarily replace the base model's forward and __call__ methods with the wrapper's methods
    #     # to ensure the adapter layers are used during explanation
    #     # original_forward = self.base_model.forward
    #     # original_call = self.base_model.__call__
    #     # try:
    #     #     self.base_model.forward = self.forward  # type: ignore
    #     #     # Create a lambda that calls the wrapper's __call__ method
    #     #     self.base_model.__call__ = lambda *args, **kwargs: self.__call__(*args, **kwargs)  # type: ignore
    #     #     result = self.base_model.explain(*args, **kwargs)
    #     # finally:
    #     #     # Restore the original methods
    #     #     self.base_model.forward = original_forward
    #     #     self.base_model.__call__ = original_call
        
    #     return self.base_model.explain(*args, **kwargs)
    
    # def explanation_mode(self, *args, **kwargs):
    #     """
    #     Delegates explain_model method to the base model.
    #     This is useful for compatibility with models that have a specific explain_mode method.
    #     """
    #     # Ensure the base model's explain_model method is called
    #     return self.base_model.explanation_mode(*args, **kwargs)

    # def add_inverse(self, *args, **kwargs):
    #     """Add inverse method to the base model"""

    #     return self.base_model.add_inverse(*args, **kwargs)


    def __getattr__(self, name: str) -> Any:
        # Delegate attribute access to the wrapped module
        try:
            return super().__getattr__(name)
        except AttributeError:
            return getattr(self.base_model, name)

    
    
    def __call__(self, *args, **kwargs):
        """
        Allows the wrapper to be called like a function.
        This is useful for compatibility with models that expect callable objects.
        """
        return self.base_model.forward(*args, **kwargs)
    
    def _apply_modifications_recursive(
        self, 
        target_modules: List[str],
        module_filter_fn: Callable[[str, nn.Module], bool],
        modification_fn: Callable[[nn.Module], nn.Module]
    ) -> Dict[str, str]:
        """
        Generic recursive function to apply modifications to modules
        
        Args:
            target_modules: List of module name patterns to target
            module_filter_fn: Function to determine if a module should be modified
            modification_fn: Function that takes a module and returns the modified version
            
        Returns:
            Dictionary mapping original parameter names to new parameter names
        """
        name_mapping = {}
        modified_modules = {}
        
        def _apply_recursive(module, prefix=""):
            for name, child in module.named_children():
                full_name = f"{prefix}.{name}" if prefix else name
                
                # Debug: Print what we're checking
                # print(f"Checking module: {full_name}, type: {type(child).__name__}")
                
                # Check if this module should be modified
                should_modify = module_filter_fn(full_name, child)
                #print(f"Should modify {full_name}? {should_modify}")
                
                if should_modify:
                    # Capture parameter names before modification
                    original_param_names = []
                    for param_name, param in child.named_parameters():
                        original_param_names.append(f"{full_name}.{param_name}")
                    
                    # Apply modification
                    modified_module = modification_fn(child)
                    if modified_module != child:  # Modification was applied
                        if self.log: 
                            self.log.info(f"Applying modification to {full_name}")
                        
                        # Replace the original module with the modified module
                        setattr(module, name, modified_module)
                        modified_modules[full_name] = modified_module
                        
                        # Capture parameter names after modification
                        new_param_names = []
                        for param_name, param in modified_module.named_parameters():
                            new_param_names.append(f"{full_name}.{param_name}")
                        
                        # Create mapping from original to new parameter names
                        module_mapping = self._create_parameter_mapping(
                            full_name, original_param_names, new_param_names
                        )
                        name_mapping.update(module_mapping)
                
                # Recursively apply to children
                _apply_recursive(child, full_name)
        
        _apply_recursive(self.base_model)
        return name_mapping
    
    def _create_parameter_mapping(
        self, 
        module_name: str, 
        original_param_names: List[str], 
        new_param_names: List[str]
    ) -> Dict[str, str]:
        """
        Create parameter name mapping for a modified module.
        This method can be overridden by subclasses for specific mapping logic.
        
        Args:
            module_name: Name of the module that was modified
            original_param_names: List of original parameter names
            new_param_names: List of new parameter names after modification
            
        Returns:
            Dictionary mapping original parameter names to new parameter names
        """
        mapping = {}
        
        for original_name in original_param_names:
            # Extract the parameter suffix (e.g., "weight", "bias")
            param_suffix = original_name.split(".")[-1]
            
            # Try common patterns for finding the new location
            possible_new_names = [
                # Direct mapping (no structure change)
                original_name,
                # Common wrapper patterns
                f"{module_name}.base_layer.{param_suffix}",
                f"{module_name}.base_layer.linear.{param_suffix}",
                f"{module_name}.original.{param_suffix}",
                f"{module_name}.wrapped.{param_suffix}",
            ]
            
            # Find the first matching new name
            for possible_name in possible_new_names:
                if possible_name in new_param_names:
                    mapping[original_name] = possible_name
                    if self.log:
                        self.log.info(f"Mapped: {original_name} -> {possible_name}")
                    break
            else:
                # If no direct mapping found, log warning
                if self.log:
                    self.log.warning(f"Could not find mapping for {original_name}")
                    self.log.debug(f"Available new names: {new_param_names}")
        
        return mapping

