# import torch
# import torch.nn as nn
# from torch import Tensor
# from bcos.modules.bcosconv2d import BcosConv2d
# from typing import Union
# import torch.linalg as LA
# from bcos.modules.bcoslinear import BcosLinear
# from bcos.modules.common import DetachableModule
# from bcos.modules.common import BcosSequential


# class BcosifyConv2d(BcosConv2d):
#     def __init__(self,
#                  *args, 
#                  clamping: bool = False,
#                  b_loss: bool = False, 
#                  **kwargs):
#         super(BcosifyConv2d, self).__init__(*args, **kwargs)
                
#         self.clamping = clamping
#         self.b_loss = b_loss

#         linear = nn.Conv2d 
#         self.linear = linear(
#             in_channels=self.in_channels,
#                 out_channels=self.out_channels * self.max_out,
#                 kernel_size=self.kernel_size,
#                 stride=self.stride,
#                 padding=self.padding,
#                 dilation=self.dilation,
#                 groups=self.groups,
#                 bias=self.bias,
#                 padding_mode=self.padding_mode,
#                 device=self.device,
#                 dtype=self.dtype,
#         )
    
#     # Following property is added as the clip converts the input's dtype to conv1's weight's dtype at line 146 here:
#     # https://github.com/openai/CLIP/blob/main/clip/model.py#L146
#     @property
#     def weight(self) -> Tensor:
#         return self.linear.weight

#     def forward(self, in_tensor: Tensor) -> Tensor:
#         """
#         Forward pass implementation.
#         Args:
#             in_tensor: Input tensor. Expected shape: (B, C, H, W)

#         Returns:
#             BcosConv2d output on the input tensor.
#         """
#         return self.forward_impl(in_tensor)

#     def forward_impl(self, in_tensor: Tensor) -> Tensor:
#         """
#         Forward pass.
#         Args:
#             in_tensor: Input tensor. Expected shape: (B, C, H, W)

#         Returns:
#             BcosConv2d output on the input tensor.
#         """
#         # For clamping
#         if self.clamping:
#             b = self.b.clamp(1 + 1e-6)
        
#         # Using the b=-1 with weight decay (loss)
#         if self.b_loss:
#             b = self.b + 2

#         # Simple linear layer
#         out = self.linear(in_tensor)

#         # MaxOut computation
#         if self.max_out > 1:
#             M = self.max_out
#             O = self.out_channels  # noqa: E741
#             out = out.unflatten(dim=1, sizes=(O, M))
#             out = out.max(dim=2, keepdim=False).values

#         # if B=1, no further calculation necessary
#         if self.b == 1 and self.b_loss == False:
#             return out

#         # Calculating the norm of input patches: ||x||
#         norm = self.calc_patch_norms(in_tensor)

#         # Calculate the dynamic scale (|cos|^(B-1))
#         # Note that cos = (x·ŵ)/||x||
#         maybe_detached_out = out
#         if self.detach:
#             maybe_detached_out = out.detach()
#             norm = norm.detach()

#         if self.b == 2 and self.b_loss == False:
#             dynamic_scaling = maybe_detached_out.abs() / norm
#         else:
#             abs_cos = (maybe_detached_out / norm).abs() + 1e-6
#             if self.clamping or self.b_loss:
#                 dynamic_scaling = abs_cos.pow(b - 1)
#             else:
#                 dynamic_scaling = abs_cos.pow(self.b - 1)

#         # put everything together
#         out = dynamic_scaling * out  # |cos|^(B-1) (ŵ·x)
#         return out
    
#     def extra_repr(self) -> str:
#         # rest in self.linear
#         s = "B={b}"

#         if self.max_out > 1:
#             s += ", max_out={max_out}"

#         # final comma as self.linear is shown in next line
#         s += ","
#         additional_entries = dict(b=self.b.data.item()) if isinstance(self.b, nn.Parameter) else {}
#         return s.format(**self.__dict__, **additional_entries)
    
#     @classmethod
#     def from_standard_module(cls, mod, model_config):
#         """
#         Create a BcosConv2d from a standard Conv2d module.
#         Args:
#             mod: Standard Conv2d module.
#         Returns:
#             BcosConv2d module.
#         """
#         clamping = model_config['bcosify_args'].get("clamping", False)
#         b_loss = model_config['bcosify_args'].get("learn_b", False) 
#         b = model_config['bcos_args'].get("b", 1)

#         new_mod = cls(
#             in_channels=mod.in_channels,
#             out_channels=mod.out_channels,
#             kernel_size=mod.kernel_size,
#             stride=mod.stride,
#             padding=mod.padding,
#             dilation=mod.dilation,
#             groups=mod.groups,
#             bias=mod.bias is not None,
#             padding_mode=mod.padding_mode,
#             clamping=clamping,
#             b_loss=b_loss,
#             b = b,
#         )
#         weights = model_config.get("weights", None)
#         if weights is not None:
#             new_mod.linear.weight.data = mod.weight.data
#             if mod.bias is not None:
#                 new_mod.linear.bias = nn.Parameter(mod.bias.data)
#         return new_mod

#     # same method as from_standard_module specifcally for last layer where i replace a Linear layer with BcosConv2d
#     @classmethod
#     def from_standard_module_linear(cls, mod, model_config):
#         """
#         Create a BcosConv2d from a standard Linear module.
#         Args:
#             mod: Standard Linear module.
#         Returns:
#             BcosConv2d module.
#         """
#         clamping = model_config['bcosify_args'].get("clamping", False)
#         b_loss = model_config['bcosify_args'].get("learn_b", False)
#         b = model_config['bcos_args'].get("b", 1)
#         new_mod = cls(
#             in_channels=mod.in_features,
#             out_channels=mod.out_features,
#             kernel_size=1,
#             stride=1,
#             padding=0,
#             dilation=1,
#             groups=1,
#             bias=mod.bias is not None,
#             padding_mode="zeros",
#             clamping=clamping,
#             b_loss=b_loss,
#             b = b,
#         )
#         weights = model_config.get("weights", None)
#         if weights is not None:
#             new_mod.linear.weight.data = mod.weight.data.view_as(new_mod.linear.weight.data)
#             if mod.bias is not None:
#                 new_mod.linear.bias = nn.Parameter(mod.bias.data)
#         return new_mod
    




# """
# Contains a Linear layer which uses the B-cos transform.

# NOTE: In case you're wondering why the convolution models do not use
# `BcosLinear`, it's because maintaining two versions of essentially
# the same thing would be very error-prone during development and testing!
# """


# class BcosifyLinear(BcosLinear):
#     def __init__(self,
#                  *args, 
#                  clamping: bool = False,
#                  b_loss: bool = False, 
#                  **kwargs):
#         super(BcosifyLinear, self).__init__(*args, **kwargs)
                
#         self.clamping = clamping
#         self.b_loss = b_loss

#         self.linear = nn.Linear(
#             in_features=self.in_features,
#                 out_features=self.out_features * self.max_out,
#                 bias=self.bias,
#                 device=self.device,
#                 dtype=self.dtype,
#         )

#     # Following property is added as the clip converts the input's dtype to conv1's weight's dtype at line 146 here:
#     # https://github.com/openai/CLIP/blob/main/clip/model.py#L146
#     @property
#     def weight(self) -> Tensor:
#         return self.linear.weight
    
#     def forward(self, in_tensor: Tensor) -> Tensor:
#         """
#         Forward pass.
#         Args:
#             in_tensor: Input tensor. Expected shape: (*, H_in)

#         Returns:
#             B-cos Linear output on the input tensor.
#             Shape: (*, H_out)
#         """

#         if self.clamping:
#             b = self.b.clamp(1 + 1e-6)
        
#         # Using the b=-1 with weight decay (loss)
#         if self.b_loss:
#             b = self.b + 2

#         # Simple linear layer
#         out = self.linear(in_tensor)

#         # MaxOut computation
#         if self.max_out > 1:
#             M = self.max_out
#             O = self.out_features  # noqa: E741
#             out = out.unflatten(dim=-1, sizes=(O, M))
#             out = out.max(dim=-1, keepdim=False).values

#         # if B=1, no further calculation necessary
#         if self.b == 1 and self.b_loss == False:
#             return out

#         # Calculating the norm of input vectors ||x||
#         norm = LA.vector_norm(in_tensor, dim=-1, keepdim=True) + 1e-12

#         # Calculate the dynamic scale (|cos|^(B-1))
#         # Note that cos = (x·ŵ)/||x||
#         maybe_detached_out = out
#         if self.detach:
#             maybe_detached_out = out.detach()
#             norm = norm.detach()

#         if self.b == 2 and self.b_loss == False:
#             dynamic_scaling = maybe_detached_out.abs() / norm
#         else:
#             abs_cos = (maybe_detached_out / norm).abs() + 1e-6
#             if self.clamping or self.b_loss:
#                 dynamic_scaling = abs_cos.pow(b - 1)
#             else:
#                 dynamic_scaling = abs_cos.pow(self.b - 1)

#         # put everything together
#         out = dynamic_scaling * out  # |cos|^(B-1) (ŵ·x)
#         return out
    
#     def extra_repr(self) -> str:
#         # rest in self.linear
#         s = "B={b}"

#         if self.max_out > 1:
#             s += ", max_out={max_out}"

#         # final comma as self.linear is shown in next line
#         s += ","
#         additional_entries = dict(b=self.b.data.item()) if isinstance(self.b, nn.Parameter) else {}
#         return s.format(**self.__dict__, **additional_entries)
    
#     @classmethod
#     def from_standard_module(cls, mod, model_config):
#         """
#         Create a BcosLinear from a standard nn.Linear module.
#         """
#         clamping = model_config['bcosify_args'].get("clamping", False)
#         b_loss = model_config['bcosify_args'].get("learn_b", False)
#         b = model_config['bcos_args'].get("b", 1)
#         new_mod = cls(
#             mod.in_features,
#             mod.out_features,
#             bias=mod.bias is not None,
#             device=mod.weight.device,
#             dtype=mod.weight.dtype,
#             max_out=1,
#             clamping=clamping,
#             b_loss=b_loss,
#             b=b,
#         )
#         weights = model_config.get("weights", None)
#         if weights is not None:
#             new_mod.linear.weight.data = mod.weight.data
#             if mod.bias is not None:
#                 new_mod.linear.bias = nn.Parameter(mod.bias.data)
#         return new_mod

# class BcosAttentionPool2d(DetachableModule):
#     def __init__(self, spacial_dim: int, embed_dim: int, num_heads: int, output_dim: int = None, attn_unpool: bool = False):
#         super().__init__()
#         self.positional_embedding = nn.Parameter(torch.randn(spacial_dim ** 2 + 1, embed_dim) / embed_dim ** 0.5)
#         if not attn_unpool:
#             self.k_proj = nn.Linear(embed_dim, embed_dim)
#             self.q_proj = nn.Linear(embed_dim, embed_dim)
#         self.v_proj = nn.Linear(embed_dim, embed_dim)
#         self.c_proj = nn.Linear(embed_dim, output_dim or embed_dim)
#         self.num_heads = num_heads
#         self.attn_unpool = attn_unpool

#     def forward(self, x):
#         if self.attn_unpool:
#             x = x.flatten(start_dim=2).permute(2, 0, 1)  # NCHW -> (HW)NC, C=embed_dim
#             x = self.v_proj(x)
#             x = self.c_proj(x)
#             # Typically, output is N x D'
#             # New output is (HW) x N x D'
#             norm = x.norm(dim=-1, keepdim=True)
#             if self.detach:
#                 norm = norm.detach()
#             return x / norm
#         x = x.flatten(start_dim=2).permute(2, 0, 1)  # NCHW -> (HW)NC
#         x = torch.cat([x.mean(dim=0, keepdim=True), x], dim=0)  # (HW+1)NC
#         q = x[:1]
#         k = x
#         if self.detach:
#             q = q.detach()
#             k = k.detach()
#         x, _ = F.multi_head_attention_forward(
#             query=q, key=k, value=x,
#             embed_dim_to_check=x.shape[-1],
#             num_heads=self.num_heads,
#             q_proj_weight=self.q_proj.weight,
#             k_proj_weight=self.k_proj.weight,
#             v_proj_weight=self.v_proj.weight,
#             in_proj_weight=None,
#             in_proj_bias=None,
#             bias_k=None,
#             bias_v=None,
#             add_zero_attn=False,
#             dropout_p=0,
#             out_proj_weight=self.c_proj.weight,
#             out_proj_bias=None,
#             use_separate_proj_weight=True,
#             training=self.training,
#             need_weights=False
#         )
#         return x.squeeze(0)

#     @classmethod
#     def from_standard_module(cls, model, module, model_config):
#         spacial_dim = model.input_resolution // 32
#         embed_dim = model.conv1.out_channels * 64
#         num_heads = module.num_heads
#         output_dim = model.output_dim
#         attn_unpool = model_config.get("attn_unpool", False)
#         new_module = cls(spacial_dim, embed_dim, num_heads, output_dim, attn_unpool)
        
#         # Copying the parameter values
#         # ! For float32 setting, can directly copy the parameters
#         weights = model_config.get("weights", None)
#         if weights is not None:
#             for name, param in module.named_parameters():
#                 if attn_unpool and ('k_proj' not in name) and ('q_proj' not in name):
#                     exec(f'new_module.{name}.data = param.data')
#         return new_module
    

# class BcosifySequential(BcosSequential):
#     """
#     Wrapper for models which are nn.Sequential at the "root" module level.
#     This only adds helper functionality from `BcosMixIn`.
#     """

#     @classmethod
#     def from_standard_module(cls, mod):
#         """
#         Create a BcosSequential from a standard nn.Sequential module.
#         """
#         return cls(*mod._modules.values())