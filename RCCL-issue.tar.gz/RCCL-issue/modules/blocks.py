import math
from typing import Any, Callable, List, Optional, Type, Union
from bcos import BcosUtilMixin
from modules.adapters.conv_adapter import ConvAdapter, DynamicBias
#from models.utils import BcosifierMixin
import torch
from torch import nn
#from bcos.models.resnet import LogitLayer, BasicBlock, BcosConv2d
# from modules.bcos_conv import BcosConv2d
from bcos.modules import norms
from torchvision.ops import StochasticDepth

from modules.bcos_conv import BcosConv2d_unnormed
from modules.conv import conv1x1, conv3x3

from modules.legacy.defaults import DEFAULT_ACT_LAYER, DEFAULT_CONV_LAYER, DEFAULT_CONV_LAYER_ADAPTER, DEFAULT_NORM_LAYER

class Bottleneck(nn.Module):
    # Bottleneck in torchvision places the stride for downsampling at 3x3 convolution(self.conv2)
    # while original implementation places the stride at the first 1x1 convolution(self.conv1)
    # according to "Deep residual learning for image recognition"https://arxiv.org/abs/1512.03385.
    # This variant is also known as ResNet V1.5 and improves accuracy according to
    # https://ngc.nvidia.com/catalog/model-scripts/nvidia:resnet_50_v1_5_for_pytorch.

    expansion: int = 4

    def __init__(
        self,
        inplanes: int = 1,
        planes: int = 1,
        stride: int = 1,
        downsample: Optional[nn.Module] = None,
        groups: int = 1,
        base_width: int = 64,
        dilation: int = 1,
        norm_layer: Callable[..., nn.Module] = DEFAULT_NORM_LAYER,
        conv_layer: Callable[..., nn.Module] = DEFAULT_CONV_LAYER,
        act_layer: Optional[Callable[..., nn.Module]] = None,
        stochastic_depth_prob: float = 0.0,
        b = 2,
        remove_skip_connections = False,
        expansion = 4,
        dynamic_bias_b: int = 1,
        dynamic_bias: bool = False,
    ) -> None:
        super(Bottleneck, self).__init__()
        self.expansion = expansion
        width = int(planes * (base_width / 64.0)) * groups
        self.width = width
        self.remove_skip_connections = remove_skip_connections
        # Both self.conv2 and self.downsample layers downsample the input when stride != 1
        self.conv1 = conv1x1(
            inplanes,
            width,
            conv_layer=conv_layer,
            b=b,
        )
        self.bn1 = norm_layer(width)
        self.conv2 = conv3x3(
            width,
            width,
            stride,
            groups,
            dilation,
            conv_layer=conv_layer,
            b=b,
        )
        self.bn2 = norm_layer(width)
        self.conv3 = conv1x1(
            width,
            planes * self.expansion,
            conv_layer=conv_layer,
            b=b,
        )
        self.bn3 = norm_layer(planes * self.expansion)

        if act_layer == None:
            self.act = None
        else:
            self.act = act_layer(inplace=False)


        self.downsample = downsample
        self.stride = stride
        self.stochastic_depth = (
            StochasticDepth(stochastic_depth_prob, "row")
            if stochastic_depth_prob
            else None
        )

    def forward(self, x):
        identity = x

        out = self.conv1(x)
        out = self.bn1(out)
        if self.act != None: out = self.act(out)

        out = self.conv2(out)
        out = self.bn2(out)
        if self.act != None:  out = self.act(out)

        out = self.conv3(out)
        out = self.bn3(out)

        if self.stochastic_depth is not None:
            out = self.stochastic_depth(out)

        if not self.remove_skip_connections:
            if self.downsample is not None:
                identity = self.downsample(x)
            out = out + identity
        if self.act != None: out = self.act(out)

        return out

class BottleneckReLU(Bottleneck):
    def __init__(self, *args, **kwargs):
        if "act_layer" in kwargs: kwargs.pop('act_layer')
        super().__init__(*args, **kwargs, act_layer=DEFAULT_ACT_LAYER)

class AdapterBottleneck(Bottleneck):
    '''
    This is Resnet bottleneck with added conv-adapters.
    
    '''
    expansion: int = 4

    def __init__(
        self,
        inplanes: int = 1,
        planes: int = 1,
        stride: int = 1,
        conv_layer: Callable[..., nn.Module] = DEFAULT_CONV_LAYER,
        conv_adapter_style: str = "parallel",
        conv_adapter_pos: str = "residual",
        conv_adapter_kernel_size: int = 3,
        conv_adapter_act_layer: Callable[..., nn.Module] = DEFAULT_ACT_LAYER,
        conv_adapter_factor: int = 8,
        conv_adapter_b: int = 1,
        dynamic_bias: bool = False,
        dynamic_bias_b: int = 1,
        **kwargs,
    ) -> None:
        super().__init__(
            inplanes = inplanes,
            planes = planes,
            stride = stride,
            conv_layer = conv_layer,
            **kwargs,
        )

        self.adapter_style = conv_adapter_style
        self.adapter_pos = conv_adapter_pos


        self.conv_adapter_conv_parallel = None
        self.conv_adapter_res_parallel = None

        if self.adapter_style == "parallel" and (self.adapter_pos == "residual" or self.adapter_pos == "both"):
            self.conv_adapter_res_parallel = ConvAdapter(
                inplanes,
                planes * self.expansion,
                kernel_size = conv_adapter_kernel_size,
                padding = 1,
                width = inplanes // conv_adapter_factor,
                stride = stride,
                groups = inplanes // conv_adapter_factor,
                dilation = 1,
                act_layer = conv_adapter_act_layer,
                b = conv_adapter_b,
            )

        if self.adapter_style == "parallel" and (self.adapter_pos == "conv" or self.adapter_pos == "both"):
            self.conv_adapter_conv_parallel = ConvAdapter(
                self.width,
                self.width,
                kernel_size = conv_adapter_kernel_size,
                padding = 1,
                width = self.width // conv_adapter_factor,
                stride = stride,
                groups = self.width // conv_adapter_factor,
                dilation = 1,
                act_layer = conv_adapter_act_layer,
                b = conv_adapter_b,
            )
            

        if dynamic_bias:
            self.dynamic_bias1 = DynamicBias(
                self.width,
                b = dynamic_bias_b,
            )
            self.dynamic_bias2 = DynamicBias(
                self.width,
                b = dynamic_bias_b,
            )
            self.dynamic_bias3 = DynamicBias(
                planes * self.expansion,
                b = dynamic_bias_b,
            )
        else:
            self.dynamic_bias1 = None
            self.dynamic_bias2 = None
            self.dynamic_bias3 = None


    def forward(self, x):
        identity = x

        # Conv1
        out = self.conv1(x)
        if self.dynamic_bias1: out = self.dynamic_bias1(out)

        out = self.bn1(out)
        if self.act != None: out = self.act(out)
        
        # Conv2
        conv2_in = out
        out = self.conv2(out)

        if self.dynamic_bias2: out = self.dynamic_bias2(out)
        if self.conv_adapter_conv_parallel: out = out + self.conv_adapter_conv_parallel(conv2_in)


        out = self.bn2(out)
        if self.act != None:  out = self.act(out)

        # Conv3
        out = self.conv3(out)
        if self.dynamic_bias3: out = self.dynamic_bias3(out)

        out = self.bn3(out)

        if self.stochastic_depth is not None:
            out = self.stochastic_depth(out)


        if self.conv_adapter_res_parallel: out = out + self.conv_adapter_res_parallel(x)

        if not self.remove_skip_connections:
            if self.downsample is not None:
                identity = self.downsample(x)
            out = out + identity
            
        if self.act != None: out = self.act(out)

        return out

    
class Bottleneck_d1(nn.Module):
    # Bottleneck in torchvision places the stride for downsampling at 3x3 convolution(self.conv2)
    # while original implementation places the stride at the first 1x1 convolution(self.conv1)
    # according to "Deep residual learning for image recognition"https://arxiv.org/abs/1512.03385.
    # This variant is also known as ResNet V1.5 and improves accuracy according to
    # https://ngc.nvidia.com/catalog/model-scripts/nvidia:resnet_50_v1_5_for_pytorch.

    expansion: int = 1

    def __init__(
        self,
        inplanes: int,
        planes: int,
        stride: int = 1,
        downsample: Optional[nn.Module] = None,
        groups: int = 1,
        base_width: int = 64,
        dilation: int = 1,
        norm_layer: Callable[..., nn.Module] = DEFAULT_NORM_LAYER,
        conv_layer: Callable[..., nn.Module] = DEFAULT_CONV_LAYER,
        # act_layer: Callable[..., nn.Module] = DEFAULT_ACT_LAYER,
        b = 2,
        stochastic_depth_prob: float = 0.0,
    ) -> None:
        super(Bottleneck_d1, self).__init__()
        width = int(planes * (base_width / 64.0)) * groups
        # Both self.conv2 and self.downsample layers downsample the input when stride != 1
        self.conv1 = conv3x3(
            inplanes,
            inplanes,
            stride,
            groups,
            dilation,
            conv_layer=conv_layer,
            b=b,
        )
        self.bn1 = norm_layer(inplanes)
        # self.act = act_layer()
        self.downsample = downsample
        self.stride = stride
        self.stochastic_depth = (
            StochasticDepth(stochastic_depth_prob, "row")
            if stochastic_depth_prob
            else None
        )

    def forward(self, x):
        # identity = x

        out = self.conv1(x)
        out = self.bn1(out)

        if self.stochastic_depth is not None:
            out = self.stochastic_depth(out)

        # if self.downsample is not None:
        #     identity = self.downsample(x)

        # out += identity
        # out = self.act(out)

        return out


class ReverseBottleneck_d3(nn.Module):
    # Bottleneck in torchvision places the stride for downsampling at 3x3 convolution(self.conv2)
    # while original implementation places the stride at the first 1x1 convolution(self.conv1)
    # according to "Deep residual learning for image recognition"https://arxiv.org/abs/1512.03385.
    # This variant is also known as ResNet V1.5 and improves accuracy according to
    # https://ngc.nvidia.com/catalog/model-scripts/nvidia:resnet_50_v1_5_for_pytorch.

    expansion: int = 4

    def __init__(
        self,
        inplanes: int,
        planes: int,
        stride: int = 1,
        downsample: Optional[nn.Module] = None,
        groups: int = 1,
        base_width: int = 64,
        dilation: int = 1,
        norm_layer: Callable[..., nn.Module] = DEFAULT_NORM_LAYER,
        conv_layer: Callable[..., nn.Module] = DEFAULT_CONV_LAYER,
        # act_layer: Callable[..., nn.Module] = None,
        stochastic_depth_prob: float = 0.0,
        b = 2,
    ) -> None:
        super(ReverseBottleneck_d3, self).__init__()
        width = inplanes * 4 * groups
        # Both self.conv2 and self.downsample layers downsample the input when stride != 1
        self.conv1 = conv1x1(
            inplanes,
            width,
            conv_layer=conv_layer,
            b = b,
        )
        self.bn1 = norm_layer(width)
        self.conv2 = conv3x3(
            width,
            width,
            stride,
            groups,
            dilation,
            conv_layer=conv_layer,
            b = b,
        )
        self.bn2 = norm_layer(width)
        self.conv3 = conv1x1(
            width,
            planes * self.expansion,
            conv_layer=conv_layer,
            b = b,
        )
        self.bn3 = norm_layer(planes * self.expansion)
        # self.act = act_layer(inplace=True)
        self.downsample = downsample
        self.stride = stride
        self.stochastic_depth = (
            StochasticDepth(stochastic_depth_prob, "row")
            if stochastic_depth_prob
            else None
        )

    def forward(self, x):
        identity = x

        out = self.conv1(x)
        out = self.bn1(out)
        # out = self.act(out)

        out = self.conv2(out)
        out = self.bn2(out)
        # out = self.act(out)

        out = self.conv3(out)
        out = self.bn3(out)

        if self.stochastic_depth is not None:
            out = self.stochastic_depth(out)

        if self.downsample is not None:
            identity = self.downsample(x)

        out += identity
        # out = self.act(out)

        return out
