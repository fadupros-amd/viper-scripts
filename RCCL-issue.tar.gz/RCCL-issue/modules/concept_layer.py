from torch import nn
import torch
from modules.conv import conv1x1, conv3x3, DEFAULT_CONV_LAYER
from modules.bcos_conv import BcosConv2d_unnormed
from modules.legacy.defaults import DEFAULT_ACT_LAYER, DEFAULT_CONV_LAYER, DEFAULT_CONV_LAYER_ADAPTER, DEFAULT_NORM_LAYER
#from bcos.models.resnet import LogitLayer, BasicBlock, BcosConv2d
from modules.bcos_conv import BcosConv2d
from modules.legacy.defaults import DEFAULT_CONV_LAYER

class ConceptLayer(nn.Module):
    """
    Simple design for a concept bottleneck. Can be used to project a low dimensional embedding in a high-dimensional one with high B to enforce seperable concepts. Internal embedding is planes*factor.
    """
    def __init__(self, planes, factor, b:int = 1, **kwargs):
        super().__init__()

        self.conv1 = DEFAULT_CONV_LAYER(planes, planes*factor, b=b)

        self.conv2 = DEFAULT_CONV_LAYER(planes*factor, planes, b=b)

    
    def forward(self, x):
        out = self.conv1(x)
        out = self.conv2(out)
        return out
