from torch import nn
#from bcos.models.resnet import LogitLayer, BasicBlock, BcosConv2d
from typing import Any, Callable, List, Optional, Type, Union
from modules.legacy.defaults import DEFAULT_CONV_LAYER


def conv3x3(
    in_planes: int,
    out_planes: int,
    stride: int = 1,
    groups: int = 1,
    dilation: int = 1,
    conv_layer: Callable[..., nn.Module] = DEFAULT_CONV_LAYER,
    b: Union[int, float] = 1,
):
    """3x3 convolution with padding"""
    return conv_layer(
        in_planes,
        out_planes,
        kernel_size=3,
        stride=stride,
        padding=dilation,
        groups=groups,
        bias=False,
        dilation=dilation,
        b=b,
    )


def conv1x1(
    in_planes: int,
    out_planes: int,
    stride: int = 1,
    conv_layer: Callable[..., nn.Module] = DEFAULT_CONV_LAYER,
    b: Union[int, float] = 1,
    groups: int = 1,
):
    """1x1 convolution"""
    return conv_layer(
        in_planes,
        out_planes,
        kernel_size=1,
        stride=stride,
        bias=False,
        b=b,
        groups=groups,
    )


