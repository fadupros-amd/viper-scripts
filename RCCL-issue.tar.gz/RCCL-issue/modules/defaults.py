import torch
from torch import nn
#from bcos.models.resnet import LogitLayer, BasicBlock, BcosConv2d
from modules.bcos_conv import BcosConv2d
from bcos.modules import norms
from modules.bcos_conv import BcosConv2d_unnormed
from modules.bcos_linear import BcosLinear

DEFAULT_NORM_LAYER = norms.NoBias(norms.BatchNormUncentered2d)
# DEFAULT_NORM_LAYER = (norms.DetachableLayerNorm)
#DEFAULT_NORM_LAYER = torch.nn.Identity

DEFAULT_ACT_LAYER = nn.ReLU

DEFAULT_CONV_LAYER = BcosConv2d_unnormed
#DEFAULT_CONV_LAYER = BcosConv2d_unnormed
DEFAULT_CONV_LAYER_ADAPTER = BcosConv2d_unnormed
DEFAULT_LINEAR_LAYER = BcosLinear