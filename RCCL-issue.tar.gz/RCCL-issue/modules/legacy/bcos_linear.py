"""
Contains a Linear layer which uses the B-cos transform.

NOTE: In case you'        skip_norm_division: bool = False,e wondering why the convolution models do not use
`BcosLinear`, it's because maintaining two versions of essentially
the same thing would be very error-prone during development and testing!
"""
from typing import Union
import warnings

import torch
import torch.linalg as LA
import torch.nn as nn
import torch.nn.functional as F
from torch import Tensor
from torch.utils.checkpoint import checkpoint

from bcos.modules import DetachableModule

__all__ = ["NormedLinear", "BcosLinear"]


class NormedLinear(nn.Linear):
    """
    Standard linear transform, but with unit norm weights.
    """

    def forward(self, input: Tensor) -> Tensor:
        w = self.weight / LA.vector_norm(self.weight, dim=1, keepdim=True)
        return F.linear(input, w, self.bias)

class UnnormedLinear(nn.Linear):
    """
    Standard linear transform, but with unit norm weights.
    """

    def forward(self, input: Tensor) -> Tensor:
        w = self.weight #/ LA.vector_norm(self.weight, dim=1, keepdim=True)
        return F.linear(input, w, self.bias)

class BcosLinear(DetachableModule):
    """
    BcosLinear is a linear transform with unit norm weights and a cosine similarity
    activation function. The cosine similarity is calculated between the input
    vector and the weight vector. The output is then scaled by the cosine
    similarity.

    See the paper for more details: https://arxiv.org/abs/2205.10268

    Parameters
    ----------
    in_features : int
        Number of input features
    out_features : int
        Number of output features
    bias : bool
        This is ignored. BcosLinear does not support bias.
    device : Optional[torch.device]
        The device of the weights.
    dtype : Optional[torch.dtype]
        The dtype of the weights.
    b : int | float
        The base of the exponential used to scale the cosine similarity.
    max_out : int
        The number of output vectors to use. If this is greater than 1, the
        output is calculated as the maximum of `max_out` vectors. This is
        equivalent to using a MaxOut activation function.
    """

    def __init__(
        self,
        in_features: int,
        out_features: int,
        bias: bool = False,
        device=None,
        dtype=None,
        b: Union[int, float] = 2,
        max_out: int = 1,
        approach: str = "standard",
        use_gradient_checkpointing: bool = False,
        skip_norm_division: bool = False,
        power_trick: bool = False,
        weight_normalization: bool = False,
        use_cosine_similarity: bool = False,
    ) -> None:
        """
        BcosLinear layer with B-cos transform.
        """
        assert not bias
        super().__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.bias = False
        self.device = device
        self.dtype = dtype

        self.b = b
        self.max_out = max_out
        self.approach = approach  # Keep this for compatibility but don't use it
        self.use_gradient_checkpointing = use_gradient_checkpointing
        self.skip_norm_division = skip_norm_division
        self.power_trick = power_trick
        self.weight_normalization = weight_normalization
        self.use_cosine_similarity = use_cosine_similarity

        self.linear = NormedLinear(
            in_features,
            out_features * self.max_out,
            bias=False,
            device=device,
            dtype=dtype,
        )

    def _bcos_computation(self, in_tensor: Tensor, out: Tensor) -> Tensor:
        """Separate function for B-cos computation that can be checkpointed"""
        # if B=1, no further calculation necessary
        if self.b == 1:
            return out

        if self.use_cosine_similarity:
            # Ultra-efficient B-cos using torch.nn.functional.cosine_similarity
            # This leverages PyTorch's optimized cosine similarity implementation
            # Note: This requires a different computational approach
            
            # Get normalized weights (already normalized by NormedLinear)
            #w = self.linear.weight / LA.vector_norm(self.linear.weight, dim=1, keepdim=True)
            w = self.linear.weight
            # Reshape for broadcasting: x: (batch, seq, in_features), w: (out_features, in_features)
            # We need to compute cosine similarity between each input vector and each weight vector
            x_expanded = in_tensor.unsqueeze(-2)  # (batch, seq, 1, in_features)
            w_expanded = w.unsqueeze(0).unsqueeze(0)  # (1, 1, out_features, in_features)
            
            # Compute cosine similarity: (batch, seq, out_features)
            cos_sim = F.cosine_similarity(x_expanded, w_expanded, dim=-1)
            
            # Apply B-cos transform: |cos|^(B-1) * cos
            if self.b == 2:
                result = cos_sim.abs() * out  # |cos| * cos for B=2
            else:
                result = cos_sim.abs().pow(self.b - 1) * out
            
            return result

        if self.power_trick:
            # Ultra-simplified B-cos: sign(w·x) * |w·x|^B
            # Mathematical insight: under ||x|| ≈ 1, B-cos ≡ |cos|^(B-1) * cos = sign(w·x) * |w·x|^B
            # NOTE: This is mathematically equivalent to skip_norm_division but ~11% slower
            # due to extra sign() operation. Use skip_norm_division for performance.
            
            warnings.warn(f"Using power_trick=True is equivalent to skip_norm_division=True but slower. Use skip_norm_division for performance.")
            if self.weight_normalization: raise NotImplementedError("BcosLinear with power_trick=True does not support weight normalization.")

            if self.b == 1:
                return out  # x^1 = x, no need to compute power
            else:
                return torch.sign(out) * torch.abs(out).pow(self.b)

        # Calculate the dynamic scale (|cos|^(B-1))
        maybe_detached_out = out
        if self.detach:
            maybe_detached_out = out.detach()
        
        if self.weight_normalization:
            w_norm = LA.vector_norm(self.linear.weight, dim=1, keepdim=False)
            maybe_detached_out = maybe_detached_out / w_norm

        if self.skip_norm_division:
            # Simplified B-cos: assume inputs are normalized (e.g., after LayerNorm)
            # Just use |w·x|^(B-1) without explicit norm division

            if self.b == 2:
                dynamic_scaling = maybe_detached_out.abs()
            else:
                dynamic_scaling = maybe_detached_out.abs().pow(self.b - 1)
            
        else:
            # Standard B-cos with norm division
            # Calculating the norm of input vectors ||x|| without gradients
            # This saves memory since we don't need gradients w.r.t. the norm for B-cos scaling
            #with torch.no_grad():
            norm = LA.vector_norm(in_tensor, dim=-1, keepdim=True) + 1e-12
            if self.detach: 
                norm = norm.detach()
            # Note that cos = (x·ŵ)/||x||
            if self.b == 2:
                dynamic_scaling = maybe_detached_out.abs() / norm
            else:
                abs_cos = (maybe_detached_out / norm).abs() + 1e-6
                dynamic_scaling = abs_cos.pow(self.b - 1)

        # put everything together
        return dynamic_scaling * out  # |cos|^(B-1) (ŵ·x)

    def forward(self, in_tensor: Tensor) -> Tensor:
        """
        Forward pass with optional gradient checkpointing.
        Args:
            in_tensor: Input tensor. Expected shape: (*, H_in)

        Returns:
            B-cos Linear output on the input tensor.
            Shape: (*, H_out)
        """
        # Simple linear layer
        out = self.linear(in_tensor)

        # MaxOut computation
        if self.max_out > 1:
            M = self.max_out
            O = self.out_features  # noqa: E741
            out = out.unflatten(dim=-1, sizes=(O, M))
            out = out.max(dim=-1, keepdim=False).values

        # Apply B-cos computation with optional checkpointing
        if self.use_gradient_checkpointing and self.training:
            # Use gradient checkpointing to save memory
            out = checkpoint(self._bcos_computation, in_tensor, out, use_reentrant=False)
        else:
            # Regular computation
            out = self._bcos_computation(in_tensor, out)

        return out  # type: ignore

    def extra_repr(self) -> str:
        # rest in self.linear
        s = "B={b}"

        if self.max_out > 1:
            s += ", max_out={max_out}"
        # Add optimization flags
        if self.power_trick:
            s += ", mode=power_trick"
        if self.skip_norm_division:
            s += ", mode=norm_free"
        if self.use_gradient_checkpointing:
            s += ", mode=gradient_checkpoint"
        if self.use_cosine_similarity:
            s += ", mode=cosine_similarity"
        if self.weight_normalization:
            s += ", mode=weight_normalization"
        # final comma as self.linear is shown in next line
        s += ","
        return s.format(**self.__dict__)
    

class BcosUnnormedLinear(BcosLinear):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.linear = UnnormedLinear(
            self.in_features,
            self.out_features * self.max_out,
            bias=False,
            device=self.device,
            dtype=self.dtype,
        )