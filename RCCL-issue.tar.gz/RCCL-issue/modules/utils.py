import torch
import torch.nn as nn

def double_conv_input_channels(conv_weights: torch.Tensor) -> torch.Tensor:
    """
    Takes a convolutional weight tensor and doubles its input channels.

    The new channels are created by concatenating the inverse of the existing channels.
    This is useful for adapting a standard 3-channel (RGB) pretrained
    convolutional layer to a 6-channel Bcos-style input.

    Args:
        conv_weights (torch.Tensor): The weight tensor of a convolutional layer.
                                     Shape should be (out_channels, in_channels, kH, kW).

    Returns:
        torch.Tensor: A new weight tensor with doubled input channels.
                      Shape will be (out_channels, 2 * in_channels, kH, kW).
    """
    # Ensure the input is a tensor
    if not isinstance(conv_weights, torch.Tensor):
        raise TypeError(f"Input must be a torch.Tensor, but got {type(conv_weights)}")
    # Calculate the "inverted" weights for the new input channels
    inverted_weights = -(conv_weights.detach().clone())
    
    # Concatenate along the INPUT channel dimension (dim=1)
    adapted_weights = torch.cat([conv_weights, inverted_weights], dim=1) * torch.reciprocal(torch.tensor(2.0, dtype=conv_weights.dtype, device=conv_weights.device))

    return adapted_weights

def double_conv_input_channels_then_convert_to_linear(conv_weights: torch.Tensor) -> torch.Tensor:
    """
    Takes conv weights, doubles the input channels, then converts to linear format.
    
    Args:
        conv_weights: Shape (out_channels, in_channels, kH, kW)
    
    Returns:
        Linear weights with doubled input channels: Shape (out_channels, 2 * in_channels * kH * kW)
    """
    # First apply your existing channel doubling for conv weights
    doubled_conv_weights = double_conv_input_channels(conv_weights)
    
    # Then convert to linear format
    linear_weights = conv_to_linear_weights(doubled_conv_weights)
    
    return linear_weights


def conv_to_linear_weights(conv_weights: torch.Tensor) -> torch.Tensor:
    """
    Convert convolutional patch embedding weights to linear layer weights.
    
    Args:
        conv_weights: Shape (out_channels, in_channels, kernel_height, kernel_width)
    
    Returns:
        Linear weights: Shape (out_channels, in_channels * kernel_height * kernel_width)
    """
    out_channels, in_channels, kh, kw = conv_weights.shape
    
    # Reshape conv weights to linear format
    # The spatial dimensions get flattened in the same order as your rearrange operation
    linear_weights = conv_weights.view(out_channels, in_channels * kh * kw)
    
    return linear_weights
