import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd
from typing import Optional, Tuple
from matplotlib.figure import Figure
from matplotlib.axes import Axes
import plotly.express as px
import plotly.graph_objects as go

def create_plot_with_values(
    data: pd.DataFrame,
    x: str,
    y: str,
    hue: Optional[str] = None,
    plot_type: str = 'scatter',
    value_position: str = 'above',
    show_scale_lines: bool = False,
    show_point_labels: bool = True,
    show_scale_values: bool = True,
    max_scale_points: int = 5,
    point_size: int = 100,  # New: customizable scatter dot size
    avoid_label_overlap: bool = True,  # New: automatic overlap prevention
    figsize: tuple = (10, 6),
    title: Optional[str] = None,
    xlabel: Optional[str] = None,
    ylabel: Optional[str] = None,
    ylim: Optional[Tuple[float, float]] = None,
    rotation: int = 0,
    y_scale: str = 'linear',
    show_default_xticks: bool = True,
    **kwargs
) -> Tuple[Figure, Axes]:
    """
    Create scatter or bar plots with value labels and optional scale lines.
    
    New Parameters:
    ---------------
    point_size : int, default 100
        Size of scatter plot points (only affects scatter plots)
    avoid_label_overlap : bool, default True
        Whether to automatically position labels to avoid overlapping
    """
    
    # Create figure and axis
    fig, ax = plt.subplots(figsize=figsize)
    
    if y_scale == 'log':
        if (data[y] <= 0).any():
            print("Warning: y-axis contains non-positive values, which will be ignored on a log scale.")
        ax.set_yscale('log')

    # Create plot based on type with customizable point size
    if plot_type.lower() == 'scatter':
        sns.scatterplot(data=data, x=x, y=y, hue=hue, ax=ax, s=point_size, **kwargs)
    elif plot_type.lower() == 'bar':
        sns.barplot(data=data, x=x, y=y, hue=hue, ax=ax, **kwargs)
    else:
        raise ValueError("plot_type must be either 'scatter' or 'bar'")
    
    # Add value labels with smart positioning
    if show_point_labels:
        _add_smart_value_labels(ax, data, x, y, plot_type, value_position, 
                               avoid_label_overlap, y_scale, rotation)
    
    # Add scale lines with axis values if requested
    if show_scale_lines:
        _add_scale_lines_with_values(ax, data, x, y, plot_type, max_scale_points, show_scale_values)
    
    # Set labels and title
    ax.set_xlabel(xlabel if xlabel else x)
    ax.set_ylabel(ylabel if ylabel else y)
    if title:
        ax.set_title(title)
    
    # Set fixed scale if requested
    if ylim:
        ax.set_ylim(*ylim)

    # Rotate x-axis labels if needed and no scale lines
    if data[x].dtype == 'object' and not show_scale_lines:
        plt.xticks(rotation=45, ha='right')
    
    if not show_default_xticks:
        ax.set_xticklabels([])  # alternatively, but may cause issues with rotation
        ax.xaxis.set_tick_params(labelbottom=False, bottom=False)


    plt.tight_layout()
    plt.show()
    
    return fig, ax


def _add_smart_value_labels(ax, data, x, y, plot_type, value_position, avoid_overlap, y_scale, rotation):
    """Add value labels with intelligent positioning to avoid overlaps"""
    
    # Get axis ranges for smart positioning
    xlim = ax.get_xlim()
    ylim = ax.get_ylim()
    x_range = xlim[1] - xlim[0]
    y_range = ylim[1] - ylim[0]
    
    if plot_type.lower() == 'bar':
        # Simple labeling for bar plots (overlap less common)
        for i, bar in enumerate(ax.patches):
            height = bar.get_height()
            if height > 0:
                ax.text(bar.get_x() + bar.get_width()/2, height + 0.015 * y_range,
                       f'{height:.3f}', ha='center', va='bottom', 
                       fontsize=8, rotation=rotation,
                       bbox=dict(boxstyle='round,pad=0.3', facecolor='white', 
                               alpha=0.9, edgecolor='gray', linewidth=0.5))
        return
    
    # Smart positioning for scatter plots
    points_data = [(i, row[x], row[y]) for i, (idx, row) in enumerate(data.iterrows()) 
                   if xlim[0] <= row[x] <= xlim[1] and ylim[0] <= row[y] <= ylim[1]]
    
    if not avoid_overlap:
        # Use simple positioning based on value_position parameter
        for i, x_val, y_val in points_data:
            offset_x, offset_y, ha, va = _get_label_position(
                value_position, x_range, y_range, data[x].dtype == 'object')
            
            ax.text(x_val + offset_x, y_val + offset_y, f'{y_val:.3f}', 
                   ha=ha, va=va, fontsize=8, rotation=rotation,
                   bbox=dict(boxstyle='round,pad=0.3', facecolor='white', 
                           alpha=0.9, edgecolor='gray', linewidth=0.5))
    else:
        # Smart overlap avoidance
        _add_labels_with_overlap_avoidance(ax, points_data, x_range, y_range, rotation)


def _get_label_position(value_position, x_range, y_range, is_categorical_x):
    """Get label offset and alignment based on position preference"""
    
    if value_position == 'above':
        return 0, 0.04 * y_range, 'center', 'bottom'
    elif value_position == 'below':
        return 0, -0.04 * y_range, 'center', 'top'
    elif value_position == 'right':
        offset_x = 0.03 * x_range if not is_categorical_x else 0.3
        return offset_x, 0, 'left', 'center'
    elif value_position == 'left':
        offset_x = -0.03 * x_range if not is_categorical_x else -0.3
        return offset_x, 0, 'right', 'center'
    else:
        return 0, 0.04 * y_range, 'center', 'bottom'


def _add_labels_with_overlap_avoidance(ax, points_data, x_range, y_range, rotation):
    """Improved label positioning with better spacing"""
    
    # Sort points by y-value to handle overlaps systematically
    points_sorted = sorted(points_data, key=lambda p: p[2])
    
    # Use adaptive spacing based on data density
    min_distance = max(0.05 * x_range, 0.05 * y_range)  # Minimum distance between labels
    used_positions = []
    
    for i, x_val, y_val in points_sorted:
        # Try positions with much larger distances
        positions_to_try = [
            (0, 0.12 * y_range, 'center', 'bottom'),           # far above
            (0.1 * x_range, 0.08 * y_range, 'left', 'bottom'), # top-right
            (-0.1 * x_range, 0.08 * y_range, 'right', 'bottom'), # top-left
            (0.12 * x_range, 0, 'left', 'center'),             # far right
            (-0.12 * x_range, 0, 'right', 'center'),           # far left
            (0, -0.12 * y_range, 'center', 'top'),             # far below
        ]
        
        # Find position with no conflicts
        chosen_pos = positions_to_try[0]
        for offset_x, offset_y, ha, va in positions_to_try:
            label_x = x_val + offset_x
            label_y = y_val + offset_y
            
            # Check distance from all existing labels
            too_close = any(
                abs(label_x - used_x) < min_distance and abs(label_y - used_y) < min_distance
                for used_x, used_y in used_positions
            )
            
            if not too_close:
                chosen_pos = (offset_x, offset_y, ha, va)
                used_positions.append((label_x, label_y))
                break
        
        # Add label with better styling
        offset_x, offset_y, ha, va = chosen_pos
        ax.text(x_val + offset_x, y_val + offset_y, f'{y_val:.2f}',  # Reduced precision
               ha=ha, va=va, fontsize=7,  # Smaller font
               bbox=dict(boxstyle='round,pad=0.2', facecolor='white', 
                        alpha=0.9, edgecolor='lightgray', linewidth=0.3),
               zorder=10)  # Ensure labels appear on top



# Keep the existing _add_scale_lines_with_values function from previous version
def _add_scale_lines_with_values(ax, data, x, y, plot_type, max_points, show_values):
    """Add scale lines with coordinate values displayed on axes"""
    
    # Get plot limits
    xlim = ax.get_xlim()
    ylim = ax.get_ylim()
    
    # Select subset of points to avoid overcrowding
    if len(data) > max_points:
        indices = []
        
        # Add highest and lowest y values
        y_sorted = data.nlargest(2, y).index.tolist()
        y_sorted.extend(data.nsmallest(2, y).index.tolist())
        indices.extend(y_sorted)
        
        # Add one middle point if space allows
        if max_points > 4:
            median_idx = data.iloc[(len(data)//2)].name
            indices.append(median_idx)
        
        # Remove duplicates and limit
        indices = list(set(indices))[:max_points]
        selected_data = data.loc[indices]
    else:
        selected_data = data
    
    # Draw grid lines and add axis values
    for i, row in selected_data.iterrows():
        x_val = row[x]
        y_val = row[y]
        
        # Skip if outside plot bounds
        if not (xlim[0] <= x_val <= xlim[1] and ylim[0] <= y_val <= ylim[1]):
            continue
        
        if plot_type.lower() == 'scatter':
            # Draw subtle grid lines
            ax.axvline(x=x_val, color='lightgray', linestyle=':', alpha=0.6, zorder=0)
            #ax.axhline(y=y_val, color='lightgray', linestyle=':', alpha=0.6, zorder=0)
            
            if show_values:
                # Add y-value on the y-axis (left side)
                # ax.text(xlim[0] - 0.01 * (xlim[1] - xlim[0]), y_val, f'{y_val:.2f}',
                #        ha='right', va='center', fontsize=7, color='darkblue',
                #        bbox=dict(boxstyle='round,pad=0.2', facecolor='lightblue', 
                #                alpha=0.8, edgecolor='blue', linewidth=0.5))
                
                # Add x-value on the x-axis (bottom) - only for numeric x
                if data[x].dtype != 'object':
                    ax.text(
                        x_val,                      # x in data coords
                        0.02,                       # slightly above the axis line (in axes coords)
                        f'{x_val:.1f}',
                        ha='center',
                        va='bottom',
                        fontsize=8,
                        clip_on=False,
                        bbox=dict(boxstyle='round,pad=0.2', facecolor='lightblue', alpha=0.8, edgecolor='blue', linewidth=0.5),
                        transform=ax.get_xaxis_transform()  # x in data coords, y in axes coords
                    )


        
        else:  # bar plot
            # Only horizontal lines for bars
            ax.axhline(y=y_val, color='lightgray', linestyle=':', alpha=0.6, zorder=0)
            
            if show_values:
                # Add y-value on the y-axis
                ax.text(xlim[0] - 0.01 * (xlim[1] - xlim[0]), y_val, f'{y_val:.2f}',
                       ha='right', va='center', fontsize=7, color='darkblue',
                       bbox=dict(boxstyle='round,pad=0.2', facecolor='lightblue', 
                               alpha=0.8, edgecolor='blue', linewidth=0.5))


