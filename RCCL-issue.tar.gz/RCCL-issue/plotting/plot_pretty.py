import plotly.express as px
import plotly.graph_objects as go
import pandas as pd
from typing import Optional, Tuple, Union, Dict, List


def create_ultimate_plotly_plot(
    data: pd.DataFrame,
    x: str,
    y: str,
    plot_type: str = 'scatter',
    
    # Visual grouping parameters
    color: Optional[str] = None,
    size: Optional[str] = None,
    symbol: Optional[str] = None,
    
    # Plot appearance
    point_size: Union[int, float] = 8,
    opacity: float = 0.8,
    width: int = 900,
    height: int = 600,
    connect_dots: bool = False,  # NEW: Connect dots from same color group
    
    # Scale lines and annotations
    show_scale_lines: bool = False,
    max_scale_lines: int = 5,
    scale_line_color: str = 'lightgray',
    scale_line_style: str = 'dot',
    scale_line_direction: str = 'vertical',  # NEW: 'vertical', 'horizontal', or 'both'
    
    # Annotations
    add_annotations: bool = False,
    annotation_points: Optional[List[str]] = ["all"],  # 'extremes', 'outliers', 'all'
    annotation_position: str = 'top',  # 'top', 'bottom', 'right', 'left'
    annotation_size: int = 10,
    annotation_axis: str = 'y',  # 'x', 'y', or 'both'
    prevent_annotation_overlap: bool = True,  # NEW PARAMETER
    annotation_overlap_buffer: float = 5.0,   # NEW PARAMETER (pixels)
    
    # Styling
    title: Optional[str] = None,
    color_palette: Optional[Union[str, Dict]] = None,
    theme: str = 'plotly_white',  # plotly, plotly_white, plotly_dark, ggplot2, seaborn, simple_white
    
    # Layout customization
    show_legend: bool = True,
    grid: bool = True,
    hover_data: Optional[List[str]] = None,
    
    # Range control
    range_y: Optional[Tuple[float, float]] = None,
    range_x: Optional[Tuple[float, float]] = None,
    
    # Export options
    save_path: Optional[str] = None,
    save_format: str = 'html',  # html, png, jpeg, pdf, svg
    
    **kwargs
):
    """
    Ultimate Plotly Express plotting function with maximum flexibility
    
    Parameters:
    -----------
    data : pd.DataFrame
        The data to plot
    x, y : str
        Column names for x and y axes
    plot_type : str, default 'scatter'
        Type of plot: 'scatter', 'bar', 'line', 'box', 'violin', 'histogram'
    
    Visual Grouping:
    ----------------
    color : str, optional
        Column name for color grouping (equivalent to seaborn's hue)
    size : str, optional
        Column name for size variation
    symbol : str, optional
        Column name for symbol variation (scatter plots only)
    
    Appearance:
    -----------
    point_size : int/float, default 8
        Base size for points/markers
    opacity : float, default 0.8
        Transparency level (0-1)
    width, height : int
        Figure dimensions in pixels
    
    Scale Lines:
    ------------
    show_scale_lines : bool, default False
        Whether to show scale lines from points to axes
    max_scale_lines : int, default 5
        Maximum number of scale lines to prevent clutter
    scale_line_color : str, default 'lightgray'
        Color of scale lines
    scale_line_style : str, default 'dot'
        Line style: 'solid', 'dot', 'dash', 'dashdot'
    scale_line_direction : str, default 'vertical'
        Direction of scale lines: 'vertical' (to x-axis), 'horizontal' (to y-axis), or 'both'
    
    
    Annotations:
    ------------
    add_annotations : bool, default False
        Whether to add value annotations
    annotation_points : list, optional
        Which points to annotate: ['extremes', 'outliers', 'all']
    annotation_position : str, default 'top'
        Position relative to points: 'top', 'bottom', 'right', 'left'
    annotation_size : int, default 10
        Font size for annotations
    annotation_axis : str, default 'y'
        Which axis values to display in annotations: 'x', 'y', or 'both'
    prevent_annotation_overlap : bool, default True
        Whether to filter out overlapping annotation boxes
    annotation_overlap_buffer : float, default 5.0
        Minimum buffer space between annotation boxes in pixels

    
    Styling:
    --------
    title : str, optional
        Plot title
    color_palette : str or dict, optional
        Color scheme or custom color mapping
    theme : str, default 'plotly_white'
        Overall plot theme
    
    Layout:
    -------
    show_legend : bool, default True
        Whether to display legend
    grid : bool, default True
        Whether to show grid lines
    hover_data : list, optional
        Additional columns to show in hover tooltips
    
    Range Control:
    --------------
    range_y : tuple, optional
        Y-axis range as (min, max)
    range_x : tuple, optional
        X-axis range as (min, max)
    
    Export:
    -------
    save_path : str, optional
        Path to save the plot
    save_format : str, default 'html'
        Format for saving: 'html', 'png', 'jpeg', 'pdf', 'svg'
    """
    
    # Extract scaled font sizes from kwargs first, before any other processing
    title_font_size = kwargs.pop('_title_font_size', 16)
    general_font_size = kwargs.pop('_general_font_size', 12)
    axis_title_font_size = kwargs.pop('_axis_title_font_size', 14)
    axis_tick_font_size = kwargs.pop('_axis_tick_font_size', 12)
    legend_font_size = kwargs.pop('_legend_font_size', 12)
    
    # Prepare hover data
    if hover_data is None:
        hover_data = [x, y]
        if color and color not in hover_data:
            hover_data.append(color)
        if size and size not in hover_data:
            hover_data.append(size)
    
    # Create the base plot based on type
    plot_functions = {
        'scatter': px.scatter,
        'bar': px.bar,
        'line': px.line,
        'box': px.box,
        'violin': px.violin,
        'histogram': px.histogram
    }
    
    if plot_type not in plot_functions:
        raise ValueError(f"Unsupported plot_type: {plot_type}. Choose from {list(plot_functions.keys())}")
    
    plot_func = plot_functions[plot_type]
    
    # Build arguments for the plotting function
    plot_args = {
        'data_frame': data,
        'x': x,
        'y': y,
        'hover_data': hover_data,
        'title': title or f'{y} vs {x}' + (f' by {color}' if color else ''),
        'template': theme,
        **kwargs
    }
    
    # Add grouping parameters if specified
    if color:
        plot_args['color'] = color
    if size and plot_type == 'scatter':
        plot_args['size'] = size
    if symbol and plot_type == 'scatter':
        plot_args['symbol'] = symbol
    
    # Handle color palette
    if color_palette:
        if isinstance(color_palette, str):
            plot_args['color_discrete_sequence'] = getattr(px.colors.qualitative, color_palette, px.colors.qualitative.Plotly)
        elif isinstance(color_palette, dict):
            plot_args['color_discrete_map'] = color_palette
    
    # Create the plot
    fig = plot_func(**plot_args)
    
    # Update traces for better appearance
    if plot_type == 'scatter':
        marker_update = dict(
            opacity=opacity,
            line=dict(width=1, color='white')
        )
        # Only set fixed point_size if we're not using dynamic sizing
        if not size:
            marker_update['size'] = point_size
        fig.update_traces(marker=marker_update)
    elif plot_type == 'bar':
        fig.update_traces(opacity=opacity)
    
    # STEP 1: Set axis ranges FIRST, before any annotations
    if range_y:
        fig.update_yaxes(range=list(range_y), autorange=False)
        y_min, y_max = range_y
    else:
        # Calculate automatic range if not specified
        y_data_range = data[y].max() - data[y].min()
        y_padding = y_data_range * 0.1
        y_min = data[y].min() - y_padding
        y_max = data[y].max() + y_padding
        fig.update_yaxes(range=[y_min, y_max])

    if range_x:
        fig.update_xaxes(range=list(range_x), autorange=False)
        x_min, x_max = range_x
    else:
        x_data_range = data[x].max() - data[x].min()
        x_padding = x_data_range * 0.1
        x_min = data[x].min() - x_padding
        x_max = data[x].max() + x_padding
        fig.update_xaxes(range=[x_min, x_max])
        
    # Add connecting lines if requested
    if connect_dots and color and plot_type == 'scatter':
        _add_connecting_lines(fig, data, x, y, color)
        
    # Add scale lines if requested
    if show_scale_lines and plot_type in ['scatter', 'bar']:
        _add_scale_lines_to_plotly(fig, data, x, y, max_scale_lines, 
                                scale_line_color, scale_line_style, 
                                scale_line_direction, x_min, x_max, y_min, y_max, 
                                axis_tick_font_size)
        
    # Add annotations if requested
    # Add annotations if requested
    if add_annotations:
        _add_smart_annotations(fig, data, x, y, annotation_points, 
                            annotation_position, annotation_size, plot_type, 
                            annotation_axis, prevent_annotation_overlap, 
                            annotation_overlap_buffer, width, height, 
                            x_min, x_max, y_min, y_max)

    
    # Calculate scaled margins
    base_top_margin = 60
    scaled_top_margin = int(base_top_margin * (title_font_size / 16))  # Scale relative to base title size
    
    # Update layout with dynamic margins based on scale line direction
    bottom_margin = 120 if show_scale_lines and scale_line_direction in ['vertical', 'both'] else 60
    left_margin = 120 if show_scale_lines and scale_line_direction in ['horizontal', 'both'] else 60
    
    fig.update_layout(
        width=width,
        height=height,
        showlegend=show_legend,
        plot_bgcolor='white' if 'white' in theme else 'rgba(0,0,0,0)',
        margin=dict(t=scaled_top_margin, b=bottom_margin, l=left_margin, r=60),
        title=dict(
            x=0.5,  # Center the title horizontally
            xanchor='center',  # Anchor the title at its center
            font=dict(size=title_font_size)
        ),
        font=dict(size=general_font_size),
        legend=dict(font=dict(size=legend_font_size))
    )
    
    # Update axis fonts for better readability at high resolution
    fig.update_xaxes(
        title_font=dict(size=axis_title_font_size),
        tickfont=dict(size=axis_tick_font_size)
    )
    fig.update_yaxes(
        title_font=dict(size=axis_title_font_size),
        tickfont=dict(size=axis_tick_font_size)
    )
    
    # Configure grid
    if grid:
        fig.update_xaxes(showgrid=True, gridwidth=1, gridcolor='rgba(128,128,128,0.2)')
        fig.update_yaxes(showgrid=True, gridwidth=1, gridcolor='rgba(128,128,128,0.2)')
    else:
        fig.update_xaxes(showgrid=False)
        fig.update_yaxes(showgrid=False)
    
    # Save if requested
    if save_path:
        if save_format == 'html':
            fig.write_html(save_path)
        elif save_format in ['png', 'jpeg', 'pdf', 'svg']:
            fig.write_image(f"{save_path}.{save_format}")
    
    return fig


def _add_connecting_lines(fig, data, x, y, color):
    """Add lines connecting dots from the same color group, sorted by x-axis"""
    if color not in data.columns:
        return
    
    # Get unique color groups and their corresponding colors from the plot
    color_groups = data[color].unique()
    
    # Get the color sequence used by plotly
    colors = fig.data[0].marker.color if hasattr(fig.data[0], 'marker') and hasattr(fig.data[0].marker, 'color') else None
    
    # If colors are not directly accessible, use plotly's default color sequence
    import plotly.express as px
    default_colors = px.colors.qualitative.Plotly
    
    for i, group in enumerate(color_groups):
        # Filter data for this color group
        group_data = data[data[color] == group].copy()
        
        # Sort by x-axis for proper line connection
        group_data = group_data.sort_values(by=x)
        
        if len(group_data) > 1:  # Only add lines if there are multiple points
            # Use the corresponding color from the color sequence
            line_color = default_colors[i % len(default_colors)]
            
            # Add line trace
            fig.add_trace(
                go.Scatter(
                    x=group_data[x],
                    y=group_data[y],
                    mode='lines',
                    line=dict(color=line_color, width=2, dash='solid'),
                    showlegend=False,  # Don't show in legend to avoid duplication
                    hoverinfo='skip',  # Don't show hover info for lines
                    name=f'{group} (line)'
                )
            )


def _add_scale_lines_to_plotly(fig, data, x, y, max_lines, color, style, direction, 
                              final_x_min, final_x_max, final_y_min, final_y_max, font_size=9):
    """Add scale lines with annotations using the final axis range"""
    
    # Use the FINAL range values
    x_min, x_max = final_x_min, final_x_max
    y_min, y_max = final_y_min, final_y_max
    x_range = x_max - x_min
    y_range = y_max - y_min
    
    # Select and filter points
    if len(data) > max_lines:
        important_data = pd.concat([
            data.nlargest(2, y),
            data.nsmallest(2, y),
            data.sample(min(max_lines - 4, len(data) - 4)) if len(data) > 4 else pd.DataFrame()
        ]).drop_duplicates().head(max_lines)
    else:
        important_data = data
    
    # Add vertical scale lines (to x-axis) if requested
    if direction in ['vertical', 'both']:
        # Filter for x-spacing to prevent overlapping annotations
        important_data_x = important_data.sort_values(x)
        min_x_distance = x_range * 0.05  # 5% minimum distance
        
        filtered_x_points = []
        last_x = None
        for _, row in important_data_x.iterrows():
            if last_x is None or abs(row[x] - last_x) >= min_x_distance:
                filtered_x_points.append(row)
                last_x = row[x]
        
        filtered_x_data = pd.DataFrame(filtered_x_points)
        
        # Calculate annotation space needed for x-axis
        x_annotation_space = 0.12 * y_range
        
        # Add vertical lines and x-axis annotations
        for _, row in filtered_x_data.iterrows():
            x_val = row[x]
            y_val = row[y]
            
            # Add vertical line from extended bottom to data point
            fig.add_shape(
                type="line",
                x0=x_val, x1=x_val,
                y0=y_min - (0.05 * y_range), y1=y_val,
                line=dict(color=color, width=1, dash=style),
                layer="below"
            )
            
            # Position annotation below the x-axis
            annotation_y = y_min - (0.08 * y_range)
            
            fig.add_annotation(
                x=x_val,
                y=annotation_y,
                text=f'{x_val:.1f}',
                showarrow=False,
                bgcolor='lightblue',
                bordercolor='blue',
                borderwidth=1,
                font=dict(size=int(font_size * 0.75)),  # Scale annotation font relative to axis font
                xanchor="center",
                yanchor="middle"
            )
        
        # Extend the y-range to show the x-axis annotations
        if len(filtered_x_data) > 0:
            extended_y_min = y_min - x_annotation_space
            fig.update_yaxes(range=[extended_y_min, y_max])
    
    # Add horizontal scale lines (to y-axis) if requested
    if direction in ['horizontal', 'both']:
        # Filter for y-spacing to prevent overlapping annotations
        important_data_y = important_data.sort_values(y)
        min_y_distance = y_range * 0.05  # 5% minimum distance
        
        filtered_y_points = []
        last_y = None
        for _, row in important_data_y.iterrows():
            if last_y is None or abs(row[y] - last_y) >= min_y_distance:
                filtered_y_points.append(row)
                last_y = row[y]
        
        filtered_y_data = pd.DataFrame(filtered_y_points)
        
        # Calculate annotation space needed for y-axis
        y_annotation_space = 0.12 * x_range
        
        # Add horizontal lines and y-axis annotations
        for _, row in filtered_y_data.iterrows():
            x_val = row[x]
            y_val = row[y]
            
            # Add horizontal line from extended left to data point
            fig.add_shape(
                type="line",
                x0=x_min - (0.05 * x_range), x1=x_val,
                y0=y_val, y1=y_val,
                line=dict(color=color, width=1, dash=style),
                layer="below"
            )
            
            # Position annotation left of the y-axis
            annotation_x = x_min - (0.08 * x_range)
            
            fig.add_annotation(
                x=annotation_x,
                y=y_val,
                text=f'{y_val:.1f}',
                showarrow=False,
                bgcolor='lightcoral',
                bordercolor='red',
                borderwidth=1,
                font=dict(size=int(font_size * 0.75)),  # Scale annotation font relative to axis font
                xanchor="center",
                yanchor="middle"
            )
        
        # Extend the x-range to show the y-axis annotations
        if len(filtered_y_data) > 0:
            extended_x_min = x_min - y_annotation_space
            fig.update_xaxes(range=[extended_x_min, x_max])


def _add_smart_annotations(fig, data, x, y, points, position, size, plot_type, 
                          annotation_axis='y', prevent_overlap=True, 
                          overlap_buffer=5.0, plot_width=900, plot_height=600,
                          x_min=None, x_max=None, y_min=None, y_max=None):
    """Add intelligent annotations to points with overlap detection and proper arrow positioning"""
    
    # Determine which points to annotate
    if points is None or 'extremes' in points:
        annotate_data = pd.concat([
            data.nlargest(2, y),
            data.nsmallest(2, y)
        ]).drop_duplicates()
    elif 'outliers' in points:
        Q1, Q3 = data[y].quantile([0.25, 0.75])
        IQR = Q3 - Q1
        annotate_data = data[(data[y] < Q1 - 1.5*IQR) | (data[y] > Q3 + 1.5*IQR)]
    elif 'all' in points:
        annotate_data = data
    else:
        annotate_data = data.head(5)  # Default to first 5 points
    
    # Position offsets (base positions)
    offsets = {
        'top': (0, 15),
        'bottom': (0, -15),
        'right': (15, 0),
        'left': (-15, 0)
    }
    
    base_xshift, base_yshift = offsets.get(position, (0, 15))
    
    if prevent_overlap and len(annotate_data) > 1:
        # Get filtered annotations with their calculated positions
        annotation_info = _filter_overlapping_annotations_with_positions(
            annotate_data, x, y, annotation_axis, position, size, 
            overlap_buffer, plot_width, plot_height, 
            x_min, x_max, y_min, y_max, base_xshift, base_yshift
        )
    else:
        # No overlap detection - use base positions
        annotation_info = []
        for _, row in annotate_data.iterrows():
            if annotation_axis == 'x':
                text = f'{row[x]:.3f}'
            elif annotation_axis == 'y':
                text = f'{row[y]:.3f}'
            elif annotation_axis == 'both':
                text = f'({row[x]:.3f}, {row[y]:.3f})'
            else:
                text = f'{row[y]:.3f}'
                
            annotation_info.append({
                'row': row,
                'text': text,
                'xshift': base_xshift,
                'yshift': base_yshift
            })
    
    # Add annotations with proper arrow positioning
    for info in annotation_info:
        row = info['row']
        text = info['text']
        xshift = info['xshift']
        yshift = info['yshift']
        
        fig.add_annotation(
            x=row[x], y=row[y],
            text=text,
            showarrow=True,
            arrowhead=2,
            arrowcolor='gray',
            bgcolor='white',
            bordercolor='gray',
            borderwidth=1,
            font=dict(size=size),
            xshift=xshift,
            yshift=yshift
            # REMOVED: ax, ay, axref, ayref parameters
        )



def _filter_overlapping_annotations_with_positions(data, x, y, annotation_axis, position, size, 
                                                  buffer, plot_width, plot_height, 
                                                  x_min, x_max, y_min, y_max, 
                                                  base_xshift, base_yshift):
    """Filter out annotations that would overlap and return position info"""
    
    if len(data) <= 1:
        # Single annotation - use base position
        info_list = []
        for _, row in data.iterrows():
            if annotation_axis == 'x':
                text = f'{row[x]:.3f}'
            elif annotation_axis == 'y':
                text = f'{row[y]:.3f}'
            elif annotation_axis == 'both':
                text = f'({row[x]:.3f}, {row[y]:.3f})'
            else:
                text = f'{row[y]:.3f}'
                
            info_list.append({
                'row': row,
                'text': text,
                'xshift': base_xshift,
                'yshift': base_yshift
            })
        return info_list
    
    # Calculate plot margins (approximate)
    margin_left = 60
    margin_bottom = 60
    margin_top = 60
    margin_right = 60
    
    # Calculate plotting area dimensions
    plot_area_width = plot_width - margin_left - margin_right
    plot_area_height = plot_height - margin_top - margin_bottom
    
    # Prepare annotation data with bounding boxes
    annotation_candidates = []
    
    for idx, row in data.iterrows():
        # Generate text for this annotation
        if annotation_axis == 'x':
            text = f'{row[x]:.3f}'
        elif annotation_axis == 'y':
            text = f'{row[y]:.3f}'
        elif annotation_axis == 'both':
            text = f'({row[x]:.3f}, {row[y]:.3f})'
        else:
            text = f'{row[y]:.3f}'
        
        # Estimate text dimensions (rough approximation)
        char_width = size * 0.6  # Approximate character width in pixels
        char_height = size * 1.2  # Approximate character height in pixels
        text_width = len(text) * char_width
        text_height = char_height
        
        # Add padding for annotation box
        box_padding = 4
        box_width = text_width + (2 * box_padding)
        box_height = text_height + (2 * box_padding)
        
        # Convert data coordinates to pixel coordinates
        if x_min is not None and x_max is not None:
            pixel_x = margin_left + ((row[x] - x_min) / (x_max - x_min)) * plot_area_width
        else:
            pixel_x = margin_left + plot_area_width / 2  # Fallback
            
        if y_min is not None and y_max is not None:
            # Note: y-axis is inverted in pixel coordinates
            pixel_y = margin_bottom + ((y_max - row[y]) / (y_max - y_min)) * plot_area_height
        else:
            pixel_y = margin_bottom + plot_area_height / 2  # Fallback
        
        # Apply base annotation offset
        annotation_pixel_x = pixel_x + base_xshift
        annotation_pixel_y = pixel_y - base_yshift  # Subtract because pixel y increases downward
        
        # Calculate bounding box coordinates
        left = annotation_pixel_x - box_width / 2
        right = annotation_pixel_x + box_width / 2
        top = annotation_pixel_y - box_height / 2
        bottom = annotation_pixel_y + box_height / 2
        
        annotation_candidates.append({
            'index': idx,
            'row': row,
            'text': text,
            'left': left,
            'right': right,
            'top': top,
            'bottom': bottom,
            'priority': abs(row[y]),  # Priority based on y-value magnitude
            'base_xshift': base_xshift,
            'base_yshift': base_yshift,
            'pixel_x': pixel_x,
            'pixel_y': pixel_y,
            'box_width': box_width,
            'box_height': box_height
        })
    
    # Sort by priority (higher priority annotations are kept)
    annotation_candidates.sort(key=lambda a: a['priority'], reverse=True)
    
    # Filter out overlapping annotations and adjust positions if needed
    selected_annotations = []
    selected_bboxes = []  # Keep track of bounding boxes for overlap checking
    
    for candidate in annotation_candidates:
        # Check if this candidate overlaps with any already selected annotation
        overlaps = False
        
        for selected_bbox in selected_bboxes:
            if _boxes_overlap(candidate, selected_bbox, buffer):
                overlaps = True
                break
        
        if not overlaps:
            # No overlap - use base position
            selected_annotations.append({
                'row': candidate['row'],
                'text': candidate['text'],
                'xshift': candidate['base_xshift'],
                'yshift': candidate['base_yshift']
            })
            # Store the bounding box for future overlap checks
            selected_bboxes.append({
                'left': candidate['left'],
                'right': candidate['right'],
                'top': candidate['top'],
                'bottom': candidate['bottom']
            })
        else:
            # Try to find alternative position
            alternative_position = _find_alternative_position(
                candidate, selected_bboxes, buffer, position
            )
            
            if alternative_position:
                selected_annotations.append({
                    'row': candidate['row'],
                    'text': candidate['text'],
                    'xshift': alternative_position['xshift'],
                    'yshift': alternative_position['yshift']
                })
                # Store the alternative bounding box
                selected_bboxes.append(alternative_position['bbox'])
            # If no alternative position found, skip this annotation
    
    return selected_annotations


def _find_alternative_position(candidate, existing_bboxes, buffer, preferred_position):
    """Try to find an alternative position for an overlapping annotation"""
    
    # Alternative position offsets to try
    alternatives = {
        'top': [(0, 25), (0, 35), (15, 15), (-15, 15)],
        'bottom': [(0, -25), (0, -35), (15, -15), (-15, -15)],
        'right': [(25, 0), (35, 0), (15, 15), (15, -15)],
        'left': [(-25, 0), (-35, 0), (-15, 15), (-15, -15)]
    }
    
    # Get alternatives for the preferred position, or default alternatives
    position_alternatives = alternatives.get(preferred_position, [(0, 25), (25, 0), (0, -25), (-25, 0)])
    
    for alt_xshift, alt_yshift in position_alternatives:
        # Create a test candidate with alternative position
        annotation_pixel_x = candidate['pixel_x'] + alt_xshift
        annotation_pixel_y = candidate['pixel_y'] - alt_yshift
        
        # Calculate new bounding box for alternative position
        box_width = candidate['box_width']
        box_height = candidate['box_height']
        
        test_bbox = {
            'left': annotation_pixel_x - box_width / 2,
            'right': annotation_pixel_x + box_width / 2,
            'top': annotation_pixel_y - box_height / 2,
            'bottom': annotation_pixel_y + box_height / 2
        }
        
        # Check if this alternative position overlaps with existing annotations
        alternative_overlaps = False
        for existing_bbox in existing_bboxes:
            if _boxes_overlap(test_bbox, existing_bbox, buffer):
                alternative_overlaps = True
                break
        
        if not alternative_overlaps:
            return {
                'xshift': alt_xshift,
                'yshift': alt_yshift,
                'bbox': test_bbox
            }
    
    return None  # No alternative position found



def _boxes_overlap(box1, box2, buffer=0):
    """Check if two bounding boxes overlap with optional buffer"""
    
    # Add buffer to all sides
    box1_left = box1['left'] - buffer
    box1_right = box1['right'] + buffer
    box1_top = box1['top'] - buffer
    box1_bottom = box1['bottom'] + buffer
    
    box2_left = box2['left'] - buffer
    box2_right = box2['right'] + buffer
    box2_top = box2['top'] - buffer
    box2_bottom = box2['bottom'] + buffer
    
    # Check for overlap
    horizontal_overlap = not (box1_right < box2_left or box2_right < box1_left)
    vertical_overlap = not (box1_bottom < box2_top or box2_bottom < box1_top)
    
    return horizontal_overlap and vertical_overlap

def generate_scatter_plot(data, x, y, color, range_y=(0.6, 1), title=None, scale_factor=2.0, scale_dots_by_trainable_params=None, connect_dots=False, annotation_overlap_buffer=1):
    # Base dimensions and font sizes
    base_width = 900
    base_height = 600
    base_point_size = 40
    base_annotation_size = 10
    base_title_size = 16
    base_general_font = 12
    base_axis_title_font = 14
    base_axis_tick_font = 12
    base_legend_font = 12
    
    # Scale everything by the factor
    scaled_width = int(base_width * scale_factor)
    scaled_height = int(base_height * scale_factor)
    scaled_point_size = base_point_size * scale_factor
    scaled_annotation_size = int(base_annotation_size * scale_factor)
    scaled_title_size = int(base_title_size * scale_factor)
    scaled_general_font = int(base_general_font * scale_factor)
    scaled_axis_title_font = int(base_axis_title_font * scale_factor)
    scaled_axis_tick_font = int(base_axis_tick_font * scale_factor)
    scaled_legend_font = int(base_legend_font * scale_factor)
    
    # Determine size parameter for dots
    size_param = None
    if scale_dots_by_trainable_params:
        if isinstance(scale_dots_by_trainable_params, str):
            # User provided a specific column name
            if scale_dots_by_trainable_params in data.columns:
                size_param = scale_dots_by_trainable_params
            else:
                print(f"Warning: Column '{scale_dots_by_trainable_params}' not found in data")
        else:
            # Backward compatibility: auto-detect (if True was passed)
            trainable_param_columns = [col for col in data.columns if 'trainable' in col.lower() and 'param' in col.lower()]
            if trainable_param_columns:
                size_param = trainable_param_columns[0]  # Use the first matching column
            else:
                print("Warning: scale_dots_by_trainable_params=True but no trainable parameters column found")
    
    return create_ultimate_plotly_plot(
    data=data,
    x=x,
    y=y,
    color=color,  # Color points by name
    size=size_param,  # Scale dots by trainable parameters if requested
    point_size=scaled_point_size,
    connect_dots=connect_dots,  # Connect dots from same model
    show_scale_lines=True,
    max_scale_lines=20,
    range_y=range_y,
    add_annotations= True,
    annotation_points=['all'],    
    annotation_size=scaled_annotation_size,
    scale_line_direction="vertical",
    prevent_annotation_overlap=True,
    annotation_overlap_buffer=annotation_overlap_buffer,
    title=title,
    width=scaled_width,
    height=scaled_height,
    # Pass scaled font sizes as additional parameters
    _title_font_size=scaled_title_size,
    _general_font_size=scaled_general_font,
    _axis_title_font_size=scaled_axis_title_font,
    _axis_tick_font_size=scaled_axis_tick_font,
    _legend_font_size=scaled_legend_font
)

def generate_scatter_plot_accuracy(data, x, y, color, title=None, scale_factor=2.0, scale_dots_by_trainable_params=None, connect_dots=False, range_y=(0.6, 0.9), annotation_overlap_buffer=1):
    return generate_scatter_plot(
        data=data,
        x=x,
        y=y,
        color=color,
        range_y=range_y,
        title=title,
        scale_factor=scale_factor,
        scale_dots_by_trainable_params=scale_dots_by_trainable_params,
        connect_dots=connect_dots,
        annotation_overlap_buffer=annotation_overlap_buffer,
    )

def generate_scatter_plot_gridscore(data, x, y, color, title=None, scale_factor=2.0, scale_dots_by_trainable_params=None, connect_dots=False):
    return generate_scatter_plot(
        data=data,
        x=x,
        y=y,
        color=color,
        range_y=(0.5, 1.0),
        title=title,
        scale_factor=scale_factor,
        scale_dots_by_trainable_params=scale_dots_by_trainable_params,
        connect_dots=connect_dots
    )