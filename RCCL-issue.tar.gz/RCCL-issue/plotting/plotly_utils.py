"""
plotly_utils.py (FIXED VERSION)
Comprehensive Plotly-Express helper module
Updated: 2025-07-23 - Fixed sampling error in _add_scale_lines
"""

from typing import Optional, Tuple, Union, Dict, List
import pandas as pd
import plotly.express as px
from plotly.subplots import make_subplots
import plotly.graph_objects as go

# ──────────────────────────────────────────────────────────────────────────────
# Core API
# ──────────────────────────────────────────────────────────────────────────────
def create_ultimate_plotly_plot(
    data: pd.DataFrame,
    x: str,
    y: str,
    plot_type: str = "scatter",
    *,
    # grouping
    color: Optional[str] = None,
    size: Optional[str] = None,
    symbol: Optional[str] = None,
    # appearance
    point_size: Union[int, float] = 9,
    opacity: float = 0.85,
    width: int = 900,
    height: int = 600,
    # scale-lines
    show_scale_lines: bool = False,
    max_scale_lines: int = 6,
    scale_line_color: str = "lightgray",
    scale_line_style: str = "dot",
    # annotations
    add_annotations: bool = False,
    annotation_points: Optional[List[str]] = None,  # ['extremes','smart','all',...]
    annotation_position: str = "top",
    annotation_size: int = 9,
    # styling
    title: Optional[str] = None,
    color_palette: Optional[Union[str, Dict]] = None,
    theme: str = "plotly_white",
    # layout
    show_legend: bool = True,
    grid: bool = True,
    hover_data: Optional[List[str]] = None,
    # axis ranges
    range_y: Optional[Tuple[float, float]] = None,
    range_x: Optional[Tuple[float, float]] = None,
    # export
    save_path: Optional[str] = None,
    save_format: str = "html",
    **kwargs,
):
    # ------------------------------------------------------------------ data
    if hover_data is None:
        hover_data = [x, y] + ([color] if color else [])

    plot_funcs = {
        "scatter": px.scatter,
        "bar": px.bar,
        "line": px.line,
        "box": px.box,
        "violin": px.violin,
        "histogram": px.histogram,
    }
    if plot_type not in plot_funcs:
        raise ValueError(f"plot_type must be one of {list(plot_funcs)}")

    px_args = dict(
        data_frame=data,
        x=x,
        y=y,
        hover_data=hover_data,
        title=title or f"{y} vs {x}",
        template=theme,
        **kwargs,
    )
    if color:
        px_args["color"] = color
    if size and plot_type == "scatter":
        px_args["size"] = size
    if symbol and plot_type == "scatter":
        px_args["symbol"] = symbol
    if color_palette:
        if isinstance(color_palette, str):
            px_args["color_discrete_sequence"] = getattr(
                px.colors.qualitative, color_palette, px.colors.qualitative.Plotly
            )
        else:
            px_args["color_discrete_map"] = color_palette

    fig = plot_funcs[plot_type](**px_args)

    # basic trace cosmetics
    if plot_type == "scatter":
        fig.update_traces(
            marker=dict(size=point_size, opacity=opacity, line=dict(width=1, color="white"))
        )
    elif plot_type == "bar":
        fig.update_traces(opacity=opacity)

    # ------------------------------------------------------------------ axis ranges (set first!)
    y_min, y_max = _compute_range(data[y], range_y)
    x_min, x_max = _compute_range(data[x], range_x)

    fig.update_yaxes(range=[y_min, y_max], autorange=False)
    fig.update_xaxes(range=[x_min, x_max], autorange=False)

    # ------------------------------------------------------------------ extras
    if show_scale_lines and plot_type in {"scatter", "bar"}:
        _add_scale_lines(fig, data, x, y, max_scale_lines, scale_line_color, scale_line_style, y_min, y_max)

    if add_annotations:
        if annotation_points and "smart" in annotation_points:
            _add_smart_annotations(fig, data, x, y, "smart", annotation_position, annotation_size)
        elif annotation_points and "all" in annotation_points:
            _add_smart_annotations(fig, data, x, y, "all", annotation_position, annotation_size)
        else:
            _add_smart_annotations(fig, data, x, y, "extremes", annotation_position, annotation_size)

    # layout tweaks
    fig.update_layout(
        width=width,
        height=height,
        showlegend=show_legend,
        margin=dict(t=60, b=120 if show_scale_lines else 60, l=60, r=60),
        plot_bgcolor="white" if "white" in theme else "rgba(0,0,0,0)",
    )
    if grid:
        fig.update_xaxes(showgrid=True, gridcolor="rgba(128,128,128,0.2)")
        fig.update_yaxes(showgrid=True, gridcolor="rgba(128,128,128,0.2)")

    # optional save
    if save_path:
        if save_format == "html":
            fig.write_html(save_path)
        else:
            fig.write_image(f"{save_path}.{save_format}")

    return fig


# ──────────────────────────────────────────────────────────────────────────────
# Helpers (FIXED VERSION)
# ──────────────────────────────────────────────────────────────────────────────
def _compute_range(series: pd.Series, user_range):
    if user_range:
        return user_range
    pad = 0.1 * (series.max() - series.min() or 1)
    return series.min() - pad, series.max() + pad


def _add_scale_lines(
    fig,
    data,
    x,
    y,
    max_lines,
    color,
    style,
    final_y_min,
    final_y_max,
):
    """FIXED: Add scale lines with proper sampling logic"""
    y_range = final_y_max - final_y_min
    
    # Start with extremes (largest and smallest y-values)
    pts = pd.concat([data.nlargest(2, y), data.nsmallest(2, y)]).drop_duplicates()
    
    # Add more points if needed and available
    if len(pts) < max_lines:
        remaining_data = data.drop(pts.index)
        points_needed = max_lines - len(pts)
        
        # FIXED: Only sample what's actually available
        points_to_sample = min(points_needed, len(remaining_data))
        
        if points_to_sample > 0:
            extra = remaining_data.sample(points_to_sample)
            pts = pd.concat([pts, extra])
    
    # Sort by x for better visual spacing
    pts = pts.sort_values(x)
    
    # Filter for minimum distance to prevent overlapping annotations
    x_range = data[x].max() - data[x].min()
    min_distance = x_range * 0.05  # 5% of x-range minimum distance
    
    filtered_points = []
    last_x = None
    for _, row in pts.iterrows():
        if last_x is None or abs(row[x] - last_x) >= min_distance:
            filtered_points.append(row)
            last_x = row[x]
    
    pts = pd.DataFrame(filtered_points)

    # Calculate annotation position
    ann_y = final_y_min - 0.08 * y_range
    
    # Extend y-axis range to show annotations
    fig.update_yaxes(range=[final_y_min - 0.12 * y_range, final_y_max])

    # Add lines and annotations
    for _, r in pts.iterrows():
        # Vertical line from extended bottom to data point
        fig.add_shape(
            type="line",
            x0=r[x],
            x1=r[x],
            y0=final_y_min - 0.05 * y_range,
            y1=r[y],
            line=dict(color=color, width=1, dash=style),
            layer="below",
        )
        
        # Annotation at the bottom
        fig.add_annotation(
            x=r[x],
            y=ann_y,
            text=f"{r[x]:.1f}",
            showarrow=False,
            bgcolor="lightblue",
            bordercolor="blue",
            font=dict(size=8),
            yanchor="middle",
        )


def _select_smart_points(data, x, y, k=6, min_ratio=0.15):
    """Select points considering both extremes and spatial distribution"""
    base = pd.concat([data.nlargest(2, y), data.nsmallest(2, y)]).drop_duplicates()
    x_span = data[x].max() - data[x].min()
    min_dist = x_span * min_ratio
    selected = base.copy()
    
    for _, row in data.sort_values(x).iterrows():
        if len(selected) >= k:
            break
        if row.name not in selected.index:  # Don't re-add existing points
            if all(abs(row[x] - sx) >= min_dist for sx in selected[x]):
                selected = pd.concat([selected, row.to_frame().T])
    
    return selected.drop_duplicates()


def _add_smart_annotations(fig, data, x, y, mode, pos, size):
    """Add smart annotations with enhanced selection logic"""
    if mode == "all":
        pts = data
    elif mode == "smart":
        pts = _select_smart_points(data, x, y, k=8)
    else:  # extremes default
        pts = pd.concat([data.nlargest(2, y), data.nsmallest(2, y)]).drop_duplicates()

    offsets = {
        "top": (0, 15),
        "bottom": (0, -15),
        "right": (15, 0),
        "left": (-15, 0),
        "top-right": (10, 10),
        "top-left": (-10, 10),
    }
    cycle = ["top", "top-right", "right", "bottom", "bottom-left", "left", "top-left"]

    for i, (_, r) in enumerate(pts.iterrows()):
        p = cycle[i % len(cycle)] if len(pts) > 4 else pos
        dx, dy = offsets.get(p, (0, 15))
        fig.add_annotation(
            x=r[x],
            y=r[y],
            text=f"{r[y]:.2f}",
            showarrow=True,
            arrowhead=2,
            arrowcolor="gray",
            font=dict(size=size),
            bgcolor="rgba(255,255,255,0.8)",
            bordercolor="gray",
            borderwidth=0.5,
            xshift=dx,
            yshift=dy,
        )


# ──────────────────────────────────────────────────────────────────────────────
# Convenience wrappers
# ──────────────────────────────────────────────────────────────────────────────
def quick_scatter(data, x, y, **kwargs):
    return create_ultimate_plotly_plot(data, x, y, plot_type="scatter", **kwargs)


def quick_bar(data, x, y, **kwargs):
    return create_ultimate_plotly_plot(data, x, y, plot_type="bar", **kwargs)


def annotated_scatter(data, x, y, **kwargs):
    return create_ultimate_plotly_plot(
        data,
        x,
        y,
        plot_type="scatter",
        add_annotations=True,
        annotation_points=["smart"],
        **kwargs,
    )


def scale_line_scatter(data, x, y, **kwargs):
    return create_ultimate_plotly_plot(
        data,
        x,
        y,
        plot_type="scatter",
        show_scale_lines=True,
        max_scale_lines=6,
        **kwargs,
    )


def dual_plot_comparison(data, x, y1, y2, **kwargs):
    fig = make_subplots(
        rows=1, cols=2,
        subplot_titles=[f"{y1} vs {x}", f"{y2} vs {x}"],
        horizontal_spacing=0.08,
    )
    for tr in create_ultimate_plotly_plot(data, x, y1, show_legend=False, **kwargs).data:
        fig.add_trace(tr, row=1, col=1)
    for tr in create_ultimate_plotly_plot(data, x, y2, show_legend=False, **kwargs).data:
        fig.add_trace(tr, row=1, col=2)
    fig.update_layout(width=1100, height=500)
    return fig