import wandb
import pandas as pd
import json
import os
from pathlib import Path
from typing import List, Dict, Any, Optional
import logging
from datetime import datetime

# Setup logging
logger = logging.getLogger(__name__)
if not logger.handlers:
    # Only configure if no handlers exist to avoid duplication
    handler = logging.StreamHandler()
    formatter = logging.Formatter('%(levelname)s:%(name)s:%(message)s')
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    logger.setLevel(logging.INFO)

class WandBSyncer:
    def __init__(self, cache_dir: Optional[str] = None):
        """
        Initialize the W&B syncer with a cache directory.
        
        Args:
            cache_dir: Directory to store cached run data. If None, uses project's .cache/wandb_runs
        """
        if cache_dir is None:
            # Use project's cache directory with a subfolder for wandb run data
            project_root = Path(__file__).parent.parent
            self.cache_dir = project_root / ".cache" / "wandb_runs"
        else:
            self.cache_dir = Path(cache_dir)
        self.cache_dir.mkdir(exist_ok=True)
        self.individual_runs_dir = self.cache_dir / "individual_runs"
        self.individual_runs_dir.mkdir(exist_ok=True)
        self.combined_csv_path = self.cache_dir / "all_runs.csv"
        
    def _get_run_cache_path(self, run_id: str) -> Path:
        """Get the cache file path for a specific run."""
        return self.individual_runs_dir / f"{run_id}.json"
    
    def _is_run_cached(self, run_id: str) -> bool:
        """Check if a run is already cached locally."""
        return self._get_run_cache_path(run_id).exists()
    
    def sync_run(self, run_id: str, entity: Optional[str] = "raphaelmaser", project: Optional[str] = "Improved-Interpretability-and-Concepts", force_refresh: bool = False) -> Dict[str, Any]:
        """
        Sync a specific W&B run by ID.
        
        Args:
            run_id: The W&B run ID
            entity: W&B entity (username/team)
            project: W&B project name
            force_refresh: If True, re-download even if cached
            
        Returns:
            Dictionary containing run data
        """
        cache_path = self._get_run_cache_path(run_id)
        
        # Check if run is cached and force_refresh is False
        if not force_refresh and self._is_run_cached(run_id):
            logger.info(f"Loading cached data for run {run_id}")
            with open(cache_path, 'r') as f:
                return json.load(f)
        
        logger.info(f"Syncing run {run_id} from W&B...")
        
        try:
            # Initialize wandb API
            api = wandb.Api()
            
            # Construct run path
            if entity and project:
                run_path = f"{entity}/{project}/{run_id}"
            else:
                # Try to get run directly by ID
                run_path = run_id
            
            # Get the run
            run = api.run(run_path)
            
            # Helper function to safely convert datetime
            def safe_datetime_to_iso(dt):
                if dt is None:
                    return None
                if isinstance(dt, str):
                    return dt  # Already a string
                if hasattr(dt, 'isoformat'):
                    return dt.isoformat()
                return str(dt)  # Fallback to string conversion
            
            # Helper function to safely get attribute
            def safe_get_attr(obj, attr, default=None):
                return getattr(obj, attr, default)
            
            # Extract run data
            run_data = {
                'id': run.id,
                'name': run.name,
                'state': run.state,
                'entity': run.entity,
                'project': run.project,
                'created_at': safe_datetime_to_iso(safe_get_attr(run, 'created_at')),
                'updated_at': safe_datetime_to_iso(safe_get_attr(run, 'updated_at')),
                'config': dict(run.config),
                'summary': dict(run.summary),
                'tags': safe_get_attr(run, 'tags', []),
                'notes': safe_get_attr(run, 'notes', ''),
                'url': run.url,
                'group': safe_get_attr(run, 'group'),
                'job_type': safe_get_attr(run, 'job_type'),
                'sweep': run.sweep.id if safe_get_attr(run, 'sweep') else None,
                'synced_at': datetime.now().isoformat()
            }
            
            # Get history (metrics over time)
            try:
                history = run.history()
                if not history.empty:
                    # Convert to records for JSON serialization
                    run_data['history'] = history.to_dict('records')
                else:
                    run_data['history'] = []
            except Exception as e:
                logger.warning(f"Could not fetch history for run {run_id}: {e}")
                run_data['history'] = []
            
            # Save to cache
            with open(cache_path, 'w') as f:
                json.dump(run_data, f, indent=2, default=str)
            
            logger.info(f"Successfully synced and cached run {run_id}")
            return run_data
            
        except Exception as e:
            logger.error(f"Failed to sync run {run_id}: {e}")
            raise
    
    def sync_multiple_runs(self, run_ids: List[str], entity: Optional[str] = None, project: Optional[str] = None, force_refresh: bool = False) -> List[Dict[str, Any]]:
        """
        Sync multiple W&B runs.
        
        Args:
            run_ids: List of W&B run IDs
            entity: W&B entity (username/team)
            project: W&B project name
            force_refresh: If True, re-download even if cached
            
        Returns:
            List of dictionaries containing run data
        """
        runs_data = []
        
        for run_id in run_ids:
            try:
                run_data = self.sync_run(run_id, entity, project, force_refresh)
                runs_data.append(run_data)
            except Exception as e:
                logger.error(f"Failed to sync run {run_id}: {e}")
                continue

        # Delete the combined CSV to force recreation with fresh data
        # This prevents stale cache issues where new runs don't appear
        if self.combined_csv_path.exists():
            self.combined_csv_path.unlink()
            logger.info("Deleted combined CSV to force fresh recreation")
        
        return runs_data
    
    def sync_all_runs(self, entity: str, project: str, force_refresh: bool = False) -> List[Dict[str, Any]]:
        """
        Sync all runs from a W&B project.
        
        Args:
            entity: W&B entity (username/team)
            project: W&B project name
            force_refresh: If True, re-download even if cached
            
        Returns:
            List of dictionaries containing run data
        """
        logger.info(f"Fetching all runs from {entity}/{project}...")
        
        try:
            # Initialize wandb API
            api = wandb.Api()
            
            # Get all runs from the project
            runs = api.runs(f"{entity}/{project}")
            
            # Extract run IDs
            run_ids = [run.id for run in runs]
            logger.info(f"Found {len(run_ids)} runs in project")
            
            # Sync all runs
            result = self.sync_multiple_runs(run_ids, entity, project, force_refresh)
            
            # Delete the combined CSV to force recreation with fresh data
            # This prevents stale cache issues where new runs don't appear
            if self.combined_csv_path.exists():
                self.combined_csv_path.unlink()
                logger.info("Deleted combined CSV to force fresh recreation")
            
            return result
            
        except Exception as e:
            logger.error(f"Failed to fetch runs from {entity}/{project}: {e}")
            raise
    
    def load_cached_run(self, run_id: str) -> Optional[Dict[str, Any]]:
        """
        Load a cached run by ID.
        
        Args:
            run_id: The W&B run ID
            
        Returns:
            Dictionary containing run data or None if not cached
        """
        if not self._is_run_cached(run_id):
            return None
        
        cache_path = self._get_run_cache_path(run_id)
        with open(cache_path, 'r') as f:
            return json.load(f)
    
    def get_all_cached_runs(self) -> List[Dict[str, Any]]:
        """
        Get all cached runs.
        
        Returns:
            List of all cached run data
        """
        cached_runs = []
        
        for cache_file in self.individual_runs_dir.glob("*.json"):
            try:
                with open(cache_file, 'r') as f:
                    run_data = json.load(f)
                    cached_runs.append(run_data)
            except Exception as e:
                logger.error(f"Failed to load cached run from {cache_file}: {e}")
                continue
        
        return cached_runs
    
    def create_combined_csv(self, include_history: bool = False) -> str:
        """
        Create a combined CSV file with all cached runs.
        
        Args:
            include_history: If True, include metrics history in separate columns
            
        Returns:
            Path to the created CSV file
        """
        logger.info("Creating combined CSV from cached runs...")
        
        cached_runs = self.get_all_cached_runs()
        
        if not cached_runs:
            logger.warning("No cached runs found")
            return str(self.combined_csv_path)
        
        # Prepare data for normalization
        processed_runs = []
        
        for run in cached_runs:
            # Create a copy and preprocess some fields
            processed_run = run.copy()
            
            # Convert tags list to comma-separated string for better CSV representation
            if 'tags' in processed_run and isinstance(processed_run['tags'], list):
                processed_run['tags'] = ','.join(processed_run['tags'])
            
            # Optionally add final values from history
            if include_history and run.get('history'):
                history = run['history']
                if history:
                    # Get the last row of history and add as final_ metrics
                    last_metrics = history[-1]
                    for key, value in last_metrics.items():
                        if key not in ['_step', '_runtime', '_timestamp']:
                            processed_run[f'final_{key}'] = value
            
            # Remove history from the main data since it's too nested for CSV
            processed_run.pop('history', None)
            
            processed_runs.append(processed_run)
        
        # Use pandas json_normalize to flatten nested dictionaries
        df = pd.json_normalize(processed_runs, sep='_')
        
        # Save to CSV
        df.to_csv(self.combined_csv_path, index=False)
        
        logger.info(f"Combined CSV created with {len(df)} runs at: {self.combined_csv_path}")
        return str(self.combined_csv_path)
    
    def get_full_history_dataframe(self, run_ids: Optional[List[str]] = None) -> pd.DataFrame:
        """
        Get a DataFrame with complete training history (epoch-by-epoch metrics) for all or specific runs.
        
        Args:
            run_ids: If provided, only include specific runs. Otherwise include all cached runs.
            
        Returns:
            pandas DataFrame with columns: run_id, run_name, epoch/step, metric_name, metric_value, timestamp
        """
        logger.info("Creating complete history DataFrame...")
        
        cached_runs = self.get_all_cached_runs()
        
        if run_ids:
            cached_runs = [run for run in cached_runs if run['id'] in run_ids]
        
        if not cached_runs:
            logger.warning("No cached runs found")
            return pd.DataFrame()
        
        history_records = []
        
        for run in cached_runs:
            run_id = run['id']
            run_name = run.get('name', 'unnamed')
            run_config = run.get('config', {})
            history = run.get('history', [])
            
            if not history:
                continue
                
            for step_data in history:
                step = step_data.get('_step', None)
                timestamp = step_data.get('_timestamp', None)
                runtime = step_data.get('_runtime', None)
                
                # Add each metric as a separate row
                for key, value in step_data.items():
                    if key.startswith('_'):  # Skip internal wandb fields
                        continue
                        
                    history_records.append({
                        'run_id': run_id,
                        'run_name': run_name,
                        'step': step,
                        'timestamp': timestamp,
                        'runtime': runtime,
                        'metric_name': key,
                        'metric_value': value,
                        # Add some key config parameters for easy filtering
                        **{f'config_{k}': v for k, v in run_config.items() 
                           if isinstance(v, (str, int, float, bool))}
                    })
        
        if not history_records:
            logger.warning("No history data found in cached runs")
            return pd.DataFrame()
            
        df = pd.DataFrame(history_records)
        
        # Convert timestamp to datetime if possible
        if 'timestamp' in df.columns:
            try:
                df['timestamp'] = pd.to_datetime(df['timestamp'])
            except:
                pass  # Keep as is if conversion fails
                
        logger.info(f"Created history DataFrame with {len(df)} records from {len(cached_runs)} runs")
        return df
    
    def get_run_history(self, run_id: str) -> pd.DataFrame:
        """
        Get the complete training history for a specific run.
        
        Args:
            run_id: The W&B run ID
            
        Returns:
            pandas DataFrame with the run's history
        """
        run_data = self.load_cached_run(run_id)
        if not run_data:
            logger.warning(f"Run {run_id} not found in cache")
            return pd.DataFrame()
            
        history = run_data.get('history', [])
        if not history:
            logger.warning(f"No history found for run {run_id}")
            return pd.DataFrame()
            
        # Convert history to DataFrame
        df = pd.DataFrame(history)
        
        # Convert timestamp to datetime if possible
        if '_timestamp' in df.columns:
            try:
                df['_timestamp'] = pd.to_datetime(df['_timestamp'])
            except:
                pass
                
        return df
    
    def get_unfolded_history_dataframe(self, run_ids: Optional[List[str]] = None, 
                                      metrics: Optional[List[str]] = None) -> pd.DataFrame:
        """
        Get training history in "wide" format where each epoch becomes a column.
        Each metric gets columns like: metric_epoch_0, metric_epoch_1, etc.
        
        Args:
            run_ids: If provided, only include specific runs. Otherwise include all cached runs.
            metrics: If provided, only include specific metrics. Otherwise include all metrics.
            
        Returns:
            pandas DataFrame with run info and metrics unfolded across epochs as columns
        """
        logger.info("Creating unfolded history DataFrame (wide format)...")
        
        cached_runs = self.get_all_cached_runs()
        
        if run_ids:
            cached_runs = [run for run in cached_runs if run['id'] in run_ids]
        
        if not cached_runs:
            logger.warning("No cached runs found")
            return pd.DataFrame()
        
        unfolded_records = []
        
        for run in cached_runs:
            run_id = run['id']
            run_name = run.get('name', 'unnamed')
            run_config = run.get('config', {})
            run_summary = run.get('summary', {})
            history = run.get('history', [])
            
            # Start with basic run info
            run_record = {
                'run_id': run_id,
                'run_name': run_name,
                'state': run.get('state'),
                'created_at': run.get('created_at'),
                'entity': run.get('entity'),
                'project': run.get('project'),
                'group': run.get('group'),
                'tags': ','.join(run.get('tags', [])) if run.get('tags') else '',
                'notes': run.get('notes', ''),
                'url': run.get('url', ''),
            }
            
            # Add config parameters
            for key, value in run_config.items():
                if isinstance(value, (str, int, float, bool)):
                    run_record[f'config_{key}'] = value
            
            # Add summary metrics
            for key, value in run_summary.items():
                if isinstance(value, (str, int, float, bool)):
                    run_record[f'summary_{key}'] = value
            
            if not history:
                unfolded_records.append(run_record)
                continue
            
            # Convert history to DataFrame for easier manipulation
            history_df = pd.DataFrame(history)
            
            # Filter metrics if specified
            if metrics:
                metric_columns = [col for col in history_df.columns 
                                if col in metrics or not col.startswith('_')]
            else:
                metric_columns = [col for col in history_df.columns if not col.startswith('_')]
            
            # For each metric, create epoch columns
            for metric in metric_columns:
                if metric in history_df.columns:
                    metric_values = history_df[metric].tolist()
                    
                    # Create columns for each epoch: metric_epoch_0, metric_epoch_1, etc.
                    for epoch, value in enumerate(metric_values):
                        run_record[f'{metric}_epoch_{epoch}'] = value
                    
                    # Also add final value and max epoch for convenience
                    run_record[f'{metric}_final'] = metric_values[-1] if metric_values else None
                    run_record[f'{metric}_max_epoch'] = len(metric_values) - 1 if metric_values else None
            
            # Add step information if available
            if '_step' in history_df.columns:
                steps = history_df['_step'].tolist()
                for epoch, step in enumerate(steps):
                    run_record[f'step_epoch_{epoch}'] = step
                run_record['max_steps'] = len(steps)
            
            unfolded_records.append(run_record)
        
        if not unfolded_records:
            logger.warning("No data to unfold")
            return pd.DataFrame()
            
        df = pd.DataFrame(unfolded_records)
        
        logger.info(f"Created unfolded DataFrame with {len(df)} runs and {len(df.columns)} columns")
        return df
    
    def create_history_csv(self, run_id: Optional[str] = None) -> str:
        """
        Create a CSV file with detailed history for one or all runs.
        
        Args:
            run_id: If provided, create history CSV for specific run only
            
        Returns:
            Path to the created CSV file
        """
        if run_id:
            history_csv_path = self.cache_dir / f"{run_id}_history.csv"
            runs = [self.load_cached_run(run_id)]
            if runs[0] is None:
                raise ValueError(f"Run {run_id} not found in cache")
        else:
            history_csv_path = self.cache_dir / "all_runs_history.csv"
            runs = self.get_all_cached_runs()
        
        logger.info(f"Creating history CSV at: {history_csv_path}")
        
        # Collect all history data
        all_history = []
        
        for run in runs:
            if not run or not run.get('history'):
                continue
            
            for step_data in run['history']:
                step_row = {
                    'run_id': run['id'],
                    'run_name': run['name'],
                    'entity': run['entity'],
                    'project': run['project']
                }
                step_row.update(step_data)
                all_history.append(step_row)
        
        if all_history:
            df_history = pd.DataFrame(all_history)
            df_history.to_csv(history_csv_path, index=False)
            logger.info(f"History CSV created with {len(all_history)} data points")
        else:
            logger.warning("No history data found")
        
        return str(history_csv_path)
    
    def load_runs_dataframe(self, include_history: bool = False) -> pd.DataFrame:
        """
        Load all cached runs as a pandas DataFrame.
        
        Args:
            include_history: If True, include final metrics from history
            
        Returns:
            pandas DataFrame with run data
        """
        if not self.combined_csv_path.exists():
            self.create_combined_csv(include_history=include_history)
        
        return pd.read_csv(self.combined_csv_path)
    
    def cleanup_cache(self, run_ids: Optional[List[str]] = None):
        """
        Clean up cache files.
        
        Args:
            run_ids: If provided, only clean specific runs. Otherwise clean all.
        """
        if run_ids:
            for run_id in run_ids:
                cache_path = self._get_run_cache_path(run_id)
                if cache_path.exists():
                    cache_path.unlink()
                    logger.info(f"Removed cache for run {run_id}")
        else:
            # Clean all individual run caches
            for cache_file in self.individual_runs_dir.glob("*.json"):
                cache_file.unlink()
            
            # Remove combined CSV
            if self.combined_csv_path.exists():
                self.combined_csv_path.unlink()
            
            logger.info("Cleaned all cache files")

# Convenience functions
def sync_wandb_runs(run_ids: List[str], entity: Optional[str] = None, project: Optional[str] = None, 
                   cache_dir: Optional[str] = None, force_refresh: bool = False) -> pd.DataFrame:
    """
    Convenience function to sync W&B runs and return as DataFrame.
    
    Args:
        run_ids: List of W&B run IDs
        entity: W&B entity (username/team)
        project: W&B project name
        cache_dir: Directory to store cached data
        force_refresh: If True, re-download even if cached
        
    Returns:
        pandas DataFrame with run data
    """
    syncer = WandBSyncer(cache_dir)
    syncer.sync_multiple_runs(run_ids, entity, project, force_refresh)
    return syncer.load_runs_dataframe()

def load_wandb_runs(cache_dir: Optional[str] = None) -> pd.DataFrame:
    """
    Load cached W&B runs as DataFrame.
    
    Args:
        cache_dir: Directory containing cached data
        
    Returns:
        pandas DataFrame with run data
    """
    syncer = WandBSyncer(cache_dir)
    return syncer.load_runs_dataframe()

def sync_all_wandb_runs(entity: str, project: str, cache_dir: Optional[str] = None, 
                       force_refresh: bool = False, include_history: bool = True) -> pd.DataFrame:
    """
    Convenience function to sync all W&B runs from a project and return as DataFrame.
    
    Args:
        entity: W&B entity (username/team)
        project: W&B project name
        cache_dir: Directory to store cached data
        force_refresh: If True, re-download even if cached
        include_history: If True, include final metrics from history in CSV
        
    Returns:
        pandas DataFrame with all run data
    """
    syncer = WandBSyncer(cache_dir)
    syncer.sync_all_runs(entity, project, force_refresh)
    return syncer.load_runs_dataframe(include_history=include_history)

def get_full_training_history(entity: Optional[str] = None, project: Optional[str] = None, 
                             run_ids: Optional[List[str]] = None, 
                             cache_dir: Optional[str] = None,
                             force_refresh: bool = False) -> pd.DataFrame:
    """
    Get complete training history (epoch-by-epoch metrics) for all or specific runs.
    
    Args:
        entity: W&B entity (username/team) - only needed if force_refresh=True
        project: W&B project name - only needed if force_refresh=True  
        run_ids: If provided, only include specific runs. Otherwise include all cached runs.
        cache_dir: Directory containing cached data
        force_refresh: If True, sync runs first before getting history
        
    Returns:
        pandas DataFrame with complete training history
    """
    syncer = WandBSyncer(cache_dir)
    
    # Optionally sync first
    if force_refresh and entity and project:
        if run_ids:
            syncer.sync_multiple_runs(run_ids, entity, project, force_refresh)
        else:
            syncer.sync_all_runs(entity, project, force_refresh)
    
    return syncer.get_full_history_dataframe(run_ids)

def get_run_training_history(run_id: str, cache_dir: Optional[str] = None) -> pd.DataFrame:
    """
    Get complete training history for a specific run.
    
    Args:
        run_id: The W&B run ID
        cache_dir: Directory containing cached data
        
    Returns:
        pandas DataFrame with the run's training history
    """
    syncer = WandBSyncer(cache_dir)
    return syncer.get_run_history(run_id)

def get_unfolded_training_history(entity: Optional[str] = None, project: Optional[str] = None,
                                 run_ids: Optional[List[str]] = None,
                                 metrics: Optional[List[str]] = None,
                                 cache_dir: Optional[str] = None,
                                 force_refresh: bool = False) -> pd.DataFrame:
    """
    Get training history in "wide" format where each epoch becomes a column.
    Each metric gets columns like: metric_epoch_0, metric_epoch_1, etc.
    
    Args:
        entity: W&B entity (username/team) - only needed if force_refresh=True
        project: W&B project name - only needed if force_refresh=True
        run_ids: If provided, only include specific runs. Otherwise include all cached runs.
        metrics: If provided, only include specific metrics. Otherwise include all metrics.
        cache_dir: Directory containing cached data
        force_refresh: If True, sync runs first before getting history
        
    Returns:
        pandas DataFrame with metrics unfolded across epochs as columns
    """
    syncer = WandBSyncer(cache_dir)
    
    # Optionally sync first
    if force_refresh and entity and project:
        if run_ids:
            syncer.sync_multiple_runs(run_ids, entity, project, force_refresh)
        else:
            syncer.sync_all_runs(entity, project, force_refresh)
    
    return syncer.get_unfolded_history_dataframe(run_ids, metrics)

if __name__ == "__main__":
    # Example usage
    syncer = WandBSyncer()
    
    # Example run IDs - replace with your actual run IDs
    run_ids = [
        "your-run-id-1",
        "your-run-id-2",
        "your-run-id-3"
    ]
    
    # Sync runs (this will cache them locally)
    try:
        syncer.sync_multiple_runs(run_ids, entity="your-entity", project="your-project")
        
        # Create combined CSV
        csv_path = syncer.create_combined_csv(include_history=True)
        print(f"Combined CSV created at: {csv_path}")
        
        # Load as DataFrame
        df = syncer.load_runs_dataframe()
        print(f"Loaded {len(df)} runs")
        print(df.head())
        
    except Exception as e:
        print(f"Error: {e}")
        print("Make sure you have valid run IDs and are logged into W&B")
