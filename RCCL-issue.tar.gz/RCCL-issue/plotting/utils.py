import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
from typing import Optional, Tuple
from matplotlib.figure import Figure
from matplotlib.axes import Axes

def rename_metrics(df: pd.DataFrame) -> pd.DataFrame:
    """
    Rename columns in the DataFrame to match the expected format.
    """
    df = df.rename(columns={
        'summary_MulticlassAccuracy_val/dataloader_idx_0': 'Validation Accuracy',
        'summary_MulticlassAccuracy_train/dataloader_idx_0': 'Train Accuracy',
        'summary_val_pg_score/dataloader_idx_1': 'PG Score',
        'summary_Loss_val/dataloader_idx_0': 'Loss_val',
        'summary_Loss_train/dataloader_idx_0': 'Loss_train',
    })
    return df

def rename_names(df: pd.DataFrame) -> pd.DataFrame:
    """
    Rename 'name' column to 'model_name' if it exists.
    """
    if 'name' in df.columns:
        df = df.rename(columns={'name': 'Model'})

    return df

def rename_configs(df: pd.DataFrame) -> pd.DataFrame:
    """
    Rename configuration columns to more readable names.
    """
    df = df.rename(
        columns={
            "config_model_trainable_params": "Trainable Parameters (M)",
        }
    )
    return df

def rename(df: pd.DataFrame, metrics = True, name = True, configs = True) -> pd.DataFrame:
    """
    Apply all renaming functions to the DataFrame.
    """

    if metrics: df = rename_metrics(df)
    if name: df = rename_names(df)
    if configs: df = rename_configs(df)
    return df

def rename_adapter_position(df: pd.DataFrame) -> pd.DataFrame:
    df = df.rename(
        columns={
        "config_enable_bottleneck_layers": "Adapter Position",
    }
    )
    return df



def add_trainable_layers_column(df, frozen_layers_col='config_define_frozen_layers', new_col_name='trainable_layers'):
    """
    Add a trainable layers column to DataFrame based on frozen layers column.
    
    Args:
        df: DataFrame to modify
        frozen_layers_col: Name of the column containing frozen layers (default: 'config_define_frozen_layers')
        new_col_name: Name for the new trainable layers column (default: 'trainable_layers')
    
    Returns:
        DataFrame with new trainable layers column added
    """
    def frozen_to_trainable(frozen_str):
        """Convert frozen layers string to trainable layers description"""
        # All ResNet layers
        all_layers = ['layer1', 'layer2', 'layer3', 'layer4']
        
        # Handle empty list (no frozen layers)
        if frozen_str == "[]" or pd.isna(frozen_str):
            return "All layers (1-4)"
        
        try:
            # Parse the frozen layers string - remove brackets and quotes
            frozen_clean = frozen_str.strip("[]").replace("'", "").replace('"', '')
            if not frozen_clean:
                return "All layers (1-4)"
            
            # Split and clean
            frozen = [layer.strip() for layer in frozen_clean.split(",") if layer.strip()]
            
            # Get trainable layers (all layers minus frozen ones)
            trainable = [layer for layer in all_layers if layer not in frozen]
            
            # Format output
            if not trainable:
                return "No trainable layers"
            elif len(trainable) == 4:
                return "All layers (1-4)"
            elif len(trainable) == 1:
                layer_num = trainable[0].replace('layer', '')
                return f"Layer {layer_num} only"
            else:
                # Convert to numbers and create range if consecutive
                layer_nums = sorted([int(layer.replace('layer', '')) for layer in trainable])
                
                # Check if consecutive
                if layer_nums == list(range(min(layer_nums), max(layer_nums) + 1)):
                    if len(layer_nums) == 2:
                        return f"Layers {min(layer_nums)}-{max(layer_nums)}"
                    else:
                        return f"Layers {min(layer_nums)}-{max(layer_nums)}"
                else:
                    # Non-consecutive layers
                    return f"Layers {', '.join(map(str, layer_nums))}"
                    
        except Exception as e:
            # Fallback for any parsing errors
            return f"Unknown: {frozen_str}"
    
    # Create a copy to avoid modifying original
    df_copy = df.copy()
    
    # Apply the function
    df_copy[new_col_name] = df_copy[frozen_layers_col].apply(frozen_to_trainable)
    
    return df_copy

def rename_adapter_factor_experiments(df: pd.DataFrame) -> pd.DataFrame:
    """
    Rename columns in the DataFrame for adapter factor experiments.
    """
    df = df.rename(
        columns={
            "config_conv_adapter_factor": "Conv-Adapter Factor",
        }
    )
    return df