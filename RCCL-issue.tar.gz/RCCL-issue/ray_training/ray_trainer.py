"""
Ray Lightning Trainer Integration
Provides backwards-compatible Lightning training with Ray's distributed capabilities.
"""

import os
import tempfile
from pathlib import Path
from typing import Dict, Any, Optional, Callable
import warnings

import torch
import ray
from ray import train
from ray.train import RunConfig, ScalingConfig, CheckpointConfig
import ray.train.lightning
from ray.train.lightning import RayTrainReportCallback
import lightning.pytorch as pl
from lightning.pytorch.loggers import WandbLogger
from lightning.pytorch.callbacks import ModelCheckpoint

from experiment.experiment import Experiment
from models.lightning_module import BcosLightningModule
from data.data_module import BcosDataModule
from callbacks.timer import TimerCallback
from wandb_osh.lightning_hooks import TriggerWandbSyncLightningCallback 


class RayLightningWrapper:
    """
    Wrapper that integrates Ray Train with PyTorch Lightning.
    Standard Lightning training is handled directly in train.py.
    """
    
    def __init__(
        self,
        experiment: Experiment,
        use_ray: bool = False,
        num_workers: int = 1,
        use_gpu: bool = True,
        resources_per_worker: Optional[Dict[str, float]] = None
    ):
        """
        Initialize Ray Lightning wrapper.
        
        Args:
            experiment: The experiment configuration object
            use_ray: Whether to use Ray for distributed training
            num_workers: Number of workers for distributed training
            use_gpu: Whether to use GPU
            resources_per_worker: Custom resource allocation per worker
        """
        self.experiment = experiment
        self.use_ray = use_ray
        self.num_workers = num_workers
        self.use_gpu = use_gpu
        self.resources_per_worker = resources_per_worker or {}
        
        # Initialize Ray if needed
        if self.use_ray and not ray.is_initialized():
            ray.init(ignore_reinit_error=True)
    
    def fit(self) -> None:
        """
        Fit the model using Ray distributed training.
        Standard Lightning training is handled in train.py.
        """
        if not self.use_ray:
            raise ValueError("RayLightningWrapper is only for Ray training. Use standard Lightning training in train.py for non-Ray training.")
        
        # Ray distributed training
        self._fit_ray()
    
    def _fit_ray(self) -> None:
        """
        Ray distributed training using Ray Train with proper Lightning integration.
        """
        import ray
        from ray import train
        from ray.train import RunConfig, ScalingConfig
        
        # Configure scaling
        scaling_config = ScalingConfig(
            num_workers=self.num_workers,
            use_gpu=self.use_gpu,
            resources_per_worker=self.resources_per_worker
        )
        
        # Configure run
        run_config = RunConfig(
            name=f"ray_{self.experiment.experiment_name}",
        )
        
        # Create training function that follows Ray Lightning best practices
        def train_func():
            import wandb
            import lightning.pytorch as pl
            import ray.train.lightning
            from ray.train.lightning import RayTrainReportCallback, RayDDPStrategy, RayLightningEnvironment
            from lightning.pytorch.loggers.wandb import WandbLogger
            from lightning.pytorch.callbacks import ModelCheckpoint
            from callbacks.timer import TimerCallback
            
            # Set up PyTorch settings
            torch.set_float32_matmul_precision(self.experiment.matmul_precision)
            
            # Calculate effective batch size for Ray distributed training
            world_size = train.get_context().get_world_size()
            effective_batch_size = self.experiment.batch_size * world_size * self.experiment.accumulate_grad_batches
            print(f"📊 Ray effective batch size: {effective_batch_size} (batch_size={self.experiment.batch_size} × world_size={world_size} × grad_accum={self.experiment.accumulate_grad_batches})")
            
            # Get wandb config with effective batch size
            wandb_config = self.experiment.to_wandb_config()
            wandb_config["effective_batch_size"] = effective_batch_size
            wandb_config["world_size"] = world_size
            wandb_config["ray_num_workers"] = self.num_workers
            
            # Initialize W&B with Ray-specific naming
            run_name = f"{self.experiment.experiment_name}_ray_worker_{train.get_context().get_world_rank()}"
            wandb.init(
                project="Improved-Interpretability-and-Concepts",
                entity="raphaelmaser",
                name=run_name,
                group=f"{self.experiment.group}_ray" if self.experiment.group else "ray",
                config=wandb_config,
                tags=self.experiment.tags + ["ray_distributed"],
                reinit=True,
                dir=os.path.join(os.environ.get("TEMP_DIR", "./.cache"), "wandb"),
            )
            
            # Create logger
            logger = WandbLogger(
                log_model=False,
                name=run_name,
                save_dir=os.path.join(os.environ.get("TEMP_DIR", "./.cache"), "wandb"),
                project="Improved-Interpretability-and-Concepts",
                config=wandb_config,
                tags=self.experiment.tags + ["ray_distributed"],
                group=f"{self.experiment.group}_ray" if self.experiment.group else "ray"
            )
            
            # Set up callbacks (including Ray-specific callback)
            model_checkpoint = ModelCheckpoint(
                save_last=True, 
                every_n_epochs=20,
            )
            epochtimer = TimerCallback()
            ray_callback = RayTrainReportCallback()
            
            # Create trainer with Ray Lightning best practices
            trainer = pl.Trainer(
                max_epochs=self.experiment.epochs,
                logger=logger,
                accelerator="auto",  # Ray configures this automatically
                devices="auto",      # Ray configures this automatically
                precision=self.experiment.precision,
                default_root_dir=os.path.join(os.environ.get("TEMP_DIR", "./.cache"), "lightning"),
                limit_train_batches=self.experiment.limit_train_batches,
                limit_val_batches=self.experiment.limit_val_batches,
                callbacks=[model_checkpoint, epochtimer, ray_callback, TriggerWandbSyncLightningCallback()],
                # Ray-specific configurations following documentation
                strategy=RayDDPStrategy(),           # Use Ray's DDP strategy
                plugins=[RayLightningEnvironment()], # Use Ray's environment plugin
                num_nodes=1,  # Ray handles multi-node coordination
            )
            
            # Prepare trainer for Ray (validates configuration)
            trainer = ray.train.lightning.prepare_trainer(trainer)
            
            # Create data module and lightning module (unchanged!)
            data_module = BcosDataModule(experiment=self.experiment)
            lightning_module = BcosLightningModule(experiment=self.experiment)
            
            # Train the model
            trainer.fit(lightning_module, data_module)
            
            # Ray callback automatically reports metrics, but we can add final metrics
            if hasattr(trainer.callback_metrics, 'items'):
                final_metrics = {}
                for k, v in trainer.callback_metrics.items():
                    if hasattr(v, 'item'):
                        final_metrics[k] = v.item()
                    else:
                        final_metrics[k] = v
                # Ray callback handles reporting automatically
        
        # Run the training with Ray Train
        from ray.train.torch import TorchTrainer
        
        trainer = TorchTrainer(
            train_func,
            scaling_config=scaling_config,
            run_config=run_config,
        )
        
        result = trainer.fit()
        
        print(f"Ray training completed. Result: {result}")


class RayTrainingConfig:
    """Configuration for Ray training"""
    
    def __init__(
        self,
        use_ray: bool = False,
        num_workers: Optional[int] = None,
        use_gpu: bool = True,
        resources_per_worker: Optional[Dict[str, float]] = None,
        ray_address: Optional[str] = None,
        experiment: Optional[Experiment] = None,
    ):
        self.use_ray = use_ray
        self.experiment = experiment
        
        # Use experiment's num_workers if available, otherwise default to 1
        if num_workers is not None:
            self.num_workers = num_workers
        elif experiment is not None:
            self.num_workers = experiment.num_gpus  # Use num_gpus for Ray workers (1 worker per GPU)
        else:
            self.num_workers = 1
            
        self.use_gpu = use_gpu
        
        # Set resources per worker based on experiment or defaults
        if resources_per_worker is not None:
            self.resources_per_worker = resources_per_worker
        elif experiment is not None:
            # Use experiment-based resource allocation
            self.resources_per_worker = {
                "CPU": experiment.num_workers // max(1, experiment.num_gpus),  # Distribute CPU workers across GPUs
                "GPU": 1.0 if use_gpu else 0.0  # 1 full GPU per Ray worker
            }
        else:
            self.resources_per_worker = {"CPU": 1, "GPU": 1.0 if use_gpu else 0.0}
            
        self.ray_address = ray_address
    
    def initialize_ray(self):
        """Initialize Ray with proper configuration"""
        if self.use_ray and not ray.is_initialized():
            if self.ray_address:
                ray.init(address=self.ray_address)
            else:
                ray.init(ignore_reinit_error=True)


def create_ray_trainer(
    experiment: Experiment,
    ray_config: Optional[RayTrainingConfig] = None
) -> RayLightningWrapper:
    """
    Factory function to create a Ray-enabled trainer.
    
    Args:
        experiment: Experiment configuration
        ray_config: Ray training configuration
    
    Returns:
        RayLightningWrapper instance
    """
    if ray_config is None:
        ray_config = RayTrainingConfig()
    
    return RayLightningWrapper(
        experiment=experiment,
        use_ray=ray_config.use_ray,
        num_workers=ray_config.num_workers,
        use_gpu=ray_config.use_gpu,
        resources_per_worker=ray_config.resources_per_worker
    )
