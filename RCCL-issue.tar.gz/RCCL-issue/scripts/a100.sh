#!/bin/bash
#SBATCH -p gpu22
#SBATCH -t 10:00:00
#SBATCH -o /home/rmaser/Master-Thesis_Improved-Interpretability-and-Concepts/slurm/slurm-%j.out
#SBATCH -c 16
#SBATCH --gres gpu:a100:1
#SBATCH --mem 200000

nvidia-smi
pixi run train --experiment_name  "$1" --num_workers 15
