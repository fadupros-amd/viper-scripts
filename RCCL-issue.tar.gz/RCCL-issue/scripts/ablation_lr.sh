#!/bin/bash
#SBATCH --array=1-12
#SBATCH -p gpu22
#SBATCH -t 8:00:00
#SBATCH -o /home/rmaser/Master-Thesis_Improved-Interpretability-and-Concepts/slurm/ablation-%A_%a.out
#SBATCH -c 30
#SBATCH --gres gpu:1
#SBATCH --mem 100000

# Learning Rate Ablation Study
# Tests different learning rates with Ray distributed training

# Define learning rates to test
learning_rates=(1e-5 5e-5 1e-4 5e-4 1e-3 5e-3 1e-2 5e-2 1e-1 5e-1 1e0 2e0)

lr=${learning_rates[$((SLURM_ARRAY_TASK_ID-1))]}

echo "🔬 Running LR ablation with lr=$lr"
echo "📊 Array task: $SLURM_ARRAY_TASK_ID"
echo "🎯 GPU: $CUDA_VISIBLE_DEVICES"

nvidia-smi

# Run experiment with Ray (default)
pixi run train \
    --experiment_name "lr_ablation_baseline" \
    --lr $lr \
    --group "ablation_lr" \
    --tags "['ablation', 'learning_rate']"

echo "✅ Completed LR ablation with lr=$lr"
