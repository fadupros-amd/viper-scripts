#!/bin/bash
#SBATCH --array=1-9
#SBATCH -p gpu22
#SBATCH -t 10:00:00
#SBATCH -o /home/rmaser/Master-Thesis_Improved-Interpretability-and-Concepts/slurm/ablation_multi-%A_%a.out
#SBATCH -c 30
#SBATCH --gres gpu:1
#SBATCH --mem 100000

# Multi-Parameter Ablation Study
# Tests combinations of learning rate, weight decay, and batch size

# Define parameter combinations
case $SLURM_ARRAY_TASK_ID in
    1) lr=1e-3; wd=0.0; bs=128 ;;
    2) lr=1e-3; wd=0.01; bs=128 ;;
    3) lr=1e-3; wd=0.1; bs=128 ;;
    4) lr=5e-4; wd=0.0; bs=256 ;;
    5) lr=5e-4; wd=0.01; bs=256 ;;
    6) lr=5e-4; wd=0.1; bs=256 ;;
    7) lr=1e-4; wd=0.0; bs=512 ;;
    8) lr=1e-4; wd=0.01; bs=512 ;;
    9) lr=1e-4; wd=0.1; bs=512 ;;
esac

echo "🔬 Running multi-parameter ablation:"
echo "  📈 Learning rate: $lr"
echo "  ⚖️  Weight decay: $wd"
echo "  📦 Batch size: $bs"
echo "📊 Array task: $SLURM_ARRAY_TASK_ID"

nvidia-smi

# Create unique experiment name
exp_name="multi_ablation_lr${lr}_wd${wd}_bs${bs}"

# Run experiment with Ray
pixi run train \
    --experiment_name "baseline_resnet" \
    --lr $lr \
    --weight_decay $wd \
    --batch_size $bs \
    --group "ablation_multi_param" \
    --tags "['ablation', 'multi_param']" \
    --experiment_name "$exp_name"

echo "✅ Completed: $exp_name"
