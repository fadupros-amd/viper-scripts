#!/bin/bash
#SBATCH -p gpu24
#SBATCH -t 3:00:00
#SBATCH -o /home/rmaser/Master-Thesis_Improved-Interpretability-and-Concepts/slurm/slurm-%A_%a.out
#SBATCH -c 30
#SBATCH --gres gpu:h100:1
#SBATCH --mem 200000
#SBATCH --array=1-5

##experiment_name="B=1_pretrained_CE-parallel_residual_adapters-B=2"
#normalize=True

case $SLURM_ARRAY_TASK_ID in
    1)
        experiment_name="B=1_pretrained_CE-parallel-residual-adapters-B=1_B=1"
        ;;
    2)
        experiment_name="B=1_pretrained_CE-parallel-residual-adapters-B=2_B=1"
        ;;
    3)
        experiment_name="B=1_pretrained_CE-parallel-residual-adapters-B=1_B=2"
        ;;
    4)
        experiment_name="B=1_pretrained_CE-parallel-residual-adapters-B=2_B=2"
        ;;
    5)
        experiment_name="B=1_pretrained_CE_bcosified"
        ;;
esac

nvidia-smi
pixi run train --experiment_name  "$experiment_name" --num_workers 28 --group "adapter-experiments-v2"
