#!/bin/bash
#SBATCH -p gpu24
#SBATCH -t 12:00:00
#SBATCH -o /home/rmaser/Master-Thesis_Improved-Interpretability-and-Concepts/slurm/slurm-%A_%a.out
#SBATCH -c 30
#SBATCH --gres gpu:h100:1
#SBATCH --mem 200000
#SBATCH --array=2-2

group="adapter-final"
conv_adapter_factor=2
epochs=100
case $SLURM_ARRAY_TASK_ID in
    1)
        experiment_name="B=1_pretrained_CE_bcosified"
        ;;
    2)
        experiment_name="B=1_pretrained_CE-parallel-adapters-B=2_B=2"
        conv_adapter_factor=4
	;;
    3)
        experiment_name="B=1_pretrained_CE-parallel-adapters-B=2_B=2"
        conv_adapter_factor=16
	;;
esac

nvidia-smi
pixi run train --experiment_name  "$experiment_name" --num_workers 28 --conv_adapter_factor $conv_adapter_factor --group $group --epochs $epochs
