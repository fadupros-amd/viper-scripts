#!/bin/bash
#SBATCH -p gpu24
#SBATCH -t 2:00:00
#SBATCH -o /home/rmaser/Master-Thesis_Improved-Interpretability-and-Concepts/slurm/slurm-%A_%a.out
#SBATCH -c 30
#SBATCH --gres gpu:h100:1
#SBATCH --mem 200000
#SBATCH --array=4-4

experiment_name="B=1_pretrained_CE_adapter-block"

case $SLURM_ARRAY_TASK_ID in
    1)
	experiment_name="B=1_pretrained_CE"
        ;;
    2)
        factor=1
        ;;
    3)
        factor=2
        ;;
    4)
        factor=4
        ;;
    5)
        factor=8
        ;;
esac

nvidia-smi
pixi run train --experiment_name  "$experiment_name" --num_workers 28 --conv_adapter_factor $factor --explanation_metric_treshold 0.9
