#!/bin/bash
#SBATCH -p gpu22
#SBATCH -t 8:00:00
#SBATCH -o /home/rmaser/Master-Thesis_Improved-Interpretability-and-Concepts/slurm/slurm-%A_%a.out
#SBATCH -c 9
#SBATCH --gres gpu:a40:1
#SBATCH --array=1-6
#SBATCH --mem 200000

# call your program here
# export DATA_ROOT="./.dataset"


# nvidia-smi
echo "SLURM_JOB_ID: $SLURM_JOB_ID"
echo "SLURM_ARRAY_TASK_ID: $SLURM_ARRAY_TASK_ID"

model="ResNet50_bottleneck_pretrained-CE"
model_frozen="ResNet50_bottleneck_pretrained-CE_frozen"

case $SLURM_ARRAY_TASK_ID in
    1)
        b_classifier=0.5
        ;;
    2)  
        b_classifier=1
        ;;
    3)
        b_classifier=1.5
        ;;
    4)
        b_classifier=2
        ;;
    5)
        b_classifier=2.5
        ;;
    6)
        b_classifier=3
        ;;
esac


# pixi run train --experiment_name $model --group bottleneck_position_resnet --enable_bottleneck_layers $enable_bottleneck_layers #--num_workers 14
pixi run train --experiment_name $model_frozen --group b_value_classifier --b_classifier $b_classifier --enable_bottleneck_layers "[0,0,0,0,0]" --num_workers 8
