#!/bin/bash
#SBATCH -p gpu24
#SBATCH -t 8:00:00
#SBATCH -o /home/rmaser/Master-Thesis_Improved-Interpretability-and-Concepts/slurm/slurm-%A_%a.out
#SBATCH -c 30
#SBATCH --gres gpu:1
#SBATCH --array=3-8
#SBATCH --mem 200000

# call your program here
# export DATA_ROOT="./.dataset"


nvidia-smi
echo "SLURM_JOB_ID: $SLURM_JOB_ID"
echo "SLURM_ARRAY_TASK_ID: $SLURM_ARRAY_TASK_ID"

epochs=20
enable_bottleneck_layers="[0,1,1,1,1]"
add_initial_adapter="False"

case $SLURM_ARRAY_TASK_ID in
    1)
        model_frozen="B=1-pretrained-CE_B=2-adapter-layer_B=2-classifier"
        remove_adapter_skip_connections="False"
        group="bottleneck_position_resnet"
        ;;
    2)
        model_frozen="B=2-pretrained_B=1-adapter-layer_B=1-classifier"
        remove_adapter_skip_connections="False"
        group="bottleneck_position_bcos"
        ;;
    3)
        model_frozen="B=1-pretrained-CE_B=2-adapter-layer_B=2-classifier_frozen"
        remove_adapter_skip_connections="True"
        group="bottleneck_position_resnet"
        epochs=90
        ;;
    4)
        model_frozen="B=1-pretrained-CE_B=2-adapter-layer_B=2-classifier"
        remove_adapter_skip_connections="True"
        group="bottleneck_position_resnet"
        epochs=90
        ;;
    5)
        model_frozen="B=1-pretrained-CE_B=2-adapter-layer_B=2-classifier_frozen"
        remove_adapter_skip_connections="True"
        group="bottleneck_position_resnet"
        enable_bottleneck_layers="[0,0,0,0,1]"
        ;;
    6)
        model_frozen="B=1-pretrained-CE_B=2-adapter-layer_B=2-classifier"
        remove_adapter_skip_connections="True"
        group="bottleneck_position_resnet"
        enable_bottleneck_layers="[0,0,0,0,1]"
        ;;
    7)
        model_frozen="B=1-pretrained-CE_B=2-adapter-layer_B=2-classifier"
        remove_adapter_skip_connections="True"
        add_initial_adapter="True"
        group="bottleneck_position_resnet"
        enable_bottleneck_layers="[0,0,0,0,1]"
        ;;
    8)
        model_frozen="B=1-pretrained-CE_B=2-adapter-layer_B=2-classifier_frozen"
        remove_adapter_skip_connections="True"
        add_initial_adapter="True"
        group="bottleneck_position_resnet"
        enable_bottleneck_layers="[0,0,0,0,1]"
        ;;
    9)
        model_frozen="B=1-pretrained-CE_B=2-adapter-layer_B=2-classifier_frozen"
        remove_adapter_skip_connections="True"
        add_initial_adapter="True"
        group="bottleneck_position_resnet"
        enable_bottleneck_layers="[0,0,0,0,1]"
        ;;
esac


pixi run train --experiment_name $model_frozen --group $group --enable_bottleneck_layers $enable_bottleneck_layers --remove_adapter_skip_connections $remove_adapter_skip_connections --add_initial_adapter $add_initial_adapter --num_workers 24 --epochs $epochs
# pixi run train --experiment_name $model --group "bottleneck_position_resnet" --enable_bottleneck_layers $enable_bottleneck_layers --num_workers 8
