#!/bin/bash
#SBATCH -o /u/rmaser/Master-Thesis_Improved-Interpretability-and-Concepts/slurm/slurm-%j_%a.out
#SBATCH -t 3:00:00
#SBATCH -c 24
#SBATCH --constraint="apu"
#SBATCH --gres=gpu:1
#SBATCH --mem=120000
#SBATCH --array=1-10

# call your program here
# export DATA_ROOT="./.dataset"

nvidia-smi
echo "SLURM_JOB_ID: $SLURM_JOB_ID"
echo "SLURM_ARRAY_TASK_ID: $SLURM_ARRAY_TASK_ID"

model="BcosResNet50_bottleneck_pretrained"
model_frozen="BcosResNet50_bottleneck_pretrained_frozen"

case $SLURM_ARRAY_TASK_ID in
    1)
        enable_bottleneck_layers="[1,1,0,0,0]"
        ;;
    2)  
        enable_bottleneck_layers="[0,1,1,0,0]"
        ;;
    3)
        enable_bottleneck_layers="[0,0,1,1,0]"
        ;;
    4)
        enable_bottleneck_layers="[0,0,0,1,1]"
        ;;
    5)
        enable_bottleneck_layers="[1,1,1,0,0]"
        ;;
    6)
        enable_bottleneck_layers="[0,1,1,1,0]"
        ;;
    7)
        enable_bottleneck_layers="[0,0,1,1,1]"
        ;;
    8)
        enable_bottleneck_layers="[1,1,1,1,0]"
        ;;
    9)
        enable_bottleneck_layers="[0,1,1,1,1]"
        ;;
    10)
        enable_bottleneck_layers="[1,1,1,1,1]"
        ;;
esac


# pixi run train --experiment_name $model --group bottleneck_position_bcos --enable_bottleneck_layers "$enable_bottleneck_layers" #--num_workers 14 #--compile False  --precision 16
pixi run train_viper --experiment_name $model_frozen --group bottleneck_position_bcos --enable_bottleneck_layers "$enable_bottleneck_layers" --num_workers 24 #--compile False  --precision 16
