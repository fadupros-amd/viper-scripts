#!/bin/bash
#SBATCH -o /u/rmaser/Master-Thesis_Improved-Interpretability-and-Concepts/slurm/slurm-%A_%a.out
#SBATCH -t 2:00:00
#SBATCH -c 24
#SBATCH --constraint="apu"
#SBATCH --gres=gpu:1
#SBATCH --mem=120000
#SBATCH --array=1-5

# call your program here
# export DATA_ROOT="./.dataset"


nvidia-smi
echo "SLURM_JOB_ID: $SLURM_JOB_ID"
echo "SLURM_ARRAY_TASK_ID: $SLURM_ARRAY_TASK_ID"

model="ResNet50_adapter-layers_pretrained-CE"
model_frozen="ResNet50_adapter-layers_pretrained-CE_frozen"

case $SLURM_ARRAY_TASK_ID in
    1)
        enable_bottleneck_layers="[0,0,0,0,0]"
        ;;
    2)
        enable_bottleneck_layers="[0,1,0,0,0]"
        ;;
    3)
        enable_bottleneck_layers="[0,0,1,0,0]"
        ;;
    4)
        enable_bottleneck_layers="[0,0,0,1,0]"
        ;;
    5)
        enable_bottleneck_layers="[0,0,0,0,1]"
        ;;
esac


# pixi run train --experiment_name $model --group bottleneck_position_resnet --enable_bottleneck_layers $enable_bottleneck_layers #--num_workers 14
pixi run train_viper --experiment_name $model_frozen --group bottleneck_position_resnet --enable_bottleneck_layers $enable_bottleneck_layers --num_workers 24
