#!/bin/bash
#SBATCH -p gpu24
#SBATCH -t 4:00:00
#SBATCH -o /home/rmaser/Master-Thesis_Improved-Interpretability-and-Concepts/slurm/slurm-%A_%a.out
#SBATCH -c 30
#SBATCH --gres gpu:1
#SBATCH --array=4-4
#SBATCH --mem 200000

# call your program here
# export DATA_ROOT="./.dataset"


nvidia-smi
echo "SLURM_JOB_ID: $SLURM_JOB_ID"
echo "SLURM_ARRAY_TASK_ID: $SLURM_ARRAY_TASK_ID"

case $SLURM_ARRAY_TASK_ID in
    1)
        model="B=2-Base_B=1-adapter_B=2-classifier"
        ;;
    2)
        model="B=1-Base_B=2-adapter_B=2-classifier"
        ;;
    3)
        model="B=2-Base_B=1-adapter_B=1-classifier"
        ;;
    4)
        model="B=1-Base_B=2-adapter_B=1-classifier"
        ;;
esac


pixi run train --experiment_name $model --num_workers 24
