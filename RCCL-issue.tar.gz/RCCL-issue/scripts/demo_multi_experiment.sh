#!/bin/bash
# Multi-Experiment Ray Tune Demo
# Shows how multiple independent experiments can share a persistent cluster

echo "🚀 Ray Tune Multi-Experiment Demo"
echo "=================================="

# 1. Start persistent cluster
echo "Step 1: Starting persistent Ray head..."
sbatch scripts/ray_persistent_head.sh
HEAD_JOB_ID=$(squeue -u $USER -n ray-head -h -o "%i" | head -n1)
echo "Head job ID: $HEAD_JOB_ID"

echo "Waiting 30 seconds for head to initialize..."
sleep 30

# 2. Submit multiple experiments in parallel
echo ""
echo "Step 2: Submitting multiple experiments..."

# Experiment 1: Learning rate search (2 nodes)
sed 's/--nodes=2/--nodes=2/' scripts/vitc/peft/PEFT-ablation-eva-ranger21-lr-persistent.sh > /tmp/exp1.sh
sed -i 's/vitc_b_16_B=2_pretrained_PEFT_lora_eva_persistent/exp1_lr_search/' /tmp/exp1.sh
sed -i 's/vitc-peft-lora-eva-ranger21-lr-persistent/exp1-lr-search/' /tmp/exp1.sh
sbatch /tmp/exp1.sh
EXP1_JOB=$(squeue -u $USER -h -o "%i" | tail -n1)
echo "Experiment 1 (LR search): Job $EXP1_JOB"

# Small delay to avoid resource conflicts
sleep 5

# Experiment 2: Optimizer search (1 node) 
sed 's/--nodes=2/--nodes=1/' scripts/vitc/peft/PEFT-ablation-eva-ranger21-lr-persistent.sh > /tmp/exp2.sh
sed -i 's/vitc_b_16_B=2_pretrained_PEFT_lora_eva_persistent/exp2_optimizer_search/' /tmp/exp2.sh
sed -i 's/vitc-peft-lora-eva-ranger21-lr-persistent/exp2-optimizer-search/' /tmp/exp2.sh
sed -i "s/--lr .*'/--optimizer '[adam,adamw,sgd,ranger21]' --lr 0.001'/" /tmp/exp2.sh
sbatch /tmp/exp2.sh
EXP2_JOB=$(squeue -u $USER -h -o "%i" | tail -n1)
echo "Experiment 2 (Optimizer search): Job $EXP2_JOB"

echo ""
echo "Step 3: Monitor progress..."
echo "Ray Dashboard: Check cluster info file when head is ready"
echo "Watch jobs: watch squeue -u $USER"
echo ""
echo "Active Jobs:"
echo "- Head: $HEAD_JOB_ID (persistent)"
echo "- Exp1: $EXP1_JOB (2 nodes, LR search)"  
echo "- Exp2: $EXP2_JOB (1 node, optimizer search)"
echo ""
echo "Key Benefits:"
echo "✅ Shared cluster - no initialization delay"
echo "✅ Independent experiments - can run simultaneously"  
echo "✅ Auto-scaling - workers join/leave dynamically"
echo "✅ Resource efficiency - only use GPU nodes when training"
echo "✅ Development friendly - cluster persists while you code"

# Cleanup script
cat > /tmp/cleanup_demo.sh << 'EOF'
#!/bin/bash
echo "Cleaning up Ray Tune demo..."
scancel -u $USER -n ray-head
rm -f /tmp/ray_cluster_${USER}.info
rm -f /tmp/exp*.sh
echo "Demo cleanup complete"
EOF
chmod +x /tmp/cleanup_demo.sh

echo ""
echo "When done, run: /tmp/cleanup_demo.sh"
