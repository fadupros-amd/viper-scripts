#!/bin/bash
#SBATCH -p gpu24
#SBATCH -t 2:00:00
#SBATCH -o /home/rmaser/Master-Thesis_Improved-Interpretability-and-Concepts/slurm/slurm-%A_%a.out
#SBATCH -c 30
#SBATCH --gres gpu:1
#SBATCH --array=7-7
#SBATCH --mem 200000


# nvidia-smi
echo "SLURM_JOB_ID: $SLURM_JOB_ID"
echo "SLURM_ARRAY_TASK_ID: $SLURM_ARRAY_TASK_ID"

model="B=1-pretrained-CE_B=2-adapter-layer_B=2-classifier_frozen"
model="B=1-pretrained-CE_B=2-classifier_frozen"
epochs=20
num_workers=24

case $SLURM_ARRAY_TASK_ID in
    1)
        define_frozen_layers='["layer2","layer3","layer4"]'
        overwrite_b_for_layer='{"layer1":2}'
        ;;
    2)  
        define_frozen_layers='["layer1","layer3","layer4"]'
        overwrite_b_for_layer='{"layer2":2}'
        ;;
    3)
        define_frozen_layers='["layer1","layer2","layer4"]'
        overwrite_b_for_layer='{"layer3":2}'
        ;;
    4)
        define_frozen_layers='["layer1","layer2","layer3"]'
        overwrite_b_for_layer='{"layer4":2}'
        ;;
    5)
        define_frozen_layers='["layer3","layer4"]'
        overwrite_b_for_layer='{"layer1":2,"layer2":2}'
        ;;
    6)
        define_frozen_layers='["layer4"]'
        overwrite_b_for_layer='{"layer1":2,"layer2":2,"layer3":2}'
        ;;
    7)
        define_frozen_layers='[]'
        overwrite_b_for_layer='{"layer1":2,"layer2":2,"layer3":2,"layer4":2}'
        ;;
esac


pixi run train --experiment_name "$model" --define_frozen_layers "$define_frozen_layers" --overwrite_b_for_layer "$overwrite_b_for_layer" --num_workers "$num_workers" --epochs "$epochs"
