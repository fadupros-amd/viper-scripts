#!/bin/bash
#SBATCH -p gpu24
#SBATCH -t 5:00:00
#SBATCH -o /home/rmaser/Master-Thesis_Improved-Interpretability-and-Concepts/slurm/slurm-%j.out
#SBATCH -c 30
#SBATCH --gres gpu:1
#SBATCH --mem-per-cpu=8000
 
# call your program here
# export DATA_ROOT="./.dataset"

nvidia-smi
pixi run train --experiment_name  "$1"
