#!/bin/bash
#SBATCH -p gpu24
#SBATCH -t 6:00:00
#SBATCH -o /home/rmaser/Master-Thesis_Improved-Interpretability-and-Concepts/slurm/slurm-%j_%a.out
#SBATCH -c 30
#SBATCH --gres gpu:1
#SBATCH --array=4-6
#SBATCH --mem-per-cpu=6144


# call your program here
# export DATA_ROOT="./.dataset"

nvidia-smi
echo "SLURM_JOB_ID: $SLURM_JOB_ID"
echo "SLURM_ARRAY_TASK_ID: $SLURM_ARRAY_TASK_ID"

case $SLURM_ARRAY_TASK_ID in
  # 1)
  #   srun pixi run train --experiment_name  BcosResNet50 --num_workers 8
  #   ;;
  # 2)
  #   srun pixi run train --experiment_name  BcosResNet50 --num_workers 16
  #   ;;
  # 3)
  #   srun pixi run train --experiment_name  BcosResNet50 --num_workers 24
  #   ;;
  # 4)
  #   srun pixi run train --experiment_name  EfficientBcosResNet50 --num_workers 8
  #   ;;
  # 5)
  #   srun pixi run train --experiment_name  EfficientBcosResNet50 --num_workers 16
  #   ;;
  6)
    srun pixi run train --experiment_name  EfficientBcosResNet50 --num_workers 24
    ;;
  # 7)
  #   srun pixi run train --experiment_name  ResNet50 --num_workers 8
  #   ;;
  # 8)
  #   srun pixi run train --experiment_name  ResNet50 --num_workers 16
  #   ;;
  # 9)
  #   srun pixi run train --experiment_name  ResNet50 --num_workers 24
  #   ;;
esac
