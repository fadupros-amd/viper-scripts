#!/bin/bash
#SBATCH -p gpu24
#SBATCH -t 2:00:00
#SBATCH -o /home/rmaser/Master-Thesis_Improved-Interpretability-and-Concepts/slurm/slurm-%j.out
#SBATCH -c 30
#SBATCH --gres gpu:1
#SBATCH --mem-per-cpu=8000
 
# call your program here
# export DATA_ROOT="./.dataset"

nvidia-smi
pixi run train --group pruned --experiment_name  "$1" --enable_bottleneck_layers "[0,0,0,0,0]"
