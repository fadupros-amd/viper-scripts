#!/bin/bash
# Auto-recovery wrapper for Ray experiments

EXPERIMENT_NAME="$1"
ORIGINAL_ARGS=("$@")

if [[ -z "$EXPERIMENT_NAME" ]]; then
    echo "Usage: $0 <experiment_name> [additional_tune_args...]"
    echo "Example: $0 my_lr_search --lr [0.001,0.01,0.1] --optimizer adamw"
    exit 1
fi

# Function to run experiment with recovery
run_experiment_with_recovery() {
    local max_retries=3
    local retry_count=0
    local success=false
    
    while [[ $retry_count -lt $max_retries && "$success" == "false" ]]; do
        echo "🚀 Attempt $((retry_count + 1))/$max_retries for experiment: $EXPERIMENT_NAME"
        
        # Check if head node is running
        cluster_info_file="/tmp/ray_cluster_${USER}.info"
        if [[ ! -f "$cluster_info_file" ]]; then
            echo "❌ No Ray head found. Starting recovery head..."
            sbatch scripts/ray_persistent_head_recovery.sh
            
            # Wait for head to start
            echo "⏳ Waiting for head node to initialize..."
            for i in {1..60}; do
                if [[ -f "$cluster_info_file" ]]; then
                    echo "✅ Head node ready!"
                    break
                fi
                sleep 5
                echo "   Waiting... ($((i*5))s)"
            done
            
            if [[ ! -f "$cluster_info_file" ]]; then
                echo "❌ Head node failed to start after 5 minutes"
                exit 1
            fi
        fi
        
        # Run experiment with auto-resume
        echo "🎯 Running experiment with auto-resume..."
        if pixi run tune "${ORIGINAL_ARGS[@]}" --resume; then
            echo "✅ Experiment completed successfully!"
            success=true
        else
            echo "❌ Experiment failed. Retry $((retry_count + 1))/$max_retries"
            retry_count=$((retry_count + 1))
            
            if [[ $retry_count -lt $max_retries ]]; then
                echo "⏳ Waiting 60 seconds before retry..."
                sleep 60
            fi
        fi
    done
    
    if [[ "$success" == "false" ]]; then
        echo "❌ Experiment failed after $max_retries attempts"
        exit 1
    fi
}

# Main execution
echo "🔄 Ray Tune Auto-Recovery Wrapper"
echo "================================="
echo "Experiment: $EXPERIMENT_NAME"
echo "Arguments: ${ORIGINAL_ARGS[*]}"
echo "Recovery: Enabled (max 3 retries)"
echo ""

run_experiment_with_recovery

echo ""
echo "✅ Experiment completed with recovery support!"
echo "📊 Results saved to ray_results/tune_${EXPERIMENT_NAME}/"
