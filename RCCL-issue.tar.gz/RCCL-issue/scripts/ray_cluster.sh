#!/bin/bash
# Ray Cluster Management Utility

CLUSTER_INFO_FILE="/tmp/ray_cluster_${USER}.info"

show_status() {
    if [[ ! -f "$CLUSTER_INFO_FILE" ]]; then
        echo "❌ No persistent Ray cluster found"
        echo "Start one with: sbatch scripts/ray_persistent_head.sh"
        return 1
    fi
    
    source "$CLUSTER_INFO_FILE"
    echo "🎯 Ray Cluster Status"
    echo "====================="
    echo "Address: $RAY_ADDRESS"
    echo "Dashboard: $RAY_DASHBOARD"
    echo ""
    
    # Check if cluster is responsive
    if pixi run ray status --address="$RAY_ADDRESS" 2>/dev/null; then
        echo "✅ Head node is running"
        
        # Show worker pools
        worker_pools_file="/tmp/ray_worker_pools_${USER}.list"
        if [[ -f "$worker_pools_file" && -s "$worker_pools_file" ]]; then
            echo ""
            echo "🔧 Active Worker Pools:"
            while read -r pool_name; do
                if [[ -n "$pool_name" ]]; then
                    pool_info="/tmp/${pool_name}.info"
                    if [[ -f "$pool_info" ]]; then
                        source "$pool_info"
                        echo "  - $pool_name: $WORKER_TYPE workers ($WORKER_NODES nodes, $WORKER_GPUS GPUs, $WORKER_CPUS CPUs)"
                    else
                        echo "  - $pool_name: (info file missing)"
                    fi
                fi
            done < "$worker_pools_file"
        else
            echo ""
            echo "⚠️  No active worker pools"
            echo "Add workers with:"
            echo "  sbatch scripts/ray_workers_gpu.sh    # GPU workers"
            echo "  sbatch scripts/ray_workers_cpu.sh    # CPU workers"
        fi
        
        echo ""
        echo "📊 Current cluster resources:"
        pixi run ray status --address="$RAY_ADDRESS" | grep -E "(node|CPU|GPU|memory)"
        
    else
        echo "❌ Cluster not responsive (may have stopped)"
        rm -f "$CLUSTER_INFO_FILE"
    fi
}

stop_cluster() {
    if [[ ! -f "$CLUSTER_INFO_FILE" ]]; then
        echo "❌ No persistent Ray cluster found"
        return 1
    fi
    
    source "$CLUSTER_INFO_FILE"
    echo "🛑 Stopping Ray cluster at $RAY_ADDRESS"
    pixi run ray stop --address="$RAY_ADDRESS"
    rm -f "$CLUSTER_INFO_FILE"
    echo "✅ Cluster stopped and info file removed"
}

start_cluster() {
    echo "🚀 Starting persistent Ray head node..."
    sbatch scripts/ray_persistent_head.sh
    echo "Wait ~30 seconds, then check status with: $0 status"
}

case "$1" in
    "status")
        show_status
        ;;
    "stop")
        stop_cluster
        ;;
    "start")
        start_cluster
        ;;
    "workers")
        case "$2" in
            "gpu")
                echo "🚀 Starting GPU worker pool..."
                sbatch scripts/ray_workers_gpu.sh
                ;;
            "cpu") 
                echo "🚀 Starting CPU worker pool..."
                sbatch scripts/ray_workers_cpu.sh
                ;;
            *)
                echo "Usage: $0 workers {gpu|cpu}"
                ;;
        esac
        ;;
    "experiment")
        echo "🧪 Submitting experiment to cluster..."
        # Pass environment variables for customization
        sbatch scripts/ray_experiment.sh
        ;;
    *)
        echo "Ray Cluster Management (Decoupled Architecture)"
        echo "==============================================="
        echo "Usage: $0 {status|start|stop|workers|experiment}"
        echo ""
        echo "Commands:"
        echo "  status            - Show cluster and worker pool status"
        echo "  start             - Start persistent Ray head node"
        echo "  stop              - Stop the entire cluster"
        echo "  workers gpu       - Add GPU worker pool"
        echo "  workers cpu       - Add CPU worker pool"  
        echo "  experiment        - Submit experiment to existing cluster"
        echo ""
        echo "Decoupled Workflow:"
        echo "  1. $0 start                    # Start head node"
        echo "  2. $0 workers gpu              # Add GPU workers"
        echo "  3. $0 experiment               # Submit experiment 1"
        echo "  4. $0 experiment               # Submit experiment 2"
        echo "  5. $0 workers gpu              # Add more workers if needed"
        echo "  6. $0 status                   # Monitor progress"
        echo "  7. $0 stop                     # Stop everything"
        echo ""
        echo "Benefits:"
        echo "  ✅ Complete decoupling of resources and experiments"
        echo "  ✅ Dynamic worker scaling independent of experiments"
        echo "  ✅ Multiple experiments share same worker pool"
        echo "  ✅ Optimal resource utilization"
        ;;
esac
