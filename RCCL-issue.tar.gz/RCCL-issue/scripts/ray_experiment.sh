#!/bin/bash
#SBATCH -p cpu20  # Lightweight job - just experiment submission
#SBATCH -t 0:10:00  # Short time - just to submit experiment
#SBATCH -o /home/rmaser/Master-Thesis_Improved-Interpretability-and-Concepts/slurm/experiment-%A.out
#SBATCH --job-name=ray-experiment

### Pure experiment submission (no worker allocation)
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=1
#SBATCH -c 2  # Minimal resources
#SBATCH --mem 8000

# Experiment parameters (customize these)
EXPERIMENT_NAME="vitc_b_16_B=2_pretrained_PEFT_lora_eva"
GROUP_NAME="test"
LR_VALUES="[0.002,0.001,0.0005,0.0002,0.0001]"
OPTIMIZER="ranger21"

echo "=== Ray Tune Experiment Submission ==="
echo "SLURM_JOB_ID: $SLURM_JOB_ID"
echo "Experiment: $EXPERIMENT_NAME"
echo "Group: $GROUP_NAME"
echo "Learning rates: $LR_VALUES"
echo "Optimizer: $OPTIMIZER"
echo "======================================"

# Read cluster info from persistent head
cluster_info_file="$HOME/ray_cluster_${USER}.info"

if [[ ! -f "$cluster_info_file" ]]; then
    echo "❌ ERROR: Ray cluster info file not found: $cluster_info_file"
    echo "Please start the persistent Ray head first:"
    echo "  sbatch scripts/ray_persistent_head.sh"
    exit 1
fi

# Load cluster connection info
source "$cluster_info_file"

# Export RAY_ADDRESS so it's available to subprocess
export RAY_ADDRESS

# Create logs directory if it doesn't exist
mkdir -p "$HOME/ray_logs"

# Check if workers are available
echo "Checking available workers..."
pixi run ray status --address="$RAY_ADDRESS"

# Force output to be displayed properly
export PYTHONUNBUFFERED=1
export RAY_DISABLE_IMPORT_WARNING=1

# Debug: Show environment variables
echo "🔍 Environment variables:"
echo "  RAY_ADDRESS=$RAY_ADDRESS"
echo "  RAY_HEAD_IP=$RAY_HEAD_IP"
echo "  RAY_HEAD_PORT=$RAY_HEAD_PORT"

# Submit experiment to existing cluster
echo "Submitting experiment to Ray cluster..."
echo "Ray address: $RAY_ADDRESS"
echo "=========================="

# Run experiment (this will use whatever workers are available)
pixi run tune \
    --experiment_name "$EXPERIMENT_NAME" \
    --group "$GROUP_NAME" \
    --lr "$LR_VALUES" \
    --optimizer "$OPTIMIZER" \
    --weight_decay 0.01 \
    --peft_config.r 8 \
    --peft_config.lora_alpha 16 \
    --gpus_per_trial 1.0 \
    --tags "decoupled" "pure-experiment" 2>&1 | tee "$HOME/ray_logs/experiment_${SLURM_JOB_ID}.log"

echo "=========================="
echo "Experiment submission completed!"

# Show final cluster status
echo "Final Ray cluster status:"
pixi run ray status --address="$RAY_ADDRESS"

echo "Experiment submitted successfully to job $SLURM_JOB_ID"
echo "Results will appear in ray_results/ directory"
echo "Workers and head node continue running for other experiments"
