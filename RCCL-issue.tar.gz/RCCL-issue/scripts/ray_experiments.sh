#!/bin/bash
# Simple script to list and resume Ray Tune experiments

STORAGE_PATH="./ray_results"

list_experiments() {
    echo "📊 Available Ray Tune Experiments:"
    echo "=================================="
    
    if [[ ! -d "$STORAGE_PATH" ]]; then
        echo "❌ No ray_results directory found"
        return 1
    fi
    
    experiments=($(find "$STORAGE_PATH" -maxdepth 1 -type d -name "tune_*" | sort -t/ -k2))
    
    if [[ ${#experiments[@]} -eq 0 ]]; then
        echo "❌ No experiments found in $STORAGE_PATH"
        return 1
    fi
    
    for i in "${!experiments[@]}"; do
        exp_path="${experiments[$i]}"
        exp_name=$(basename "$exp_path")
        
        # Get experiment info
        created=$(stat -f "%Sm" -t "%Y-%m-%d %H:%M" "$exp_path" 2>/dev/null || stat -c "%y" "$exp_path" | cut -d' ' -f1,2 | cut -d'.' -f1)
        
        # Check if experiment has trials
        trial_count=$(find "$exp_path" -name "trial_*" -type d | wc -l)
        
        # Check for checkpoint (incomplete experiment)
        has_checkpoint=""
        if [[ -f "$exp_path/tuner.pkl" ]]; then
            has_checkpoint=" (resumable)"
        fi
        
        echo "[$((i+1))] $exp_name"
        echo "    Created: $created"
        echo "    Trials: $trial_count$has_checkpoint"
        echo ""
    done
}

resume_experiment() {
    local exp_number="$1"
    
    if [[ -z "$exp_number" ]]; then
        echo "Usage: $0 resume <experiment_number>"
        return 1
    fi
    
    experiments=($(find "$STORAGE_PATH" -maxdepth 1 -type d -name "tune_*" | sort -t/ -k2))
    
    if [[ "$exp_number" -lt 1 || "$exp_number" -gt ${#experiments[@]} ]]; then
        echo "❌ Invalid experiment number. Use 'list' to see available experiments."
        return 1
    fi
    
    exp_path="${experiments[$((exp_number-1))]}"
    exp_name=$(basename "$exp_path")
    
    echo "🔄 Resuming experiment: $exp_name"
    echo "📁 Path: $exp_path"
    echo ""
    
    # Simple resume command
    echo "Run this command to resume:"
    echo "python train_tune.py --restore_path '$exp_path'"
}

case "$1" in
    "list")
        list_experiments
        ;;
    "resume")
        resume_experiment "$2"
        ;;
    *)
        echo "Ray Tune Experiment Manager"
        echo "=========================="
        echo "Usage: $0 {list|resume}"
        echo ""
        echo "Commands:"
        echo "  list              - List all available experiments"
        echo "  resume <number>   - Show command to resume experiment"
        echo ""
        echo "Examples:"
        echo "  $0 list"
        echo "  $0 resume 3"
        echo ""
        echo "Ray Tune Fault Tolerance:"
        echo "✅ Experiments auto-save checkpoints"
        echo "✅ Use --restore_path to resume from any checkpoint"
        echo "✅ Ray handles crashed trials automatically"
        ;;
esac
