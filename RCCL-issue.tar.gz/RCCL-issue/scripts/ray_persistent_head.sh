#!/bin/bash
#SBATCH -p cpu20  # Use CPU partition for head node
#SBATCH -t 7-00:00:00  # 7 days (adjust as needed)
#SBATCH -o /home/rmaser/Master-Thesis_Improved-Interpretability-and-Concepts/slurm/ray-head-%A.out
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=1
#SBATCH --cpus-per-task=4  # Minimal CPU for head
#SBATCH --mem=16GB  # Moderate memory for head
#SBATCH --job-name=ray-head

# Persistent Ray Head Node
# This runs continuously and manages the Ray cluster

head_node=$(hostname)
head_node_ip=$(hostname --ip-address)

# Clean up IP if needed
if [[ "$head_node_ip" == *" "* ]]; then
    IFS=' ' read -ra ADDR <<<"$head_node_ip"
    if [[ ${#ADDR[0]} -gt 16 ]]; then
        head_node_ip=${ADDR[1]}
    else
        head_node_ip=${ADDR[0]}
    fi
fi

port=6379
dashboard_port=8265

echo "=== Ray Persistent Head Node ==="
echo "SLURM_JOB_ID: $SLURM_JOB_ID"
echo "Head node: $head_node"
echo "Head node IP: $head_node_ip"
echo "Ray port: $port"
echo "Ray Dashboard: http://$head_node_ip:$dashboard_port"
echo "================================="

# Create a file with cluster info for other jobs to read
cluster_info_file="$HOME/ray_cluster_${USER}.info"
echo "RAY_ADDRESS=${head_node_ip}:${port}" > "$cluster_info_file"
echo "RAY_HEAD_IP=${head_node_ip}" >> "$cluster_info_file"
echo "RAY_HEAD_PORT=${port}" >> "$cluster_info_file"
echo "RAY_DASHBOARD=http://${head_node_ip}:${dashboard_port}" >> "$cluster_info_file"

echo "Cluster info written to: $cluster_info_file"
cat "$cluster_info_file"

# Start Ray head node (this will block)
echo "Starting Ray head node..."
pixi run ray start --head \
    --node-ip-address="$head_node_ip" \
    --port=$port \
    --dashboard-host='0.0.0.0' \
    --dashboard-port=$dashboard_port \
    --num-cpus=$SLURM_CPUS_PER_TASK \
    --block

echo "Ray head node stopped."
