#!/bin/bash
#SBATCH -p cpu
#SBATCH -t 7-00:00:00  # 7 days
#SBATCH -o /home/rmaser/Master-Thesis_Improved-Interpretability-and-Concepts/slurm/ray-head-recovery-%A.out
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=1
#SBATCH --cpus-per-task=4
#SBATCH --mem=16GB
#SBATCH --job-name=ray-head-recovery

# Enhanced Ray Head with Recovery Support

head_node=$(hostname)
head_node_ip=$(hostname --ip-address)

# Clean up IP if needed
if [[ "$head_node_ip" == *" "* ]]; then
    IFS=' ' read -ra ADDR <<<"$head_node_ip"
    if [[ ${#ADDR[0]} -gt 16 ]]; then
        head_node_ip=${ADDR[1]}
    else
        head_node_ip=${ADDR[0]}
    fi
fi

port=6379
dashboard_port=8265

echo "=== Ray Head Node with Recovery ==="
echo "SLURM_JOB_ID: $SLURM_JOB_ID"
echo "Head node: $head_node"
echo "Head node IP: $head_node_ip"
echo "Ray port: $port"
echo "Ray Dashboard: http://$head_node_ip:$dashboard_port"
echo "=================================="

# Create cluster info file
cluster_info_file="$HOME/ray_cluster_${USER}.info"
echo "RAY_ADDRESS=${head_node_ip}:${port}" > "$cluster_info_file"
echo "RAY_HEAD_IP=${head_node_ip}" >> "$cluster_info_file"
echo "RAY_HEAD_PORT=${port}" >> "$cluster_info_file"
echo "RAY_DASHBOARD=http://${head_node_ip}:${dashboard_port}" >> "$cluster_info_file"
echo "RAY_HEAD_JOB_ID=${SLURM_JOB_ID}" >> "$cluster_info_file"
echo "RAY_HEAD_START_TIME=$(date)" >> "$cluster_info_file"

# Check for previous experiment state
echo "🔍 Checking for resumable experiments..."
if [[ -d "ray_results" ]]; then
    echo "📂 Found existing ray_results directory"
    echo "🔄 Experiments can be resumed with --resume flag"
    
    # List resumable experiments
    echo "📋 Resumable experiments:"
    for exp_dir in ray_results/tune_*; do
        if [[ -d "$exp_dir" ]]; then
            exp_name=$(basename "$exp_dir" | sed 's/tune_//')
            trial_count=$(find "$exp_dir" -name "trial_*" -type d 2>/dev/null | wc -l)
            echo "  - $exp_name ($trial_count trials found)"
        fi
    done
else
    echo "🆕 No previous experiments found - starting fresh"
fi

echo ""
echo "Cluster info written to: $cluster_info_file"
cat "$cluster_info_file"

# Enhanced Ray head startup with recovery support
echo "Starting Ray head node with recovery support..."
pixi run ray start --head \
    --node-ip-address="$head_node_ip" \
    --port=$port \
    --dashboard-host='0.0.0.0' \
    --dashboard-port=$dashboard_port \
    --num-cpus=$SLURM_CPUS_PER_TASK \
    --temp-dir="/tmp/ray_head_${SLURM_JOB_ID}" \
    --block

echo "Ray head node stopped."
