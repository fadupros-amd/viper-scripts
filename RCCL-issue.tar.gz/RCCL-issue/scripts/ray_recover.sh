#!/bin/bash
# Ray Head Recovery Script
# Automatically restarts head and reconnects workers after crash

CLUSTER_INFO_FILE="/tmp/ray_cluster_${USER}.info"
WORKER_POOLS_FILE="/tmp/ray_worker_pools_${USER}.list"

echo "🔄 Ray Head Recovery"
echo "==================="

# Check if there was a previous cluster
if [[ -f "$CLUSTER_INFO_FILE" ]]; then
    echo "📂 Found previous cluster info"
    source "$CLUSTER_INFO_FILE"
    echo "Previous cluster was at: $RAY_ADDRESS"
    
    # Test if it's still alive
    if pixi run ray status --address="$RAY_ADDRESS" 2>/dev/null; then
        echo "✅ Cluster is still alive! No recovery needed."
        exit 0
    else
        echo "💀 Cluster is dead, starting recovery..."
    fi
else
    echo "❌ No previous cluster info found"
    echo "Use: sbatch scripts/ray_persistent_head.sh"
    exit 1
fi

# Start new head node
echo ""
echo "🚀 Starting new Ray head node..."
HEAD_JOB_ID=$(sbatch --parsable scripts/ray_persistent_head.sh)
echo "New head job ID: $HEAD_JOB_ID"

# Wait for head to start
echo "⏳ Waiting for head node to initialize..."
for i in {1..30}; do
    if [[ -f "$CLUSTER_INFO_FILE" ]]; then
        source "$CLUSTER_INFO_FILE"
        if pixi run ray status --address="$RAY_ADDRESS" 2>/dev/null; then
            echo "✅ Head node is ready!"
            break
        fi
    fi
    echo "   Waiting... ($i/30)"
    sleep 2
done

if ! pixi run ray status --address="$RAY_ADDRESS" 2>/dev/null; then
    echo "❌ Head node failed to start properly"
    exit 1
fi

# Check for existing worker pools
if [[ -f "$WORKER_POOLS_FILE" ]]; then
    echo ""
    echo "🔧 Found existing worker pools, checking status..."
    
    while read -r pool_name; do
        if [[ -n "$pool_name" ]]; then
            # Check if worker job is still running
            job_id=$(echo "$pool_name" | grep -o '[0-9]\+$')
            if squeue -j "$job_id" &>/dev/null; then
                echo "✅ Worker pool $pool_name is still running"
                echo "   Workers should auto-reconnect to new head"
            else
                echo "💀 Worker pool $pool_name has stopped"
                # Remove from list
                sed -i "/$pool_name/d" "$WORKER_POOLS_FILE"
            fi
        fi
    done < "$WORKER_POOLS_FILE"
    
    echo ""
    echo "⏳ Waiting for workers to reconnect..."
    sleep 15
    
    echo "📊 Current cluster status:"
    pixi run ray status --address="$RAY_ADDRESS"
    
else
    echo "⚠️  No worker pools found"
    echo "Add workers with:"
    echo "  ./scripts/ray_cluster.sh workers gpu"
    echo "  ./scripts/ray_cluster.sh workers cpu"
fi

echo ""
echo "🎯 Recovery Summary"
echo "=================="
echo "✅ New head node: $RAY_ADDRESS"
echo "📊 Dashboard: $RAY_DASHBOARD" 
echo "🔧 Worker pools: Check status above"
echo ""
echo "🧪 To resume interrupted experiments:"
echo "   python train_tune.py --experiment_name YOUR_EXP_NAME --resume"
echo ""
echo "📈 Monitor with:"
echo "   ./scripts/ray_cluster.sh status"
