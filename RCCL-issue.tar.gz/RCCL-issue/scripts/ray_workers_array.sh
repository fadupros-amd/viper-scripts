#!/bin/bash

# Ray Worker Array Management Utility
# Provides easy management of SLURM array-based Ray workers

show_usage() {
    echo "Usage: $0 <command> [options]"
    echo ""
    echo "Commands:"
    echo "  start-gpu [N]     Start N GPU worker array tasks (default: 4)"
    echo "  start-cpu [N]     Start N CPU worker array tasks (default: 8)"
    echo "  stop-gpu          Stop all GPU array workers"
    echo "  stop-cpu          Stop all CPU array workers"
    echo "  stop-all          Stop all array workers"
    echo "  status            Show status of all array workers"
    echo "  scale-gpu N       Scale GPU workers to N tasks"
    echo "  scale-cpu N       Scale CPU workers to N tasks"
    echo ""
    echo "Examples:"
    echo "  $0 start-gpu 8        # Start 8 GPU workers"
    echo "  $0 start-cpu 16       # Start 16 CPU workers"
    echo "  $0 scale-gpu 12       # Scale to 12 GPU workers"
    echo "  $0 status             # Show current worker status"
    echo "  $0 stop-all           # Stop all workers"
}

get_array_jobs() {
    local job_name=$1
    squeue -u $USER --name="$job_name" --format="%A %t %N" --noheader 2>/dev/null
}

start_gpu_workers() {
    local num_workers=${1:-4}
    echo "🚀 Starting $num_workers GPU worker array tasks..."
    
    # Check if head node is running
    if [[ ! -f "$HOME/ray_cluster_${USER}.info" ]]; then
        echo "❌ ERROR: Ray cluster info file not found"
        echo "Please start the persistent Ray head first:"
        echo "  sbatch scripts/ray_persistent_head.sh"
        exit 1
    fi
    
    # Submit array job
    job_id=$(sbatch --array=1-${num_workers} scripts/ray_workers_gpu_array.sh | awk '{print $4}')
    echo "✅ Submitted GPU worker array: Job ID $job_id (tasks 1-$num_workers)"
    echo "📊 Monitor with: squeue -u $USER -j $job_id"
}

start_cpu_workers() {
    local num_workers=${1:-8}
    echo "🚀 Starting $num_workers CPU worker array tasks..."
    
    # Check if head node is running
    if [[ ! -f "$HOME/ray_cluster_${USER}.info" ]]; then
        echo "❌ ERROR: Ray cluster info file not found"
        echo "Please start the persistent Ray head first:"
        echo "  sbatch scripts/ray_persistent_head.sh"
        exit 1
    fi
    
    # Submit array job
    job_id=$(sbatch --array=1-${num_workers} scripts/ray_workers_cpu_array.sh | awk '{print $4}')
    echo "✅ Submitted CPU worker array: Job ID $job_id (tasks 1-$num_workers)"
    echo "📊 Monitor with: squeue -u $USER -j $job_id"
}

stop_gpu_workers() {
    echo "🛑 Stopping all GPU array workers..."
    local jobs=$(get_array_jobs "ray-workers-gpu-array")
    if [[ -n "$jobs" ]]; then
        echo "$jobs" | awk '{print $1}' | xargs -r scancel
        echo "✅ Cancelled GPU array workers"
    else
        echo "ℹ️  No GPU array workers found"
    fi
}

stop_cpu_workers() {
    echo "🛑 Stopping all CPU array workers..."
    local jobs=$(get_array_jobs "ray-workers-cpu-array")
    if [[ -n "$jobs" ]]; then
        echo "$jobs" | awk '{print $1}' | xargs -r scancel
        echo "✅ Cancelled CPU array workers"
    else
        echo "ℹ️  No CPU array workers found"
    fi
}

stop_all_workers() {
    echo "🛑 Stopping all array workers..."
    stop_gpu_workers
    stop_cpu_workers
    
    # Also stop non-array workers for completeness
    local other_jobs=$(squeue -u $USER --name="ray-workers-gpu,ray-workers-cpu" --format="%A" --noheader 2>/dev/null)
    if [[ -n "$other_jobs" ]]; then
        echo "$other_jobs" | xargs -r scancel
        echo "✅ Also cancelled non-array workers"
    fi
}

show_status() {
    echo "=== Ray Worker Array Status ==="
    echo ""
    
    # Check head node
    echo "🏢 Head Node:"
    local head_jobs=$(squeue -u $USER --name="ray-head,ray-head-recovery" --format="%A %t %N %S" --noheader 2>/dev/null)
    if [[ -n "$head_jobs" ]]; then
        echo "$head_jobs" | while read job state node start_time; do
            echo "  ✅ Job $job ($state) on $node since $start_time"
        done
    else
        echo "  ❌ No head node running"
    fi
    
    echo ""
    echo "🖥️  GPU Workers (Array):"
    local gpu_jobs=$(get_array_jobs "ray-workers-gpu-array")
    if [[ -n "$gpu_jobs" ]]; then
        local gpu_count=$(echo "$gpu_jobs" | wc -l)
        echo "  📊 $gpu_count array tasks:"
        echo "$gpu_jobs" | while read job state node; do
            echo "    - Job $job ($state) on $node"
        done
    else
        echo "  ❌ No GPU array workers running"
    fi
    
    echo ""
    echo "🔧 CPU Workers (Array):"
    local cpu_jobs=$(get_array_jobs "ray-workers-cpu-array")
    if [[ -n "$cpu_jobs" ]]; then
        local cpu_count=$(echo "$cpu_jobs" | wc -l)
        echo "  📊 $cpu_count array tasks:"
        echo "$cpu_jobs" | while read job state node; do
            echo "    - Job $job ($state) on $node"
        done
    else
        echo "  ❌ No CPU array workers running"
    fi
    
    echo ""
    echo "🔍 Ray Cluster Status:"
    if [[ -f "$HOME/ray_cluster_${USER}.info" ]]; then
        echo "  ✅ Cluster info available:"
        cat "$HOME/ray_cluster_${USER}.info" | sed 's/^/    /'
    else
        echo "  ❌ No cluster info found"
    fi
}

scale_gpu_workers() {
    local target_workers=$1
    if [[ -z "$target_workers" ]] || [[ ! "$target_workers" =~ ^[0-9]+$ ]]; then
        echo "❌ ERROR: Please specify number of workers (e.g., scale-gpu 8)"
        exit 1
    fi
    
    echo "🔄 Scaling GPU workers to $target_workers tasks..."
    
    # Stop existing GPU workers
    stop_gpu_workers
    
    # Wait a moment for cleanup
    sleep 2
    
    # Start new workers if target > 0
    if [[ $target_workers -gt 0 ]]; then
        start_gpu_workers $target_workers
    else
        echo "✅ Scaled to 0 GPU workers (all stopped)"
    fi
}

scale_cpu_workers() {
    local target_workers=$1
    if [[ -z "$target_workers" ]] || [[ ! "$target_workers" =~ ^[0-9]+$ ]]; then
        echo "❌ ERROR: Please specify number of workers (e.g., scale-cpu 16)"
        exit 1
    fi
    
    echo "🔄 Scaling CPU workers to $target_workers tasks..."
    
    # Stop existing CPU workers
    stop_cpu_workers
    
    # Wait a moment for cleanup
    sleep 2
    
    # Start new workers if target > 0
    if [[ $target_workers -gt 0 ]]; then
        start_cpu_workers $target_workers
    else
        echo "✅ Scaled to 0 CPU workers (all stopped)"
    fi
}

# Main command handling
case "${1:-}" in
    "start-gpu")
        start_gpu_workers $2
        ;;
    "start-cpu")
        start_cpu_workers $2
        ;;
    "stop-gpu")
        stop_gpu_workers
        ;;
    "stop-cpu")
        stop_cpu_workers
        ;;
    "stop-all")
        stop_all_workers
        ;;
    "status")
        show_status
        ;;
    "scale-gpu")
        scale_gpu_workers $2
        ;;
    "scale-cpu")
        scale_cpu_workers $2
        ;;
    "--help"|"-h"|"help")
        show_usage
        ;;
    *)
        echo "❌ ERROR: Unknown command '${1:-}'"
        echo ""
        show_usage
        exit 1
        ;;
esac
