#!/bin/bash
#SBATCH -p cpu  # CPU p# Create worker info file for monitoring  
worker_info_file="$HOME/ray_workers_cpu_${SLURM_JOB_ID}.info"tition for CPU-only workers
#SBATCH -t 4:00:00
#SBATCH -o /home/rmaser/Master-Thesis_Improved-Interpretability-and-Concepts/slurm/workers-cpu-%A.out
#SBATCH --job-name=ray-workers-cpu

### Allocate CPU-only workers (for data processing, etc.)
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=1
#SBATCH -c 16  # More CPUs for CPU-intensive tasks
#SBATCH --mem 64000

# Pure CPU worker allocation

# Read cluster info from persistent head
cluster_info_file="$HOME/ray_cluster_${USER}.info"

if [[ ! -f "$cluster_info_file" ]]; then
    echo "❌ ERROR: Ray cluster info file not found: $cluster_info_file"
    echo "Please start the persistent Ray head first:"
    echo "  sbatch scripts/ray_persistent_head.sh"
    exit 1
fi

# Load cluster connection info  
source "$cluster_info_file"

echo "=== Ray CPU Worker Pool ==="
echo "SLURM_JOB_ID: $SLURM_JOB_ID"
echo "SLURM_JOB_NUM_NODES: $SLURM_JOB_NUM_NODES"
echo "Ray head address: $RAY_ADDRESS"
echo "Worker pool type: CPU ($SLURM_CPUS_PER_TASK cores)"
echo "Worker lifetime: Until job expires or manually cancelled"
echo "============================"

# Create worker info file for monitoring
worker_info_file="/tmp/ray_workers_cpu_${SLURM_JOB_ID}.info"
echo "WORKER_JOB_ID=$SLURM_JOB_ID" > "$worker_info_file"
echo "WORKER_TYPE=CPU" >> "$worker_info_file"
echo "WORKER_NODES=$SLURM_JOB_NUM_NODES" >> "$worker_info_file"
echo "WORKER_GPUS=0" >> "$worker_info_file"
echo "WORKER_CPUS=$((SLURM_JOB_NUM_NODES * SLURM_CPUS_PER_TASK))" >> "$worker_info_file"
echo "WORKER_START_TIME=$(date)" >> "$worker_info_file"

# Register worker pool with head node
echo "ray-workers-cpu-$SLURM_JOB_ID" >> "$HOME/ray_worker_pools_${USER}.list"

# Start CPU workers (BLOCKING)
echo "STARTING $SLURM_JOB_NUM_NODES CPU WORKERS"
srun --nodes=$SLURM_JOB_NUM_NODES --ntasks-per-node=1 bash -c "
    echo 'Ray CPU worker starting on \$(hostname)'
    pixi run ray start \
        --address='$RAY_HEAD_IP:$RAY_HEAD_PORT' \
        --num-cpus=$SLURM_CPUS_PER_TASK \
        --num-gpus=0 \
        --block
"

# Cleanup when job ends
echo "CPU worker pool $SLURM_JOB_ID shutting down..."
rm -f "$worker_info_file"
sed -i "/ray-workers-cpu-$SLURM_JOB_ID/d" "$HOME/ray_worker_pools_${USER}.list" 2>/dev/null || true

echo "CPU workers disconnected from cluster"
