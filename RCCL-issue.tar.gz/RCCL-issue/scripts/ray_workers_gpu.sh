#!/bin/bash
#SBATCH -p gpu22
#SBATCH -t 4:00:00  # Worker pool lifetime
#SBATCH -o /home/rmaser/Master-Thesis_Improved-Interpretability-and-Concepts/slurm/workers-gpu-%A.out
#SBATCH --job-name=ray-workers-gpu

### Allocate GPU workers (independent of experiments)
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=1  
#SBATCH --gres gpu:1
#SBATCH --gpus-per-task=1
#SBATCH -c 8
#SBATCH --mem 200000

# Pure worker allocation - no experiment code

# Read cluster info from persistent head
cluster_info_file="$HOME/ray_cluster_${USER}.info"

if [[ ! -f "$cluster_info_file" ]]; then
    echo "❌ ERROR: Ray cluster info file not found: $cluster_info_file"
    echo "Please start the persistent Ray head first:"
    echo "  sbatch scripts/ray_persistent_head.sh"
    exit 1
fi

# Load cluster connection info
source "$cluster_info_file"

echo "=== Ray GPU Worker Pool ==="
echo "SLURM_JOB_ID: $SLURM_JOB_ID"
echo "SLURM_JOB_NUM_NODES: $SLURM_JOB_NUM_NODES"
echo "Ray head address: $RAY_ADDRESS"
echo "Worker pool type: GPU ($SLURM_JOB_NUM_NODES nodes)"
echo "Worker lifetime: Until job expires or manually cancelled"
echo "============================="

# Create worker info file for monitoring
worker_info_file="$HOME/ray_workers_gpu_${SLURM_JOB_ID}.info"
echo "WORKER_JOB_ID=$SLURM_JOB_ID" > "$worker_info_file"
echo "WORKER_TYPE=GPU" >> "$worker_info_file"
echo "WORKER_NODES=$SLURM_JOB_NUM_NODES" >> "$worker_info_file"
echo "WORKER_GPUS=$((SLURM_JOB_NUM_NODES * 1))" >> "$worker_info_file"
echo "WORKER_CPUS=$((SLURM_JOB_NUM_NODES * SLURM_CPUS_PER_TASK))" >> "$worker_info_file"
echo "WORKER_START_TIME=$(date)" >> "$worker_info_file"

# Register worker pool with head node
echo "ray-workers-gpu-$SLURM_JOB_ID" >> "$HOME/ray_worker_pools_${USER}.list"

# Start GPU workers on all nodes (BLOCKING - they run until job ends)
echo "STARTING $SLURM_JOB_NUM_NODES GPU WORKERS"
srun --nodes=$SLURM_JOB_NUM_NODES --ntasks-per-node=1 bash -c "
    echo 'Ray GPU worker starting on \$(hostname)'
    pixi run ray start \
        --address='$RAY_HEAD_IP:$RAY_HEAD_PORT' \
        --num-cpus=$SLURM_CPUS_PER_TASK \
        --num-gpus=$SLURM_GPUS_PER_TASK \
        --block
"

# Cleanup when job ends
echo "GPU worker pool $SLURM_JOB_ID shutting down..."
rm -f "$worker_info_file"
sed -i "/ray-workers-gpu-$SLURM_JOB_ID/d" "$HOME/ray_worker_pools_${USER}.list" 2>/dev/null || true

echo "GPU workers disconnected from cluster"
