#!/bin/bash
#SBATCH -p gpu22
#SBATCH -t 4:00:00  # Worker pool lifetime
#SBATCH -o /home/rmaser/Master-Thesis_Improved-Interpretability-and-Concepts/slurm/workers-gpu-array-%A_%a.out
#SBATCH --job-name=ray-workers-gpu-array

### GPU Worker Array - Decoupled Resource Pool
#SBATCH --array=1-4  # Default to 4 GPU workers (adjust as needed)
#SBATCH --ntasks=1
#SBATCH --gres gpu:1
#SBATCH --gpus-per-task=1
#SBATCH -c 8
#SBATCH --mem 200000

# Array-based GPU worker allocation - Ray can stop/start as needed

# Read cluster info from persistent head
cluster_info_file="$HOME/ray_cluster_${USER}.info"

if [[ ! -f "$cluster_info_file" ]]; then
    echo "❌ ERROR: Ray cluster info file not found: $cluster_info_file"
    echo "Please start the persistent Ray head first:"
    echo "  sbatch scripts/ray_persistent_head.sh"
    exit 1
fi

# Load cluster connection info
source "$cluster_info_file"

echo "=== Ray GPU Worker Array (Task $SLURM_ARRAY_TASK_ID) ==="
echo "SLURM_JOB_ID: $SLURM_JOB_ID"
echo "SLURM_ARRAY_JOB_ID: $SLURM_ARRAY_JOB_ID"
echo "SLURM_ARRAY_TASK_ID: $SLURM_ARRAY_TASK_ID"
echo "Ray head address: $RAY_ADDRESS"
echo "Worker type: GPU (array task)"
echo "Worker lifetime: Until job expires or Ray stops it"
echo "====================================================="

# Create unique worker info file for this array task
worker_info_file="$HOME/ray_workers_gpu_array_${SLURM_ARRAY_JOB_ID}_${SLURM_ARRAY_TASK_ID}.info"
echo "WORKER_JOB_ID=$SLURM_JOB_ID" > "$worker_info_file"
echo "WORKER_ARRAY_JOB_ID=$SLURM_ARRAY_JOB_ID" >> "$worker_info_file"
echo "WORKER_ARRAY_TASK_ID=$SLURM_ARRAY_TASK_ID" >> "$worker_info_file"
echo "WORKER_TYPE=GPU_ARRAY" >> "$worker_info_file"
echo "WORKER_GPUS=1" >> "$worker_info_file"
echo "WORKER_CPUS=$SLURM_CPUS_PER_TASK" >> "$worker_info_file"
echo "WORKER_START_TIME=$(date)" >> "$worker_info_file"
echo "WORKER_NODE=$(hostname)" >> "$worker_info_file"

# Register this array worker with head node
echo "ray-workers-gpu-array-$SLURM_ARRAY_JOB_ID-$SLURM_ARRAY_TASK_ID" >> "$HOME/ray_worker_pools_${USER}.list"

echo "STARTING GPU WORKER ARRAY TASK $SLURM_ARRAY_TASK_ID on $(hostname)"

# Start GPU worker (BLOCKING - runs until job ends or Ray stops it)
pixi run ray start \
    --address="$RAY_HEAD_IP:$RAY_HEAD_PORT" \
    --num-cpus=$SLURM_CPUS_PER_TASK \
    --num-gpus=$SLURM_GPUS_PER_TASK \
    --block

# Cleanup when worker stops
echo "GPU worker array task $SLURM_ARRAY_TASK_ID shutting down..."
rm -f "$worker_info_file"
sed -i "/ray-workers-gpu-array-$SLURM_ARRAY_JOB_ID-$SLURM_ARRAY_TASK_ID/d" "$HOME/ray_worker_pools_${USER}.list" 2>/dev/null || true

echo "GPU worker array task $SLURM_ARRAY_TASK_ID disconnected from cluster"
