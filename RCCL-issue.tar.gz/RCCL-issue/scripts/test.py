import os
# Set DATA_ROOT environment variable before importing modules that use it
os.environ["DATA_ROOT"] = "./.data"  # Store data in a .data directory
os.makedirs(os.environ["DATA_ROOT"], exist_ok=True)
from bcos.data.datamodules import CIFAR10DataModule
from models.utils import TestModule
import lightning as L
from lightning.pytorch.loggers.wandb import WandbLogger
from data.transforms import get_transforms

def main():
    temp_path = ".temp"
    os.makedirs(temp_path, exist_ok=True)
    config = {
        "batch_size": 1000,
        "num_workers": 8,
        "train_transform": get_transforms(),
        "test_transform": get_transforms(),
    }
    data_module = CIFAR10DataModule(config)
    lightning_module = TestModule()
    
    # TODO config
    logger = WandbLogger(
        log_model="latest",
        name="test",
        save_dir=os.path.join(temp_path, "wandb"),
        project="Improved-Interpretability-and-Concepts",
    )

    trainer = pl.Trainer(
        max_epochs=30,
        logger=logger,
        accelerator="auto",
        default_root_dir=os.path.join(temp_path, ".lightning"),
        limit_train_batches=1.0,
        callbacks=[],
    )

    trainer.fit(lightning_module, data_module)

if __name__ == "__main__":

    main()
