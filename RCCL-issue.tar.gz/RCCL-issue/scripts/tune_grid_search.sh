#!/bin/bash
#SBATCH -p gpu22
#SBATCH -t 12:00:00
#SBATCH -o /home/rmaser/Master-Thesis_Improved-Interpretability-and-Concepts/slurm/grid_search-%j.out
#SBATCH -c 120  # 4 GPUs * 30 cores
#SBATCH --gres gpu:4
#SBATCH --mem 400000

# Full Grid Search with Ray Tune
# Multiple parameters → automatic grid search across all combinations

echo "🔬 Running full grid search with Ray Tune"
echo "📊 Job ID: $SLURM_JOB_ID"
echo "🎯 GPUs: $CUDA_VISIBLE_DEVICES"

nvidia-smi

# Full grid search - multiple parameters create cartesian product
# 3 LRs × 3 optimizers × 2 weight decays = 18 trials
pixi run python train_tune.py \
    --experiment_name "optimizer_grid" \
    --lr "[1e-4,1e-3,1e-2]" \
    --optimizer "[adam,adamw,ranger21]" \
    --weight_decay "[1e-5,1e-4]" \
    --batch_size 32 \
    --max_epochs 20 \
    --num_gpus 4 \
    --search_mode grid \
    --scheduler asha \
    --group "grid_search"

echo "✅ Grid search completed"
