#!/bin/bash
#SBATCH -p gpu22
#SBATCH -t 8:00:00
#SBATCH -o /home/rmaser/Master-Thesis_Improved-Interpretability-and-Concepts/slurm/lr_search-%j.out
#SBATCH -c 120  # 4 GPUs * 30 cores
#SBATCH --gres gpu:4
#SBATCH --mem 400000

# Learning Rate Search with Ray Tune
# Same script, just provide multiple learning rates → automatic grid search

echo "🔍 Running learning rate search with Ray Tune"
echo "📊 Job ID: $SLURM_JOB_ID"  
echo "🎯 GPUs: $CUDA_VISIBLE_DEVICES"

nvidia-smi

# Learning rate search - just provide list of LRs
pixi run python train_tune.py \
    --experiment_name "lr_search_grid" \
    --lr "[1e-5,5e-5,1e-4,5e-4,1e-3,5e-3,1e-2,5e-2]" \
    --optimizer adamw \
    --weight_decay 0.0001 \
    --batch_size 32 \
    --max_epochs 20 \
    --num_gpus 4 \
    --search_mode grid \
    --group "lr_search"

echo "✅ Learning rate search completed"
