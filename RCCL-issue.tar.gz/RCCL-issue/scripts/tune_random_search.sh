#!/bin/bash
#SBATCH -p gpu22
#SBATCH -t 10:00:00
#SBATCH -o /home/rmaser/Master-Thesis_Improved-Interpretability-and-Concepts/slurm/random_search-%j.out
#SBATCH -c 120  # 4 GPUs * 30 cores
#SBATCH --gres gpu:4
#SBATCH --mem 400000

# Random Search with Ray Tune
# Use distributions instead of fixed values → intelligent random sampling

echo "🎲 Running random search with Ray Tune"
echo "📊 Job ID: $SLURM_JOB_ID"
echo "🎯 GPUs: $CUDA_VISIBLE_DEVICES"

nvidia-smi

# Random search with distributions
pixi run python train_tune.py \
    --experiment_name "random_search" \
    --lr "loguniform(1e-5,1e-1)" \
    --optimizer "[adam,adamw,sgd,ranger21]" \
    --weight_decay "loguniform(1e-6,1e-2)" \
    --batch_size "[16,32,64,128]" \
    --max_epochs 20 \
    --num_gpus 4 \
    --search_mode random \
    --num_samples 40 \
    --scheduler asha \
    --group "random_search"

echo "✅ Random search completed"
