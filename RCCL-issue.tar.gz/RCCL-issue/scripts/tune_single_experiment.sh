#!/bin/bash
#SBATCH -p gpu22
#SBATCH -t 2:00:00
#SBATCH -o /home/rmaser/Master-Thesis_Improved-Interpretability-and-Concepts/slurm/single_experiment-%j.out
#SBATCH -c 30
#SBATCH --gres gpu:1
#SBATCH --mem 100000

# Single Experiment with Ray Tune
# This uses Ray Tune but only runs 1 trial (no hyperparameter search)

echo "🎯 Running single experiment with Ray Tune"
echo "📊 Job ID: $SLURM_JOB_ID"
echo "🎯 GPU: $CUDA_VISIBLE_DEVICES"

nvidia-smi

# Single experiment - same script, just single values
pixi run python train_tune.py \
    --experiment_name "single_baseline" \
    --lr 0.001 \
    --optimizer adamw \
    --weight_decay 0.0001 \
    --batch_size 32 \
    --max_epochs 20 \
    --num_gpus 1 \
    --group "single_experiments"

echo "✅ Single experiment completed"
