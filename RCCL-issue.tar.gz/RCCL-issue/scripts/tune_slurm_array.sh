#!/bin/bash
#SBATCH --array=1-10
#SBATCH -p gpu22
#SBATCH -t 4:00:00
#SBATCH -o /home/rmaser/Master-Thesis_Improved-Interpretability-and-Concepts/slurm/array_tune-%A_%a.out
#SBATCH -c 30
#SBATCH --gres gpu:1
#SBATCH --mem 100000

# SLURM Array with Ray Tune
# Use SLURM arrays to dynamically allocate compute nodes
# Each array job runs a different experiment configuration

echo "🔄 SLURM Array job with Ray Tune"
echo "📊 Array job: $SLURM_ARRAY_TASK_ID"
echo "🎯 GPU: $CUDA_VISIBLE_DEVICES"

# Define different experiment configurations for each array task
case $SLURM_ARRAY_TASK_ID in
    1)
        EXPERIMENT="baseline_adamw"
        LR="0.001"
        OPTIMIZER="adamw"
        ;;
    2)
        EXPERIMENT="baseline_adam"  
        LR="0.001"
        OPTIMIZER="adam"
        ;;
    3)
        EXPERIMENT="baseline_sgd"
        LR="0.01"
        OPTIMIZER="sgd"
        ;;
    4)
        EXPERIMENT="lr_sweep_low"
        LR="[1e-5,5e-5,1e-4]"  # Small grid search within this job
        OPTIMIZER="adamw"
        ;;
    5)
        EXPERIMENT="lr_sweep_high"
        LR="[1e-3,5e-3,1e-2]"  # Small grid search within this job
        OPTIMIZER="adamw"
        ;;
    6)
        EXPERIMENT="batch_size_test"
        LR="0.001"
        BATCH_SIZE="[32,64,128]"
        OPTIMIZER="adamw"
        ;;
    7)
        EXPERIMENT="random_exploration"
        LR="loguniform(1e-5,1e-2)"
        OPTIMIZER="[adam,adamw]"
        ;;
    *)
        echo "Unknown array task ID: $SLURM_ARRAY_TASK_ID"
        exit 1
        ;;
esac

echo "🧪 Running experiment: $EXPERIMENT"

# Run the experiment (Ray Tune handles whether it's 1 trial or multiple)
pixi run python train_tune.py \
    --experiment_name "$EXPERIMENT" \
    --lr "$LR" \
    --optimizer "$OPTIMIZER" \
    ${BATCH_SIZE:+--batch_size "$BATCH_SIZE"} \
    --max_epochs 15 \
    --num_gpus 1 \
    --search_mode ${SEARCH_MODE:-grid} \
    ${NUM_SAMPLES:+--num_samples "$NUM_SAMPLES"} \
    --group "array_experiments" \
    --tags "slurm_array" "experiment_${SLURM_ARRAY_TASK_ID}"

echo "✅ Array task $SLURM_ARRAY_TASK_ID completed"
