#!/bin/bash
#SBATCH -p apu
#SBATCH -t 12:00:00
#SBATCH -o /u/rmaser/Master-Thesis_Improved-Interpretability-and-Concepts/slurm/slurm-%A_%a.out
#SBATCH --gres gpu:2
#SBATCH --array=2
# Lightning DDP configuration following official docs
#SBATCH --ntasks-per-node=2   # This needs to match Trainer(devices=...)
#SBATCH --nodes=4             # This needs to match Trainer(num_nodes=...)
#SBATCH --cpus-per-task=24
#SBATCH --exclusive

echo "SLURM_JOB_ID: $SLURM_JOB_ID"
echo "SLURM_ARRAY_TASK_ID: $SLURM_ARRAY_TASK_ID"

module load rocm/6.4

learning_rate=0.001
weight_decay=0.001
optimizer="ranger21"
# optimizer="adamw"
batch_size=128
epochs=90
num_workers=8

case $SLURM_ARRAY_TASK_ID in
    1)
        model="vit_b_16_B=2_pretrained"
        ;;
    2)
        model="vitc_b_16_B=2_pretrained"
        ;;
    3)
        model="vitc_b_16_B=2_pretrained_only-conv-stem"
        ;;
esac

srun pixi run train_viper --experiment_name "$model" --num_workers $num_workers --group "imagenet-baselines" --epochs 90  --dataset "imagenet1k" --replace_classifier_by_pretrained True --peft_config.lora_alpha $peft_config_alpha --weight_decay $weight_decay --lr $learning_rate --optimizer $optimizer --no-ray --batch_size $batch_size --use_gradient_checkpointing False --compile True
# srun --cpu-bind=cores --gpu-bind=single:1 pixi run train --experiment_name "$model" --num_workers $num_workers --group "imagenet-baselines" --epochs 90  --dataset "imagenet1k" --replace_classifier_by_pretrained False --peft_config.lora_alpha $peft_config_alpha --weight_decay $weight_decay --lr $learning_rate --optimizer $optimizer --no-ray --batch_size $batch_size --use_gradient_checkpointing True --compile_mode "default" --pin_memory False
#--cpu-bind=cores --gpu-bind=single:1 
# pixi run train --experiment_name $model --group "bottleneck_position_resnet" --enable_bottleneck_layers $enable_bottleneck_layers --num_workers 8
