#!/bin/bash
#SBATCH -p apu
#SBATCH -t 1:00:00
#SBATCH -o /u/rmaser/Master-Thesis_Improved-Interpretability-and-Concepts/slurm/slurm-%A.out
#SBATCH -c 10
#SBATCH --gres gpu:1
#SBATCH --mem 20000

curl -I --connect-timeout 30 --max-time 30 -v https://api.wandb.ai
curl -I --connect-timeout 30 --max-time 30 -v https://www.google.com