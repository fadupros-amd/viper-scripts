#!/bin/bash
#SBATCH -p apu
#SBATCH -t 1:00:00
#SBATCH -o /u/rmaser/Master-Thesis_Improved-Interpretability-and-Concepts/slurm/slurm-%A_%a.out
#SBATCH -c 48
#SBATCH --gres gpu:2
#SBATCH --array=1-1
#SBATCH --mem 220000
# Lightning DDP configuration following official docs
#SBATCH --ntasks-per-node=2   # This needs to match Trainer(devices=...)
#SBATCH --nodes=16            # This needs to match Trainer(num_nodes=...)
#SBATCH --cpus-per-task=24

# call your program here
# export DATA_ROOT="./.dataset"

echo "SLURM_JOB_ID: $SLURM_JOB_ID"
echo "SLURM_ARRAY_TASK_ID: $SLURM_ARRAY_TASK_ID"

module load rocm/6.4

model="vitc_b_16_B=2_pretrained_PEFT_lora_eva"
# group="vitc-peft-lora-eva-ranger21-lr"
group="test"

weight_decay=0.01
# optimizer="ranger21"
optimizer="adamw" 
peft_config_r=8
batch_size=128
epochs=100
num_workers=4

case $SLURM_ARRAY_TASK_ID in
# LoRA
    1)
        learning_rate=0.002
        ;;
    2)
        learning_rate=0.001
        ;;
    3)
        learning_rate=0.0005
        ;;
    4)
        learning_rate=0.0002
        ;;
    5)
        learning_rate=0.0001
        ;;
    6)
        learning_rate=0.005
        ;;
    7)
        learning_rate=0.01
        ;;
    8)
        learning_rate=0.02
        ;;
    9)
        learning_rate=0.05
        ;;
    10)
        learning_rate=0.1
esac

peft_config_alpha=$((peft_config_r * 2))

# Calculate num_workers as SLURM assigned CPUs minus 4 times the number of GPUs
# num_gpus=${SLURM_GPUS_PER_TASK:-1}
# num_workers_calc=$((SLURM_CPUS_PER_TASK - 4 * num_gpus))

# Use srun for proper multi-GPU DDP with automatic device assignment
# SLURM directives above configure: 2 tasks, 2 GPUs, 1 GPU per task
srun pixi run train_viper --experiment_name "$model" --num_workers $num_workers --peft_config.r $peft_config_r --peft_config.lora_alpha $peft_config_alpha --group $group --weight_decay $weight_decay --lr $learning_rate --optimizer $optimizer --no-ray --batch_size $batch_size --epochs $epochs --attention_mode "torch" --agc_clipping_value 1.0 --compile True --use_profiler False --compile_mode "default" --prefetch_factor 2 --accumulate_grad_batches 1 --precision "bf16-mixed" --use_gradient_checkpointing True #--grid_scale_confidence_threshold 0.2 # Adjust prefetch_factor as needed

# Alternative: Explicitly disable Ray (same as old behavior)
# pixi run train --experiment_name "$model" --num_workers 24 --peft_config.r $peft_config_r --peft_config.lora_alpha $peft_config_alpha --group $group --weight_decay $weight_decay --lr $learning_rate --optimizer $optimizer --no-ray

# Alternative: Use multi-worker Ray distributed training 
# pixi run train --experiment_name "$model" --num_workers 24 --peft_config.r $peft_config_r --peft_config.lora_alpha $peft_config_alpha --group $group --weight_decay $weight_decay --lr $learning_rate --optimizer $optimizer --ray_num_workers 2
