#!/bin/bash
#SBATCH -p apu
#SBATCH -t 8:00:00
#SBATCH -o /u/rmaser/Master-Thesis_Improved-Interpretability-and-Concepts/slurm/slurm-%A_%a.out
#SBATCH -c 48
#SBATCH --gres gpu:2
#SBATCH --array=6-10
#SBATCH --mem 220000

# call your program here
# export DATA_ROOT="./.dataset"


nvidia-smi
echo "SLURM_JOB_ID: $SLURM_JOB_ID"
echo "SLURM_ARRAY_TASK_ID: $SLURM_ARRAY_TASK_ID"

case $SLURM_ARRAY_TASK_ID in
    1|2|3|4|5)
        model="vitc_b_16_B=2_pretrained_PEFT_dora_eva"
        group="vitc-peft-dora-eva-ranger21-lr"
        ;;
    6|7|8|9|10)
        model="vitc_b_16_B=2_pretrained_PEFT_lora_eva"
        group="vitc-peft-lora-eva-ranger21-lr"
        ;;
esac

weight_decay=0.001
optimizer="ranger21"
peft_config_r=8
batch_size=128
epochs=50
num_workers=$SLURM_MEM_PER_NODE

case $SLURM_ARRAY_TASK_ID in
# LoRA
    1|6|11|16)
        learning_rate=0.002
        ;;
    2|7|12|17)
        learning_rate=0.001
        ;;
    3|8|13|18)
        learning_rate=0.0005
        ;;
    4|9|14|19)
        learning_rate=0.0002
        ;;
    5|10|15|20)
        learning_rate=0.0001
        ;;
esac

peft_config_alpha=$((peft_config_r * 2))

# Calculate num_workers as SLURM assigned CPUs minus 4 times the number of GPUs
num_gpus=${SLURM_GPUS_PER_TASK:-1}
num_workers_calc=$((SLURM_CPUS_PER_TASK - 4 * num_gpus))

# Your existing training command now uses Ray by default!
# To disable Ray and use the old Lightning training, add --no-ray
pixi run train_viper --experiment_name "$model" --num_workers $num_workers_calc --peft_config.r $peft_config_r --peft_config.lora_alpha $peft_config_alpha --group $group --weight_decay $weight_decay --lr $learning_rate --optimizer $optimizer --no-ray --batch_size $batch_size --epochs $epochs

# Alternative: Explicitly disable Ray (same as old behavior)
# pixi run train --experiment_name "$model" --num_workers 24 --peft_config.r $peft_config_r --peft_config.lora_alpha $peft_config_alpha --group $group --weight_decay $weight_decay --lr $learning_rate --optimizer $optimizer --no-ray

# Alternative: Use multi-worker Ray distributed training 
# pixi run train --experiment_name "$model" --num_workers 24 --peft_config.r $peft_config_r --peft_config.lora_alpha $peft_config_alpha --group $group --weight_decay $weight_decay --lr $learning_rate --optimizer $optimizer --ray_num_workers 2
