#!/bin/bash
#SBATCH -t 10:00:00
#SBATCH -o /u/rmaser/Master-Thesis_Improved-Interpretability-and-Concepts/slurm/slurm-%j.out
#SBATCH -c 24
#SBATCH --constraint="apu"
#SBATCH --gres=gpu:1
#SBATCH --mem=120000


# call your program here
# export DATA_ROOT="./.dataset"

module purge
module load gcc/14 openmpi/5.0 rocm/6.3

pixi run -e rocm train --experiment_name  "$1" --cache_data 0 --pin_memory 0 --num_workers 24 --precision 32-true
