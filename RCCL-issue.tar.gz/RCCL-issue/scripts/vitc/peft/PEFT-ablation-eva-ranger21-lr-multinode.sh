#!/bin/bash
#SBATCH -p gpu22
#SBATCH -t 0:10:00
#SBATCH -o /home/rmaser/Master-Thesis_Improved-Interpretability-and-Concepts/slurm/slurm-%A.out

### This script works for any number of nodes, Ray will find and manage all resources
#SBATCH --nodes=2

### Give all resources on each node to a single Ray task, ray can manage the resources internally
#SBATCH --ntasks-per-node=1
#SBATCH --gres gpu:1
#SBATCH --gpus-per-task=1
#SBATCH -c 8
#SBATCH --mem 200000

# Multinode Ray Tune version using the unified train_tune.py script
# This efficiently distributes hyperparameter search across multiple nodes

# Get head node information
head_node=$(hostname)
head_node_ip=$(hostname --ip-address)

# if we detect a space character in the head node IP, we'll
# convert it to an ipv4 address. This step is optional.
if [[ "$head_node_ip" == *" "* ]]; then
    IFS=' ' read -ra ADDR <<<"$head_node_ip"
    if [[ ${#ADDR[0]} -gt 16 ]]; then
        head_node_ip=${ADDR[1]}
    else
        head_node_ip=${ADDR[0]}
    fi
fi

# Use dynamic ports to avoid conflicts with other Ray clusters
# This allows multiple SLURM jobs to run Ray clusters simultaneously
port=$((6379 + SLURM_JOB_ID % 1000))  # Port range: 6379-7378
dashboard_port=$((8265 + SLURM_JOB_ID % 1000))  # Port range: 8265-9264

echo "=== Ray Multinode Setup ==="
echo "SLURM_JOB_ID: $SLURM_JOB_ID"
echo "SLURM_JOB_NUM_NODES: $SLURM_JOB_NUM_NODES"
echo "Head node: $head_node"
echo "Head node IP: $head_node_ip"
echo "Ray port: $port (dynamic based on job ID)"
echo "Ray Dashboard: http://$head_node_ip:$dashboard_port (dynamic based on job ID)"
echo "=========================="

echo "STARTING HEAD at $head_node"
srun --nodes=1 --ntasks=1 -w $head_node bash -c "
    echo 'Starting Ray head on \$(hostname)'
    pixi run ray start --head \
        --node-ip-address='$head_node_ip' \
        --port=$port \
        --dashboard-host='0.0.0.0' \
        --dashboard-port=$dashboard_port \
        --num-cpus=$SLURM_CPUS_PER_TASK \
        --num-gpus=$SLURM_GPUS_PER_TASK \
        --temp-dir='/tmp/ray_${SLURM_JOB_ID}' \
        --block
" &
sleep 5

worker_num=$(($SLURM_JOB_NUM_NODES - 1)) #number of nodes other than the head node
if [[ $worker_num -gt 0 ]]; then
    echo "STARTING $worker_num WORKERS"
    srun -n $worker_num --nodes=$worker_num --ntasks-per-node=1 --exclude $head_node bash -c "
        echo 'Starting Ray worker on \$(hostname)'
        pixi run ray start \
            --address='$head_node_ip:$port' \
            --num-cpus=$SLURM_CPUS_PER_TASK \
            --num-gpus=$SLURM_GPUS_PER_TASK \
            --block
    " &
    sleep 2
fi

# Show cluster status
echo "Ray cluster status:"
pixi run ray status --address="$head_node_ip:$port"

# Wait for cluster to be fully ready
echo "Waiting for Ray cluster to be fully ready..."
sleep 5

##############################################################################################
#### Ray Tune hyperparameter search

echo "Running Ray Tune hyperparameter search..."

# LORA experiment with multiple learning rates  
# You can add multiple models by using: --experiment_name '[vitc_b_16_B=2_pretrained_PEFT_lora_eva,vitc_b_16_B=2_pretrained_PEFT_dora_eva]'
export RAY_ADDRESS="$head_node_ip:$port"

# Force output to be displayed properly in SLURM multinode environment
export PYTHONUNBUFFERED=1  # Force Python to flush output immediately
export RAY_DISABLE_IMPORT_WARNING=1  # Reduce Ray import noise

# Ensure Ray Tune output comes to this terminal by running in foreground with proper output handling
echo "Starting Ray Tune with address: $RAY_ADDRESS"
echo "Python unbuffered output enabled for immediate display"
echo "=========================="

# Run Ray Tune and capture its output
pixi run tune \
    --experiment_name "vitc_b_16_B=2_pretrained_PEFT_lora_eva" \
    --group "vitc-peft-lora-eva-ranger21-lr-multinode" \
    --lr '[0.002,0.001,0.0005,0.0002,0.0001]' \
    --optimizer "ranger21" \
    --weight_decay 0.01 \
    --peft_config.r 8 \
    --peft_config.lora_alpha 16 \
    --gpus_per_trial 1.0 \
    --tags "multinode" 2>&1 | tee "/tmp/ray_tune_output_${SLURM_JOB_ID}.log"

echo "=========================="
echo "LORA experiment completed!"

# Show final cluster status
echo "Final Ray cluster status:"
pixi run ray status --address="$head_node_ip:$port"

# Cleanup
pixi run ray stop --address="$head_node_ip:$port"

echo "Ray multinode training completed for job $SLURM_JOB_ID"

# Usage:
# sbatch PEFT-ablation-eva-ranger21-lr-multinode.sh
#
# This will:
# 1. Set up a Ray cluster across multiple nodes using srun
# 2. Run LORA experiment with learning rate search
# 3. Test 5 different learning rates: [0.002, 0.001, 0.0005, 0.0002, 0.0001]
# 4. Use ASHA scheduler for early stopping  
# 5. Efficiently distribute trials across all available GPUs
#
# To test multiple models (LORA + DORA), change experiment_name to:
# --experiment_name '[vitc_b_16_B=2_pretrained_PEFT_lora_eva,vitc_b_16_B=2_pretrained_PEFT_dora_eva]'
