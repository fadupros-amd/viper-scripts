#!/bin/bash
#SBATCH -p gpu22
#SBATCH -t 2:00:00
#SBATCH -o /home/rmaser/Master-Thesis_Improved-Interpretability-and-Concepts/slurm/slurm-%A.out

### Connect to persistent Ray cluster and add GPU workers
#SBATCH --nodes=2
#SBATCH --ntasks-per-node=1
#SBATCH --gres gpu:1
#SBATCH --gpus-per-task=1
#SBATCH -c 8
#SBATCH --mem 200000

# Enhanced multinode training that connects to persistent Ray head

# Read cluster info from persistent head
cluster_info_file="/tmp/ray_cluster_${USER}.info"

if [[ ! -f "$cluster_info_file" ]]; then
    echo "❌ ERROR: Ray cluster info file not found: $cluster_info_file"
    echo "Please start the persistent Ray head first:"
    echo "  sbatch scripts/ray_persistent_head.sh"
    exit 1
fi

# Load cluster connection info
source "$cluster_info_file"

echo "=== Connecting to Persistent Ray Cluster ==="
echo "SLURM_JOB_ID: $SLURM_JOB_ID"
echo "SLURM_JOB_NUM_NODES: $SLURM_JOB_NUM_NODES"
echo "Ray head address: $RAY_ADDRESS"
echo "Dashboard: $RAY_DASHBOARD"
echo "============================================="

# Start GPU workers on all nodes
echo "STARTING $SLURM_JOB_NUM_NODES GPU WORKERS"
srun --nodes=$SLURM_JOB_NUM_NODES --ntasks-per-node=1 bash -c "
    echo 'Starting Ray worker on \$(hostname) connecting to $RAY_HEAD_IP:$RAY_HEAD_PORT'
    pixi run ray start \
        --address='$RAY_HEAD_IP:$RAY_HEAD_PORT' \
        --num-cpus=$SLURM_CPUS_PER_TASK \
        --num-gpus=$SLURM_GPUS_PER_TASK \
        --temp-dir='/tmp/ray_worker_${SLURM_JOB_ID}_\$(hostname)' \
        --block
" &

# Store worker PIDs for cleanup
WORKER_PIDS=$!

# Wait for workers to connect
echo "Waiting for workers to join cluster..."
sleep 15

# Show updated cluster status
echo "Updated Ray cluster status:"
pixi run ray status --address="$RAY_ADDRESS"

##############################################################################################
#### Ray Tune hyperparameter search

echo "Running Ray Tune hyperparameter search..."

# Force output to be displayed properly in SLURM multinode environment
export PYTHONUNBUFFERED=1
export RAY_DISABLE_IMPORT_WARNING=1

# Run Ray Tune (connecting to existing cluster)
echo "Starting Ray Tune with address: $RAY_ADDRESS"
echo "=========================="

pixi run tune \
    --experiment_name "vitc_b_16_B=2_pretrained_PEFT_lora_eva_persistent" \
    --group "vitc-peft-lora-eva-ranger21-lr-persistent" \
    --lr '[0.002,0.001,0.0005,0.0002,0.0001]' \
    --optimizer "ranger21" \
    --weight_decay 0.01 \
    --peft_config.r 8 \
    --peft_config.lora_alpha 16 \
    --gpus_per_trial 1.0 \
    --tags "persistent" "multinode" 2>&1 | tee "/tmp/ray_tune_output_${SLURM_JOB_ID}.log"

echo "=========================="
echo "Experiment completed!"

# Show final cluster status
echo "Final Ray cluster status:"
pixi run ray status --address="$RAY_ADDRESS"

# Graceful worker shutdown
echo "Shutting down workers gracefully..."
kill $WORKER_PIDS 2>/dev/null || true
sleep 5

echo "Ray workers stopped for job $SLURM_JOB_ID"
echo "Note: Persistent head node continues running"
echo "Workers will auto-disconnect from cluster"

# Usage:
# 1. First start persistent head: sbatch scripts/ray_persistent_head.sh  
# 2. Then submit worker jobs: sbatch this_script.sh
# 3. Multiple experiments can share the same persistent cluster
# 4. Workers auto-disconnect when job completes
