#!/bin/bash
#SBATCH -p gpu24
#SBATCH -t 8:00:00
#SBATCH -o /home/rmaser/Master-Thesis_Improved-Interpretability-and-Concepts/slurm/slurm-%A_%a.out
#SBATCH -c 30
#SBATCH --gres gpu:1
#SBATCH --array=1-10
#SBATCH --mem 200000

# Ray-enabled version of your PEFT ablation script
# This demonstrates how to integrate Ray while maintaining backwards compatibility

nvidia-smi
echo "SLURM_JOB_ID: $SLURM_JOB_ID"
echo "SLURM_ARRAY_TASK_ID: $SLURM_ARRAY_TASK_ID"

case $SLURM_ARRAY_TASK_ID in
    1|2|3|4|5)
        model="vitc_b_16_B=2_pretrained_PEFT_dora_eva"
        group="vitc-peft-dora-eva-ranger21-lr-ray"
        ;;
    6|7|8|9|10)
        model="vitc_b_16_B=2_pretrained_PEFT_lora_eva"
        group="vitc-peft-lora-eva-ranger21-lr-ray"
        ;;
esac

weight_decay=0.01
optimizer="ranger21"
peft_config_r=8

case $SLURM_ARRAY_TASK_ID in
    1|6)
        learning_rate=0.002
        ;;
    2|7)
        learning_rate=0.001
        ;;
    3|8)
        learning_rate=0.0005
        ;;
    4|9)
        learning_rate=0.0002
        ;;
    5|10)
        learning_rate=0.0001
        ;;
esac

peft_config_alpha=$((peft_config_r * 2))

# Choose training mode based on environment variable or default to standard
TRAINING_MODE=${TRAINING_MODE:-"standard"}

case $TRAINING_MODE in
    "standard")
        echo "Running standard Lightning training..."
        pixi run train --experiment_name "$model" --num_workers 24 \
            --peft_config.r $peft_config_r \
            --peft_config.lora_alpha $peft_config_alpha \
            --group $group \
            --weight_decay $weight_decay \
            --lr $learning_rate \
            --optimizer $optimizer
        ;;
    
    "ray")
        echo "Running Ray distributed training..."
        python train_ray.py --experiment_name "$model" \
            --ray_use_ray \
            --ray_num_workers 1 \
            --ray_use_gpu \
            --num_workers 24 \
            --peft_config.r $peft_config_r \
            --peft_config.lora_alpha $peft_config_alpha \
            --group $group \
            --weight_decay $weight_decay \
            --lr $learning_rate \
            --optimizer $optimizer
        ;;
    
    "tune")
        echo "Running Ray Tune hyperparameter optimization..."
        python train_ray.py --experiment_name "$model" \
            --tune_enable \
            --tune_num_samples 20 \
            --tune_max_epochs 30 \
            --tune_search_space_type lora \
            --group "${group}_tune" \
            --optimizer $optimizer
        ;;
    
    "tune_custom")
        echo "Running custom Ray Tune optimization..."
        python train_ray.py --experiment_name "$model" \
            --tune_enable \
            --tune_num_samples 15 \
            --tune_max_epochs 25 \
            --tune_param_lr "tune.loguniform(1e-5, 1e-2)" \
            --tune_param_weight_decay "tune.loguniform(1e-6, 1e-1)" \
            --tune_param_peft_config.r "tune.choice([8, 16, 32, 64])" \
            --tune_param_peft_config.lora_alpha "tune.choice([8, 16, 32, 64])" \
            --group "${group}_custom_tune" \
            --optimizer $optimizer
        ;;
esac

echo "Training completed for task $SLURM_ARRAY_TASK_ID with mode $TRAINING_MODE"

# Usage examples:
# 
# Standard training (backwards compatible):
# sbatch PEFT-ablation-eva-ranger21-lr-ray.sh
#
# Ray distributed training:
# TRAINING_MODE=ray sbatch PEFT-ablation-eva-ranger21-lr-ray.sh
#
# Hyperparameter optimization:
# TRAINING_MODE=tune sbatch PEFT-ablation-eva-ranger21-lr-ray.sh
#
# Custom hyperparameter optimization:
# TRAINING_MODE=tune_custom sbatch PEFT-ablation-eva-ranger21-lr-ray.sh
