#!/bin/bash
#SBATCH -p gpu24
#SBATCH -t 8:00:00
#SBATCH -o /home/rmaser/Master-Thesis_Improved-Interpretability-and-Concepts/slurm/slurm-%A.out
#SBATCH -c 30
#SBATCH --gres gpu:4
#SBATCH --mem 400000

# Ray Tune version using the unified train_tune.py script
# This uses Ray Tune for efficient hyperparameter optimization on a single node

nvidia-smi
echo "SLURM_JOB_ID: $SLURM_JOB_ID"

# Run both DORA and LORA experiments using unified Ray Tune
echo "Running unified Ray Tune hyperparameter search..."

# DORA experiment with comprehensive hyperparameter search
python train_tune.py \
    --experiment_name "vitc_b_16_B=2_pretrained_PEFT_dora_eva" \
    --group "vitc-peft-dora-eva-ranger21-tune" \
    --lr '[0.002,0.001,0.0005,0.0002,0.0001]' \
    --optimizer "ranger21" \
    --weight_decay '[0.01,0.001,0.0001]' \
    --peft_config.r '[8,16,32]' \
    --peft_config.lora_alpha '[8,16,32,64]' \
    --num_gpus 4 \
    --gpus_per_trial 1.0 \
    --scheduler "asha" \
    --search_mode "grid" \
    --tags "tune" "dora" "ranger21" &

dora_pid=$!

# LORA experiment with comprehensive hyperparameter search
python train_tune.py \
    --experiment_name "vitc_b_16_B=2_pretrained_PEFT_lora_eva" \
    --group "vitc-peft-lora-eva-ranger21-tune" \
    --lr '[0.002,0.001,0.0005,0.0002,0.0001]' \
    --optimizer "ranger21" \
    --weight_decay '[0.01,0.001,0.0001]' \
    --peft_config.r '[8,16,32]' \
    --peft_config.lora_alpha '[8,16,32,64]' \
    --num_gpus 4 \
    --gpus_per_trial 1.0 \
    --scheduler "asha" \
    --search_mode "grid" \
    --tags "tune" "lora" "ranger21" &

lora_pid=$!

# Wait for both experiments to complete
wait $dora_pid
wait $lora_pid

echo "All Ray Tune experiments completed!"

# Alternative: Random search version
# Uncomment below for random search instead of grid search
#
# python train_tune.py \
#     --experiment_name "vitc_b_16_B=2_pretrained_PEFT_dora_eva" \
#     --group "vitc-peft-dora-eva-ranger21-random" \
#     --lr "loguniform(1e-5,1e-2)" \
#     --optimizer "ranger21" \
#     --weight_decay "loguniform(1e-6,1e-1)" \
#     --peft_config.r "choice([8,16,32,64])" \
#     --peft_config.lora_alpha "choice([8,16,32,64])" \
#     --num_gpus 4 \
#     --gpus_per_trial 1.0 \
#     --scheduler "asha" \
#     --search_mode "random" \
#     --num_samples 50 \
#     --tags "random_tune" "dora" "ranger21"

# Usage:
# sbatch PEFT-ablation-eva-ranger21-lr-tune.sh
#
# This will:
# 1. Run DORA and LORA experiments in parallel
# 2. Test comprehensive hyperparameter combinations:
#    - 5 learning rates
#    - 3 weight decay values  
#    - 3 rank values
#    - 4 alpha values
#    = 180 combinations per experiment = 360 total trials
# 3. Use ASHA scheduler for early stopping of poor trials
# 4. Efficiently distribute trials across 4 GPUs
