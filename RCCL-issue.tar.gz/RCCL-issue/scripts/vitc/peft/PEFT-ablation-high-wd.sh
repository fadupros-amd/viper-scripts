#!/bin/bash
#SBATCH -p gpu24
#SBATCH -t 8:00:00
#SBATCH -o /home/rmaser/Master-Thesis_Improved-Interpretability-and-Concepts/slurm/slurm-%A_%a.out
#SBATCH -c 30
#SBATCH --gres gpu:1
#SBATCH --array=11-15
#SBATCH --mem 200000

# call your program here
# export DATA_ROOT="./.dataset"


nvidia-smi
echo "SLURM_JOB_ID: $SLURM_JOB_ID"
echo "SLURM_ARRAY_TASK_ID: $SLURM_ARRAY_TASK_ID"

case $SLURM_ARRAY_TASK_ID in
    1|2|3|4|5)
        model="vitc_b_16_B=2_pretrained_PEFT_randlora"
        group="vitc-peft-randlora-ranks"
        ;;
    6|7|8|9|10)
        model="vitc_b_16_B=2_pretrained_PEFT_dora"
        group="vitc-peft-dora-ranks"
        ;;
    11|12|13|14|15)
        model="vitc_b_16_B=2_pretrained_PEFT_lora"
        group="vitc-peft-lora-ranks"
        ;;
    16|17|18|19|20)
        model="vitc_b_16_B=2_pretrained_PEFT_shira"
        group="vitc-peft-shira-ranks"
        ;;
esac

weight_decay=0.1
learning_rate=0.001

case $SLURM_ARRAY_TASK_ID in
# LoRA
    1|6|11|16)
        peft_config_r=8
        ;;
    2|7|12|17)
        peft_config_r=16
        ;;
    3|8|13|18)
        peft_config_r=32
        ;;
    4|9|14|19)
        peft_config_r=64
        ;;
    5|10|15|20)
        peft_config_r=128
        ;;
esac

peft_config_alpha=$((peft_config_r * 2))


if (( 5 < ${SLURM_ARRAY_TASK_ID} && ${SLURM_ARRAY_TASK_ID} <= 15 )); then
    pixi run train --experiment_name "$model" --num_workers 24 --peft_config.r $peft_config_r --peft_config.lora_alpha $peft_config_alpha --group $group --weight_decay $weight_decay --lr $learning_rate
else
    pixi run train --experiment_name "$model" --num_workers 24 --peft_config.r $peft_config_r --group $group --weight_decay $weight_decay --lr $learning_rate
fi

