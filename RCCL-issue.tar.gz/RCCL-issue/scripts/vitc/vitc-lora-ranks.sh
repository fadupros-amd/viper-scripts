#!/bin/bash
#SBATCH -p gpu24
#SBATCH -t 8:00:00
#SBATCH -o /home/rmaser/Master-Thesis_Improved-Interpretability-and-Concepts/slurm/slurm-%A_%a.out
#SBATCH -c 30
#SBATCH --gres gpu:1
#SBATCH --array=1-6
#SBATCH --mem 200000

# call your program here
# export DATA_ROOT="./.dataset"


nvidia-smi
echo "SLURM_JOB_ID: $SLURM_JOB_ID"
echo "SLURM_ARRAY_TASK_ID: $SLURM_ARRAY_TASK_ID"
model="vitc_b_16_B=2_pretrained_lora_kaiming"

case $SLURM_ARRAY_TASK_ID in
    1)
        lora_rank=8
        ;;
    2)
        lora_rank=16
        ;;
    3)
        lora_rank=32
        ;;
    4)
        lora_rank=64
        ;;
    5)
        lora_rank=128
        ;;
    6)
        lora_rank=256
        ;;
esac


pixi run train --experiment_name $model --num_workers 24 --lora_rank $lora_rank --lora_alpha $lora_rank --group "vitc-lora-ranks" --weight_decay 0.01
# pixi run train --experiment_name $model --group "bottleneck_position_resnet" --enable_bottleneck_layers $enable_bottleneck_layers --num_workers 8
