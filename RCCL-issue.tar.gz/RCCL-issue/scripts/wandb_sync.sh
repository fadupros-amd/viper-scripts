#!/bin/bash

# Define the base directory for W&B runs
WANDB_BASE_DIR="./.cache/wandb/wandb"

# --- Build up the find command arguments ---
# We'll store arguments in an array for safety and clarity
# The find command will search in WANDB_BASE_DIR, not go deeper than 1 level,
# look for directories (-type d), and then apply a group of OR-ed conditions.
find_args=("$WANDB_BASE_DIR" "-maxdepth" "1" "-type" "d" "(")

# Patterns for May 13th, 2025 onwards

# May 13th - May 19th, 2025
# This is the FIRST pattern in the group, so it does NOT start with -o.
# The pattern "*-2025051[3-9]_*" covers directories from May 13th (20250513)
# through May 19th (20250519).
find_args+=("-name" "*-2025051[3-9]_*")

# May 20th - May 29th, 2025
# Subsequent patterns are OR-ed with the previous one.
# find_args+=("-o" "-name" "*-2025052[0-9]_*")

# May 30th - May 31st, 2025
# find_args+=("-o" "-name" "*-2025053[0-1]_*")

# June 2025 through September 2025 (months 06-09)
# '??' matches any two characters for the day.
# find_args+=("-o" "-name" "*-20250[6-9]??_*")

# October 2025 through December 2025 (months 10-12)
# find_args+=("-o" "-name" "*-20251[0-2]??_*")

# ---- Add patterns for future years if you anticipate needing them ----
# Example for all of 2026:
# find_args+=("-o" "-name" "*-2026????_*") # '????' matches any four characters (MMDD)

# Example for years 2027-2029:
# find_args+=("-o" "-name" "*-202[7-9]????_*")

# Close the OR group for the find command
find_args+=(")")

# --- Dry Run: See what directories would be found ---
echo "The following directories would be selected for syncing (created on or after May 13, 2025):"
# The find command is constructed from the find_args array.
# -print will print each found directory path.
find "${find_args[@]}" -print
echo ""
echo "If this looks correct, uncomment one of the sync command blocks below."

# --- Actual Sync Command Option 1: Efficiently sync multiple directories ---
# The '-exec wandb sync {} +' part will call 'wandb sync' and append all found
# directories to a single command (or a few commands if the list is very long).
# This is generally more efficient.
#
# echo "Attempting to sync multiple directories with -exec {} +"
find "${find_args[@]}" -exec wandb sync {} +

# --- Actual Sync Command Option 2: Sync one by one for detailed output ---
# This loop processes each found directory individually.
# -print0 and read -r -d $'\0' are used to handle filenames/paths with spaces or special characters safely.
#
# echo "Attempting to sync directories one by one..."
# find "${find_args[@]}" -print0 | while IFS= read -r -d $'\0' rundir; do
#   echo "-------------------------------------"
#   echo "--- Syncing $rundir ---"
#   wandb sync "$rundir"
#   echo "--- Finished syncing $rundir ---"
# done
# echo "-------------------------------------"
# echo "All selected directories processed."
