#!/usr/bin/env python3
"""
Test script to verify Ray Tune output visibility in multinode environments
"""

import os
import sys
import time
from pathlib import Path

# Add project root to Python path
project_root = Path(__file__).parent
sys.path.insert(0, str(project_root))

import ray
from ray import tune
from ray.tune import CLIReporter

def dummy_trainable(config):
    """Simple trainable that just sleeps and reports fake metrics."""
    # Suppress trainable output as intended
    sys.stdout = open(os.devnull, 'w')
    sys.stderr = open(os.devnull, 'w')
    
    for i in range(5):
        time.sleep(2)  # Simulate training
        # Report fake metrics to Ray Tune
        tune.report(
            val_accuracy=0.5 + config["lr"] * i * 0.1,
            val_loss=1.0 - config["lr"] * i * 0.05,
            epoch=i
        )

def main():
    print("🧪 Testing Ray Tune Output Visibility")
    print("=" * 50)
    
    # Check if connecting to existing Ray cluster
    ray_address = os.environ.get('RAY_ADDRESS', None)
    if ray_address and ray_address != 'local':
        print(f"🔗 Connecting to Ray cluster at: {ray_address}")
        ray.init(address=ray_address)
    else:
        print(f"🚀 Starting local Ray cluster")
        ray.init()
    
    # Configure reporter with enhanced visibility
    reporter = CLIReporter(
        metric_columns=["val_accuracy", "val_loss", "epoch"],
        parameter_columns=["lr"],
        print_intermediate_tables=True,
        max_progress_rows=10
    )
    
    # Simple grid search
    search_space = {
        "lr": tune.grid_search([0.001, 0.01, 0.1])
    }
    
    print(f"\n🎯 Starting test with 3 trials...")
    print(f"📊 Should see progress table below:")
    print("=" * 50)
    sys.stdout.flush()
    
    # Run tuning
    tuner = tune.Tuner(
        tune.with_resources(dummy_trainable, resources={"cpu": 1}),
        param_space=search_space,
        tune_config=tune.TuneConfig(num_samples=3),
        run_config=tune.RunConfig(
            name="test_output_visibility",
            progress_reporter=reporter,
            storage_path=str(Path.cwd() / "test_ray_results"),
        )
    )
    
    try:
        results = tuner.fit()
        
        print(f"\n" + "=" * 50)
        print(f"✅ Test completed successfully!")
        print(f"📊 {len(results)} trials completed")
        sys.stdout.flush()
        
    except Exception as e:
        print(f"❌ Test failed: {e}")
        sys.stdout.flush()
        raise e
    
    finally:
        ray.shutdown()

if __name__ == "__main__":
    main()
