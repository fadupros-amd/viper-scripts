import subprocess
import os, socket, sys

# Minimal startup diagnostics
print(f"[BOOT] host={socket.gethostname()} "
      f"SLURM_PROCID={os.getenv('SLURM_PROCID')} "
      f"SLURM_LOCALID={os.getenv('SLURM_LOCALID')} "
      f"LOCAL_RANK={os.getenv('LOCAL_RANK')} "
      f"HIP_VISIBLE_DEVICES={os.getenv('HIP_VISIBLE_DEVICES')} "
      f"ROCR_VISIBLE_DEVICES={os.getenv('ROCR_VISIBLE_DEVICES')}",
      flush=True)
print(f"[DEBUG] SLURM_STEP_GPUS={os.getenv('SLURM_STEP_GPUS')}")
print(f"[DEBUG] SLURM_GPUS_ON_NODE={os.getenv('SLURM_GPUS_ON_NODE')}")
print(f"[DEBUG] GPU_DEVICE_ORDINAL={os.getenv('GPU_DEVICE_ORDINAL')}")

# lr = os.environ.get("SLURM_LOCALID") or os.environ.get("LOCAL_RANK")
if "HIP_VISIBLE_DEVICES" not in os.environ and "ROCR_VISIBLE_DEVICES" in os.environ:
    # os.environ["HIP_VISIBLE_DEVICES"] = str(lr)
    os.environ["HIP_VISIBLE_DEVICES"] = os.environ["ROCR_VISIBLE_DEVICES"]
    # os.environ["ROCR_VISIBLE_DEVICES"] = str(lr)
    print(f"[Init] Copying ROCR_VISIBLE_DEVICES TO HIP_VISIBLE_DEVICES", flush=True)
else:
    print(f"[Init] Using existing HIP_VISIBLE_DEVICES={os.environ.get('HIP_VISIBLE_DEVICES')}", flush=True)


# Only set HIP/ROCR if not already provided by srun
local_id = os.environ.get("SLURM_LOCALID")
hip = os.environ.get("HIP_VISIBLE_DEVICES")
rocr = os.environ.get("ROCR_VISIBLE_DEVICES")

# If srun already masked per task (e.g., via --gpu-bind/--gpus-per-task), HIP may already be set.
# # Only set if HIP is missing and we have a valid local_id (0,1,...).
# if hip is None and local_id is not None and local_id.isdigit():
#     os.environ["HIP_VISIBLE_DEVICES"] = local_id
#     os.environ["ROCR_VISIBLE_DEVICES"] = local_id
#     print(f"[Init] Set HIP/ROCR to {local_id}", flush=True)
# else:
#     print(f"[Init] Using HIP={hip} ROCR={rocr}", flush=True)

import ast
from pathlib import Path
import wandb
from models.bcos_vit import Encoder

# Ensure project root is in sys.path for imports like 'data', 'models', 'experiment'
sys.path.append(str(Path(__file__).resolve().parent.parent))
# Set DATA_ROOT environment variable before importing modules that use it
os.environ["DATA_ROOT"] = "./.data"  # Store data in a .data directory
os.environ["TEMP_DIR"] = "./.cache"  # Store data in a .data directory
os.makedirs(os.environ["DATA_ROOT"], exist_ok=True)
os.makedirs(os.environ["TEMP_DIR"], exist_ok=True)

# SLURM DDP device assignment: Manually set visible devices for each process
# This must be done BEFORE importing torch or lightning
# local_rank = os.environ.get("SLURM_LOCALID") or os.environ.get("LOCAL_RANK")
# if local_rank is not None:
#     os.environ["HIP_VISIBLE_DEVICES"] = str(local_rank)
#     os.environ["ROCR_VISIBLE_DEVICES"] = str(local_rank)
#     print(f"[Init] Bound local rank {local_rank} to GPU {local_rank}")
    
# Fix Ray AMD GPU environment variable issue before importing Ray
# Ray expects HIP_VISIBLE_DEVICES instead of ROCR_VISIBLE_DEVICES for AMD GPUs
# if "ROCR_VISIBLE_DEVICES" in os.environ and "HIP_VISIBLE_DEVICES" not in os.environ:
#     os.environ["HIP_VISIBLE_DEVICES"] = os.environ["ROCR_VISIBLE_DEVICES"]
#     print(f"🔧 Ray AMD GPU fix: Set HIP_VISIBLE_DEVICES={os.environ['HIP_VISIBLE_DEVICES']}")

# Alternative: Disable Ray's GPU detection if causing issues
# Uncomment the next line if you want to disable GPU detection entirely for Ray
# os.environ["RAY_DISABLE_IMPORT_WARNING"] = "1"

# os.environ["CUDA_LAUNCH_BLOCKING"] = "1"

import warnings

warnings.filterwarnings(
    "once",  # The action: show only the first time.
    category=UserWarning,
    module=r"torch\.utils\._sympy\.interp"  # Target the exact module generating the warning.
)

import lightning.pytorch as L
from lightning.pytorch.loggers.wandb import WandbLogger
from lightning.pytorch.callbacks import ModelCheckpoint
from lightning.pytorch.profilers import PyTorchProfiler
from data.data_module import BcosDataModule
from experiment.experiment import Experiment
from models.lightning_module import BcosLightningModule
from ray_training.ray_trainer import RayLightningWrapper, RayTrainingConfig
import torch
from lightning.pytorch.strategies import FSDPStrategy
from torch.distributed.fsdp.wrap import ModuleWrapPolicy

print(f"[CUDA] CUDA is available: {torch.cuda.is_available()}")
print(f"[CUDA] Using CUDA devices: {torch.cuda.device_count()}")
if torch.cuda.is_available():
    cur = torch.cuda.current_device()
    print(f"[CUDA] current_device={cur} name={torch.cuda.get_device_name(cur)}")

print(f"[ID] using local id {os.environ.get('SLURM_LOCALID', None)} ")

try:
    pid = str(os.getpid())
    taskset = subprocess.check_output(["taskset", "-cp", pid]).decode().strip()
    print(f"[CPU] {taskset}", flush=True)
except Exception as e:
    print(f"[CPU] taskset query failed: {e}", flush=True)


# Configure torch.compile for better performance
torch._dynamo.config.cache_size_limit = 128  # Increase cache size
torch._dynamo.config.recompile_limit = 128    # Allow more recompilations per function
torch._dynamo.config.suppress_errors = True  # Suppress minor compilation errors

import argparse
from callbacks.timer import TimerCallback
# import thunder

def parse_unknown_args(unknown_args):
    """Parses unknown arguments into a dictionary, handling --key value and --key=value formats."""
    args_dict = {}
    i = 0
    while i < len(unknown_args):
        arg = unknown_args[i]
        if arg.startswith('--'):
            # Check for --key=value format
            if '=' in arg:
                parts = arg.split('=', 1)
                key = parts[0][2:] # Remove '--'
                value_str = parts[1]
                i += 1
            # Check for --key value format
            elif i + 1 < len(unknown_args) and not unknown_args[i+1].startswith('--'):
                key = arg[2:] # Remove '--'
                value_str = unknown_args[i+1]
                i += 2
            # Handle --key flag without value
            else:
                key = arg[2:] # Remove '--'
                value = True # Assume flag means True
                args_dict[key] = value
                i += 1
                continue # Move to next argument

            # Parse the value string
            try:
                # Attempt to convert to integer
                value = int(value_str)
            except ValueError:
                try:
                    # Attempt to convert to float
                    value = float(value_str)
                except ValueError:
                    # Attempt to evaluate as a Python literal (list, dict, tuple, bool, None, etc.)
                    # Only attempt if it looks like a literal start
                    if value_str.startswith('[') or value_str.startswith('{') or value_str.startswith('(') or value_str.lower() in ['true', 'false', 'none']:
                        try:
                            value = ast.literal_eval(value_str)
                        except (ValueError, SyntaxError):
                            # If literal evaluation fails, keep as string and warn
                            raise ValueError()
                            print(f"Warning: Could not evaluate '{value_str}' as a literal for key '{key}'. Keeping as string.")
                            value = value_str
                    else:
                        # Keep as string if conversion fails and doesn't look like a literal
                        value = value_str

            args_dict[key] = value
        else:
            # Handle positional unknown arguments if necessary, or ignore
            print(f"Warning: Ignoring unknown positional argument: {arg}")
            i += 1
    return args_dict


def main(experiment=None, use_ray=None):
    """Main training function that can be called directly or from command line.
    
    Args:
        experiment: Optional experiment object (for hyperparameter search)
        use_ray: Optional override for Ray usage
    """
    # SLURM DDP Debugging
    # print(f"--- RANK {os.environ.get('SLURM_PROCID', None)} ---")
    # print(f"ROCR_VISIBLE_DEVICES = {os.environ.get('ROCR_VISIBLE_DEVICES', None)}")
    # print(f"HIP_VISIBLE_DEVICES = {os.environ.get('HIP_VISIBLE_DEVICES', None)}")
    # print(f"CUDA_VISIBLE_DEVICES = {os.environ.get('CUDA_VISIBLE_DEVICES', None)}")
    # print(f"torch.cuda.device_count() = {torch.cuda.device_count()}")
    # print("--------------------")
    # sys.stdout.flush()

    if experiment is None:
        # Parse command line arguments (normal CLI usage)
        parser = argparse.ArgumentParser(description="Train BCos model with Ray support")
        parser.add_argument(
            "--experiment_name", type=str, default="ResNet50",
            help="Name of the experiment configuration to use"
        )
        parser.add_argument(
            "--no-ray", action="store_true", default=True,
            help="Disable Ray distributed training (use standard Lightning)"
        )
        parser.add_argument(
            "--ray_num_workers", type=int, default=None,
            help="Number of Ray workers (overrides experiment config)"
        )
        parser.add_argument(
            "--ray_use_gpu", action="store_true", default=True,
            help="Use GPU with Ray workers"
        )
        parser.add_argument(
            "--ray_address", type=str, default=None,
            help="Ray cluster address (for connecting to existing cluster)"
        )
        
        parsed_args, unknown_args = parser.parse_known_args()
        
        additional_args = parse_unknown_args(unknown_args)

        config_path = "./configs/config.yaml"
        model_config_path = "./configs/models.yaml"
        experiment = Experiment.from_yaml_paths(config_path=config_path, model_config_path=model_config_path, experiment_name=parsed_args.experiment_name)
        experiment.override_arguments(**additional_args)
        
        use_ray_flag = not parsed_args.no_ray if use_ray is None else use_ray
        ray_num_workers = parsed_args.ray_num_workers
        ray_use_gpu = parsed_args.ray_use_gpu
        ray_address = parsed_args.ray_address
    else:
        # Direct function call (hyperparameter search usage)
        use_ray_flag = True if use_ray is None else use_ray
        ray_num_workers = None
        ray_use_gpu = True
        ray_address = None
    
    torch.set_float32_matmul_precision(experiment.matmul_precision)

    # Configure Ray
    ray_config = RayTrainingConfig(
        use_ray=use_ray_flag,
        num_workers=ray_num_workers,  # None means use experiment default
        use_gpu=ray_use_gpu,
        ray_address=ray_address,
        experiment=experiment,  # Pass experiment for default values
    )

    # Initialize Ray if needed
    if ray_config.use_ray:
        ray_config.initialize_ray()
        print(f"🚀 Using Ray distributed training with {ray_config.num_workers} workers")
        print(f"📊 W&B logging will be handled by Ray workers")
        print(f"🔧 Resources per worker: {ray_config.resources_per_worker}")
        print(f"💾 Experiment data workers: {experiment.num_workers}, GPUs: {experiment.num_gpus}")
    else:
        print("🔥 Using standard Lightning training (Ray disabled)")
        # Initialize W&B run with experiment settings (only for non-Ray training)
        # wandb.init(
        #     project="Improved-Interpretability-and-Concepts",
        #     entity="raphaelmaser",
        #     name=experiment.experiment_name,
        #     group=experiment.group,
        #     config=experiment.to_wandb_config(),
        #     tags=experiment.tags,
        #     reinit=True,
        #     dir=os.path.join(os.environ["TEMP_DIR"], "wandb"),
        # )

    # Train the model
    if ray_config.use_ray:
        # Create Ray-enabled trainer
        trainer = RayLightningWrapper(
            experiment=experiment,
            use_ray=ray_config.use_ray,
            num_workers=ray_config.num_workers,
            use_gpu=ray_config.use_gpu,
            resources_per_worker=ray_config.resources_per_worker
        )
        trainer.fit()
    else:

        rank = int(os.environ.get('LOCAL_RANK', 0))

        # For srun multi-task DDP, each process should use 1 device
        # SLURM handles the device assignment via CUDA_VISIBLE_DEVICES
        is_slurm_multi_task = "SLURM_NTASKS_PER_NODE" in os.environ and int(os.environ["SLURM_NTASKS_PER_NODE"]) > 1
        
        # if is_slurm_multi_task:
        #     # Each srun process uses 1 device, total parallelism via multiple processes
        #     devices = 1  
        #     # Lightning needs to know about total world size
        #     num_nodes = int(os.environ["SLURM_NTASKS_PER_NODE"]) * int(os.environ.get("SLURM_NNODES", 1))
            
        #     # CRITICAL: Set these environment variables to help Lightning detect srun context
        #     os.environ["WORLD_SIZE"] = str(num_nodes)
        #     os.environ["RANK"] = os.environ.get("SLURM_PROCID", "0")
        #     os.environ["LOCAL_RANK"] = os.environ.get("SLURM_LOCALID", "0")
            
        #     print(f"🔧 SLURM DDP: devices={devices}, num_nodes={num_nodes}")
        # else:
        #     devices = "auto"
        #     num_nodes = 1

        if is_slurm_multi_task:
            # Each srun-spawned process uses 1 device
            devices = int(os.environ["SLURM_NTASKS_PER_NODE"])
            # Total "nodes" from Lightning's perspective = total processes
            num_nodes = int(os.environ.get("SLURM_NNODES", 1))
            print(f"🔧 SLURM DDP: devices={devices}, num_nodes={num_nodes}")
        else:
            devices = "auto"
            num_nodes = 1

            
        # Calculate effective batch size for wandb logging
        # devices can be "auto" or an integer
        if devices == "auto":
            # When devices is "auto", Lightning will use all available GPUs on the node
            devices_per_node = torch.cuda.device_count() if torch.cuda.is_available() else 1
        else:
            devices_per_node = devices
            
        effective_batch_size = experiment.batch_size * devices_per_node * num_nodes * experiment.accumulate_grad_batches
        print(f"📊 Effective batch size: {effective_batch_size} (batch_size={experiment.batch_size} × devices={devices_per_node} × nodes={num_nodes} × grad_accum={experiment.accumulate_grad_batches})")

        logger = None
        if rank == 0:
            # Calculate wandb config with effective batch size
            wandb_config = experiment.to_wandb_config()
            wandb_config["effective_batch_size"] = effective_batch_size
            wandb_config["devices_per_node"] = devices_per_node
            wandb_config["num_nodes"] = num_nodes
            
            # Standard Lightning training (when Ray is disabled)
            logger = WandbLogger(
                project="Improved-Interpretability-and-Concepts",
                entity="raphaelmaser",
                log_model=False,
                name=experiment.experiment_name,
                save_dir=os.path.join(os.environ["TEMP_DIR"], "wandb"),
                config=wandb_config,
                tags=experiment.tags,
                group=experiment.group
            )
        
        model_checkpoint = ModelCheckpoint(
            save_last=True, 
            every_n_epochs=20,
        )
        
        epochtimer = TimerCallback()
        
        # Comprehensive PyTorch profiler for detailed performance analysis
        # Configure for AMD GPU (MI300A) with ROCm

        # # Add GPU profiling activity based on available backend
        # if torch.cuda.is_available():
        #     if hasattr(torch.profiler.ProfilerActivity, 'CUDA'):
        #         # NVIDIA GPUs
        #         profiler_activities.append(torch.profiler.ProfilerActivity.CUDA)
        #     # For AMD GPUs with ROCm, CPU profiling will still capture GPU operations
        #     # ROCm operations are typically captured through CPU activity tracing

        profiler = None
        if experiment.use_profiler:
            profiler_activities = [torch.profiler.ProfilerActivity.CPU]
            profiler_activities.append(torch.profiler.ProfilerActivity.CUDA)

            profiler = PyTorchProfiler(
                dirpath=os.path.join(os.environ["TEMP_DIR"], "profiler"),
                filename="perf_logs",
                group_by_input_shape=True,
                activities=profiler_activities,
            schedule=torch.profiler.schedule(
                wait=1,
                warmup=1,
                active=3,
                repeat=1
            ),
            on_trace_ready=torch.profiler.tensorboard_trace_handler(
                os.path.join(os.environ["TEMP_DIR"], "profiler", "tensorboard")
            ),
            record_shapes=True,
            profile_memory=True,
            with_stack=True
        )

        # For your B-cos ViT model
        strategy = FSDPStrategy(
            # Define which layers to checkpoint
            activation_checkpointing_policy={
                # Your transformer encoder blocks
                Encoder,  # Your Encoder class from the model
            },
            
            # Optional: Use same policy for auto-wrapping
            auto_wrap_policy=ModuleWrapPolicy({Encoder}),
            
            # FSDP sharding strategy
            sharding_strategy="FULL_SHARD",
        )

        enable_progress_bar = not is_slurm_multi_task

        trainer = L.Trainer(
            max_epochs=experiment.epochs,
            logger=logger,
            accelerator="auto",
            devices=devices,  # Match SLURM --ntasks-per-node
            num_nodes=num_nodes,  # Match SLURM --nodes
            precision=experiment.precision,
            profiler=profiler,
            default_root_dir=os.path.join(os.environ["TEMP_DIR"], "lightning"),
            limit_train_batches=experiment.limit_train_batches,
            callbacks=[model_checkpoint, epochtimer],
            limit_val_batches=experiment.limit_val_batches,
            # strategy=strategy,
            strategy="ddp",
            sync_batchnorm=False,  # Disable sync batch norm which can cause device issues on ROCm
            gradient_clip_val=experiment.gradient_clip_val,
            # gradient_clip_algorithm='value',  # This works with FSDP
            accumulate_grad_batches=experiment.accumulate_grad_batches,
            enable_progress_bar=enable_progress_bar,
            # num_sanity_val_steps=0,

        )
        
        data_module = BcosDataModule(experiment=experiment)
        lightning_module = BcosLightningModule(experiment=experiment)
        # if experiment.compile:
        #     lightning_module = torch.compile(
        #         lightning_module, 
        #         mode=experiment.compile_mode, 
        #         fullgraph=experiment.compile_fullgraph, 
        #         dynamic=experiment.compile_dynamic,
        #     )
        
        trainer.fit(lightning_module, data_module)

    print("✅ Training completed!")


if __name__ == "__main__":

    main()
