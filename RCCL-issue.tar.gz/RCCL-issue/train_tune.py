#!/usr/bin/env python3
"""
Unified Ray Tune Training
========================

This script ALWAYS uses Ray Tune, whether you're running a single experiment
or a hyperparameter search. The difference is just in how you specify parameters:

- Single values: train_tune.py --lr 0.001 → Single trial
- Multiple values: train_tune.py --lr [0.001,0.01,0.1] → Grid search across LRs
- Mixed: train_tune.py --lr [0.001,0.01] --opt    print(f"\n{'='*80}")
       print(f"🚀 Ray Tune Training")
    print(f"📊 Experiment: {parsed_args.experiment_name}")
    print(f"    # Handle experiment resumption
    resume_path = None
    if parsed_args.resume:
        # Auto-find latest experiment with same name
        resume_path = find_latest_experiment(parsed_args.experiment_name)al_gpus} total, {parsed_args.gpus_per_trial} per trial")
    print(f"💻 CPUs: {cpus_per_trial} per trial")nt(f"🚀 Ray Tune Training")
    print(f"📊 Experiment: {parsed_args.experiment_name}")
    print(f"🎯 GPUs: {total_gpus} total, {parsed_args.gpus_per_trial} per trial")
    print(f"💻 CPUs: {cpus_per_trial} per trial")print(f"🚀 Ray Tune Training")
    print(f"{'='*80}")
    print(f"📊 Experiment: {parsed_args.experiment_name}")
    print(f"🎯 GPUs: {parsed_args.num_gpus} total, {parsed_args.gpus_per_trial} per trial")
    print(f"💻 CPUs: {cpus_per_trial} per trial")
    if parsed_args.max_concurrent is not None:
        print(f"🔄 Max concurrent: {parsed_args.max_concurrent} (user-specified)")
    else:
        print(f"🔄 Max concurrent: Unlimited (Ray Tune will use resource limits)")
    
    if search_space:
        print(f"🔬 Search space: {list(search_space.keys())}")
        print(f"📈 Base config: {list(base_config.keys())}")
    else:
        print(f"📋 Single experiment config: {list(base_config.keys())}")
    print(f"{'='*80}\n")Grid search LRs, fixed optimizer

This unified approach means:
- Same script for single experiments and hyperparameter searches
- SLURM scripts just define parameter spaces
- Ray handles resource allocation automatically
- Flexible scheduling (1 GPU or 100 GPUs, same script)

Usage Examples:
    # Single experiment (1 trial)
    python train_tune.py --experiment_name test --lr 0.001 --optimizer adamw

    # Learning rate search (3 trials)
    python train_tune.py --experiment_name lr_search --lr [0.001,0.01,0.1]

    # Full grid search (12 trials: 3 LRs × 4 optimizers)
    python train_tune.py --experiment_name grid_search --lr [0.001,0.01,0.1] --optimizer [adam,adamw,sgd,ranger21]

    # Random search with ranges
    python train_tune.py --experiment_name random_search --lr "uniform(1e-5,1e-1)" --num_samples 50 --search_mode random
"""

import argparse
import ast
import os
import sys
from pathlib import Path
from typing import Dict, Any, List, Union

import ray
from ray import tune
from ray.tune import CLIReporter
from ray.tune.schedulers import ASHAScheduler, PopulationBasedTraining

# Add project root to Python path
project_root = Path(__file__).parent
sys.path.insert(0, str(project_root))

from train import main as train_main


def parse_parameter_value(value_str: str) -> Any:
    """Parse a parameter value that can be single, list, or distribution."""
    
    if value_str.startswith('[') and value_str.endswith(']'):
        # List format: [0.001,0.01,0.1] → grid search
        try:
            # Parse as Python list
            values = ast.literal_eval(value_str)
            return tune.grid_search(values)
        except:
            # Parse as comma-separated string list
            values = [v.strip() for v in value_str[1:-1].split(',')]
            # Try to convert to numbers
            try:
                values = [float(v) for v in values]
            except:
                pass  # Keep as strings
            return tune.grid_search(values)
    
    elif value_str.startswith('uniform(') or value_str.startswith('loguniform(') or value_str.startswith('randint('):
        # Distribution format: uniform(1e-5,1e-1) → random sampling
        if value_str.startswith('uniform('):
            args = value_str[8:-1].split(',')
            return tune.uniform(float(args[0]), float(args[1]))
        elif value_str.startswith('loguniform('):
            args = value_str[11:-1].split(',')
            return tune.loguniform(float(args[0]), float(args[1]))
        elif value_str.startswith('randint('):
            args = value_str[8:-1].split(',')
            return tune.randint(int(args[0]), int(args[1]))
    
    else:
        # Single value → no search
        try:
            # Try to convert to number
            if '.' in value_str:
                return float(value_str)
            else:
                return int(value_str)
        except:
            # Keep as string
            return value_str


from train import main as train_main, parse_unknown_args


def create_search_space_from_args(parsed_args, additional_args) -> tuple[Dict[str, Any], Dict[str, Any]]:
    """Create Ray Tune search space from command line arguments."""
    
    search_space = {}
    base_config = {}
    
    # Ray Tune specific arguments (these control the search behavior, not experiment parameters)
    tune_specific = {
        'search_mode', 'scheduler', 'num_samples', 'gpus_per_trial', 
        'max_concurrent', 'experiment_name', 'tags', 'ray_num_workers', 
        'ray_use_gpu', 'ray_address', 'no_ray'
    }
    
    # Process parsed arguments (from argparse)
    parsed_dict = vars(parsed_args)
    for key, value in parsed_dict.items():
        if key in tune_specific:
            # These are Ray Tune control parameters, add to base config
            base_config[key] = value
        elif value is not None:
            # This is a potential experiment parameter that could be tuned
            if isinstance(value, str):
                parsed_value = parse_parameter_value(value)
                # Check if it's a Ray Tune search space object
                if hasattr(parsed_value, '__class__') and 'tune' in str(type(parsed_value)):
                    search_space[key] = parsed_value
                else:
                    base_config[key] = parsed_value
            else:
                base_config[key] = value
    
    # Process additional arguments (from parse_unknown_args)
    # These can also be either single values or search spaces
    for key, value in additional_args.items():
        if isinstance(value, str):
            parsed_value = parse_parameter_value(value)
            # Check if it's a Ray Tune search space object
            if hasattr(parsed_value, '__class__') and 'tune' in str(type(parsed_value)):
                search_space[key] = parsed_value
            else:
                base_config[key] = parsed_value
        elif isinstance(value, list):
            # parse_unknown_args already converted [1e-3,1e-4] to a Python list
            # Convert it to Ray Tune grid search
            search_space[key] = tune.grid_search(value)
        else:
            base_config[key] = value
    
    return search_space, base_config


def create_trainable(base_config: Dict[str, Any], cpus_per_trial: int, verbose: bool = False):
    """Create a Ray Tune trainable function."""
    
    # Capture absolute paths in the closure (before Ray changes working directory)
    project_root = Path(__file__).parent.absolute()
    config_path = project_root / "configs" / "config.yaml"
    model_config_path = project_root / "configs" / "models.yaml"
    
    def trainable(config: Dict[str, Any]) -> None:
        """Trainable function that Ray Tune will execute."""
        
        # Always suppress trainable output to keep logs clean
        import sys
        import os
        # Redirect stdout and stderr to suppress all trial output
        sys.stdout = open(os.devnull, 'w')
        sys.stderr = open(os.devnull, 'w')
        # Add project root to path (in case Ray changed working directory)
        import sys
        if str(project_root) not in sys.path:
            sys.path.insert(0, str(project_root))
        
        # Load base experiment config (like original train.py)
        from experiment.experiment import Experiment
        
        # Get experiment name from base_config
        experiment_name = base_config.get('experiment_name', 'ResNet50')
        
        # Load experiment from YAML using absolute paths
        experiment = Experiment.from_yaml_paths(
            config_path=str(config_path), 
            model_config_path=str(model_config_path), 
            experiment_name=experiment_name
        )
        
        # Merge all arguments: base_config (CLI args) + config (Ray Tune trial params)
        all_overrides = {**base_config, **config}
        
        # Auto-calculate num_workers based on allocated CPUs if not explicitly set
        # Reserve 2 CPUs for main process and overhead, rest for data workers
        auto_num_workers = max(0, cpus_per_trial - 2)
        all_overrides['num_workers'] = auto_num_workers
        print(f"🔍 Auto-calculated num_workers: {cpus_per_trial} CPUs - 2 overhead = {auto_num_workers} workers")
            
        print(f"🔍 BEFORE experiment.override_arguments:")
        print(f"  - all_overrides['num_workers']: {all_overrides.get('num_workers', 'NOT SET')}")
        print(f"  - cpus_per_trial: {cpus_per_trial}")
        
        # Remove Ray Tune specific arguments before applying to experiment
        tune_specific = {
            'search_mode', 'scheduler', 'num_samples', 'gpus_per_trial', 
            'max_concurrent', 'tags', 'ray_num_workers', 'ray_use_gpu', 
            'ray_address', 'no_ray', 'verbose'
        }
        experiment_overrides = {k: v for k, v in all_overrides.items() if k not in tune_specific}
        
        print(f"🔍 experiment_overrides passed to experiment:")
        print(f"  - experiment_overrides['num_workers']: {experiment_overrides.get('num_workers', 'NOT SET')}")
        
        # Apply overrides (like original train.py)
        experiment.override_arguments(**experiment_overrides)
        
        print(f"🔍 AFTER experiment.override_arguments:")
        print(f"  - experiment.num_workers: {getattr(experiment, 'num_workers', 'NOT FOUND')}")
        if hasattr(experiment, 'config') and 'num_workers' in experiment.config:
            print(f"  - experiment.config['num_workers']: {experiment.config['num_workers']}")
        else:
            print(f"  - experiment.config has no num_workers key")
        
        # Force the correct num_workers value if it's wrong
        expected_num_workers = all_overrides.get('num_workers', cpus_per_trial - 2)
        actual_num_workers = getattr(experiment, 'num_workers', None)
        
        if actual_num_workers != expected_num_workers:
            print(f"🚨 MISMATCH! Expected num_workers={expected_num_workers}, but experiment.num_workers={actual_num_workers}")
            # Force the correct value
            if hasattr(experiment, 'config'):
                experiment.config['num_workers'] = expected_num_workers
                print(f"� FORCED experiment.config['num_workers'] = {expected_num_workers}")
            else:
                print(f"❌ Cannot fix: experiment has no config attribute")
        else:
            print(f"✅ num_workers is correct: {actual_num_workers}")
        
        # Final verification
        print(f"🔍 FINAL VERIFICATION:")
        print(f"  - experiment.num_workers: {getattr(experiment, 'num_workers', 'NOT FOUND')}")
        print(f"  - experiment.config['num_workers']: {experiment.config.get('num_workers', 'NOT FOUND') if hasattr(experiment, 'config') else 'NO CONFIG'}")
        
        # Debug: Print the actual experiment configuration
        print(f"🔍 Experiment config debug:")
        print(f"  - batch_size: {experiment.batch_size}")
        print(f"  - num_gpus: {experiment.num_gpus}")
        print(f"  - cpus_per_trial allocated by Ray: {cpus_per_trial}")
        
        # Run training with the current hyperparameters
        # Force use_ray=False to run single-worker training within each trial
        try:
            train_main(experiment, use_ray=False)
            
        except Exception as e:
            print(f"❌ Training failed with config {config}: {e}")
            import traceback
            print(f"❌ Full traceback: {traceback.format_exc()}")
            raise e
    
    return trainable


def get_scheduler(scheduler_type: str, metric: str = "val_accuracy"):
    """Get the trial scheduler."""
    
    if scheduler_type == "asha":
        return ASHAScheduler(
            metric=metric,
            mode="max",
            max_t=50,
            grace_period=5,
            reduction_factor=2
        )
    elif scheduler_type == "pbt":
        return PopulationBasedTraining(
            time_attr="training_iteration",
            metric=metric,
            mode="max",
            perturbation_interval=5,
        )
    else:  # none
        return None


def main():
    parser = argparse.ArgumentParser(
        description="Unified Ray Tune Training (single experiments or hyperparameter search)",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  Single experiment:
    python train_tune.py --experiment_name test --lr 0.001 --optimizer adamw

  Learning rate search:
    python train_tune.py --experiment_name lr_search --lr [0.001,0.01,0.1]

  Full grid search:
    python train_tune.py --experiment_name grid --lr [0.001,0.01] --optimizer [adam,adamw]

  Random search:
    python train_tune.py --experiment_name random --lr "loguniform(1e-5,1e-1)" --num_samples 20 --search_mode random

  Any experiment parameter can be tuned:
    python train_tune.py --experiment_name test --batch_size [16,32,64] --weight_decay [1e-5,1e-4,1e-3] --epochs 50
        """
    )
    
    # Only define Ray Tune specific arguments
    # All other arguments (lr, optimizer, batch_size, etc.) are handled by parse_unknown_args
    
    parser.add_argument("--experiment_name", type=str, required=True,
                       help="Experiment name")
    
    parser.add_argument("--group", type=str, default=None,
                       help="W&B group name")
    
    parser.add_argument("--tags", type=str, nargs="+", default=["ray_tune"],
                       help="W&B tags")
    
    # Ray Tune configuration
    parser.add_argument("--search_mode", type=str, default="grid",
                       choices=["grid", "random"],
                       help="Search mode for multiple values")
    
    parser.add_argument("--scheduler", type=str, default="none",
                       choices=["asha", "pbt", "none"],
                       help="Trial scheduler")
    
    parser.add_argument("--num_samples", type=int, default=None,
                       help="Number of trials (for random search)")
    
    # Ray configuration
    parser.add_argument("--gpus_per_trial", type=float, default=1.0,
                       help="GPUs per trial")
    
    parser.add_argument("--max_concurrent", type=int, default=None,
                       help="Max concurrent trials")
    
    parser.add_argument("--verbose", action="store_true", default=False,
                       help="Show detailed output from each trial")
    
    parser.add_argument("--resume", action="store_true", default=True,
                       help="Resume from latest experiment checkpoint")
    
    # Parse remaining unknown arguments (like the original train.py)
    parsed_args, unknown_args = parser.parse_known_args()
    additional_args = parse_unknown_args(unknown_args)
    
    # Create search space from arguments
    search_space, base_config = create_search_space_from_args(parsed_args, additional_args)
    
    # Handle verbosity settings BEFORE initializing Ray
    # Don't set AIR_VERBOSITY for SLURM - let our custom reporter handle output
    if 'AIR_VERBOSITY' in os.environ:
        print(f"🔍 Removing existing AIR_VERBOSITY={os.environ['AIR_VERBOSITY']} to use custom reporter")
        del os.environ['AIR_VERBOSITY']
    
    # Initialize Ray
    if not ray.is_initialized():
        # Check if we're connecting to an existing cluster (multinode setup)
        ray_address = os.environ.get('RAY_ADDRESS', None)
        if ray_address and ray_address != 'local':
            print(f"🔗 Connecting to existing Ray cluster at {ray_address}")
            # Force output to display when connecting to external cluster
            import logging
            ray.init(address=ray_address, logging_level=logging.INFO)
        else:
            print(f"🚀 Starting new Ray cluster")
            ray.init()
    else:
        print(f"🔗 Ray already initialized, using existing cluster")
    
    # Apply logging settings after Ray initialization
    if not parsed_args.verbose:
        import logging
        # Only reduce worker-level logging, not Ray Tune's progress display
        logging.getLogger("ray.worker").setLevel(logging.ERROR)
        logging.getLogger("ray.serve").setLevel(logging.ERROR)
        # But keep Ray Tune progress visible
        logging.getLogger("ray.tune").setLevel(logging.INFO)
    else:
        print(f"🔍 Verbose mode: keeping all Ray logging enabled")
    
    
    # Get available resources from Ray
    available_resources = ray.available_resources()
    total_cpus = available_resources.get('CPU', 20)  # Fallback to 20 if not available
    total_gpus = available_resources.get('GPU', 0)  # Auto-detect GPUs from Ray cluster
    
    print(f"🔍 Ray resource debug:")
    print(f"  - Available resources: {available_resources}")
    print(f"  - Total CPUs detected: {total_cpus}")
    print(f"  - Total GPUs detected: {total_gpus}")
    
    # Validate GPU availability
    if total_gpus == 0:
        print(f"⚠️  No GPUs detected by Ray! Available resources: {available_resources}")
        if parsed_args.gpus_per_trial > 0:
            print(f"   Setting gpus_per_trial to 0 (CPU-only mode)")
            parsed_args.gpus_per_trial = 0
    
    # Determine number of trials
    if search_space:
        # Calculate number of trials for grid search
        if parsed_args.search_mode == "grid":
            num_trials = 1
            for param, space in search_space.items():
                if hasattr(space, '_values'):  # grid_search
                    num_trials *= len(space._values)
            print(f"🔬 Grid search with {len(search_space)} parameters → {num_trials} trials")
        else:
            num_trials = parsed_args.num_samples or 20
            print(f"🎲 Random search with {len(search_space)} parameters → {num_trials} trials")
    else:
        num_trials = 1
        print(f"🎯 Single experiment (no hyperparameter search)")
    
    # Calculate resource allocation (but don't limit max_concurrent unless explicitly set)
    if total_gpus > 0:
        max_by_gpu = int(total_gpus / parsed_args.gpus_per_trial)
    else:
        max_by_gpu = float('inf')  # No GPU limit in CPU-only mode
    
    # Dynamic CPU allocation: proportional to GPU allocation
    # Each trial gets (gpus_per_trial / total_gpus) fraction of total CPUs
    gpu_fraction = parsed_args.gpus_per_trial / total_gpus
    cpus_per_trial_allocated = int(total_cpus * gpu_fraction)
    
    # Reserve some overhead (2-4 CPUs) for Ray and other processes
    overhead_cpus = 2
    cpus_per_trial_usable = max(1, cpus_per_trial_allocated - overhead_cpus)
    
    # Calculate theoretical max concurrent based on CPU allocation (for info only)
    max_by_cpu = int(total_cpus / cpus_per_trial_allocated) if cpus_per_trial_allocated > 0 else max_by_gpu
    
    # Debug: Print the calculation
    print(f"🔍 Dynamic resource allocation:")
    print(f"  - GPU fraction per trial: {parsed_args.gpus_per_trial} / {total_gpus} = {gpu_fraction:.2f}")
    print(f"  - CPUs allocated per trial: {total_cpus} * {gpu_fraction:.2f} = {cpus_per_trial_allocated}")
    print(f"  - CPUs usable per trial (after overhead): {cpus_per_trial_usable}")
    print(f"  - Theoretical max by GPU: {total_gpus} / {parsed_args.gpus_per_trial} = {max_by_gpu}")
    print(f"  - Theoretical max by CPU: {total_cpus} / {cpus_per_trial_allocated} = {max_by_cpu}")
    print(f"  - num_trials: {num_trials}")
    
    # Only set max_concurrent if explicitly provided by user
    if parsed_args.max_concurrent is not None:
        if parsed_args.verbose:
            print(f"  - User-specified max_concurrent: {parsed_args.max_concurrent}")
    else:
        if parsed_args.verbose:
            print(f"  - max_concurrent: Not set (Ray Tune will use resource limits)")
        # Don't set max_concurrent - let Ray Tune handle it based on resources
    
    # Use the dynamically calculated CPU allocation
    cpus_per_trial = cpus_per_trial_allocated
    
    print(f"🚀 Ray Tune Training")
    print(f"📊 Experiment: {parsed_args.experiment_name}")
    print(f"🎯 GPUs: {total_gpus} total, {parsed_args.gpus_per_trial} per trial")
    print(f"� CPUs: {cpus_per_trial} per trial")
    if parsed_args.max_concurrent is not None:
        print(f"�🔄 Max concurrent: {parsed_args.max_concurrent} (user-specified)")
    else:
        print(f"🔄 Max concurrent: Unlimited (Ray Tune will use resource limits)")
    
    
    if search_space:
        print(f"🔬 Search space: {list(search_space.keys())}")
        print(f"📈 Base config: {list(base_config.keys())}")
    else:
        print(f"📋 Single experiment config: {list(base_config.keys())}")
    
    # Create trainable
    trainable = create_trainable(base_config, cpus_per_trial, verbose=parsed_args.verbose)
    
    # Configure scheduler
    scheduler = get_scheduler(parsed_args.scheduler)
    
    # Configure reporter with Ray Tune's default nice formatting
    if search_space:
        # For hyperparameter searches, show key metrics and parameters
        reporter = CLIReporter(
            metric_columns=["MulticlassAccuracy_val/dataloader_idx_0", "val_loss/dataloader_idx_0", "epoch"],
            parameter_columns=list(search_space.keys()),
            print_intermediate_tables=True,  # Force intermediate table printing
            max_progress_rows=20,  # Show more rows for better visibility
            max_error_rows=5,
            max_column_length=20
        )
    else:
        # For single experiments, minimal output
        reporter = CLIReporter(
            metric_columns=["MulticlassAccuracy_val/dataloader_idx_0", "val_loss/dataloader_idx_0", "epoch"],
            print_intermediate_tables=True,  # Force intermediate table printing
            max_progress_rows=10
        )
    
    # Force output flushing for multinode environments
    print(f"\n🎯 Starting Ray Tune with {num_trials} trials...")
    print(f"📊 Progress will be displayed below:")
    print(f"{'='*80}")
    sys.stdout.flush()  # Force immediate output
    
    # Prepare TuneConfig - only set max_concurrent_trials if explicitly provided
    tune_config_kwargs = {
        "scheduler": scheduler,
        "num_samples": num_trials,
    }
    if parsed_args.max_concurrent is not None:
        tune_config_kwargs["max_concurrent_trials"] = parsed_args.max_concurrent
    
    # Smart experiment tracking and resumption
    storage_path = Path.cwd() / "ray_results"
    
    def find_latest_experiment(experiment_name: str) -> Path | None:
        """Find the most recent experiment directory for a given name."""
        pattern = f"tune_{experiment_name}_*"
        matching_dirs = list(storage_path.glob(pattern))
        if matching_dirs:
            # Sort by modification time, return most recent
            latest = max(matching_dirs, key=lambda p: p.stat().st_mtime)
            return latest
        return None
    
    def get_experiment_config_hash(search_space: dict, base_config: dict) -> str:
        """Create a hash of the experiment configuration for tracking."""
        import hashlib
        import json
        
        # Create a deterministic representation of the config
        config_repr = {
            "search_space": str(sorted(search_space.items())),
            "base_config": {k: v for k, v in sorted(base_config.items()) 
                           if k not in ['tags', 'group']}  # Exclude non-essential fields
        }
        config_str = json.dumps(config_repr, sort_keys=True)
        return hashlib.md5(config_str.encode()).hexdigest()[:8]
    
    # Handle experiment resumption
    resume_path = None
    if parsed_args.resume_path:
        # Explicit path provided
        resume_path = Path(parsed_args.resume_path)
        if not resume_path.exists():
            print(f"❌ Resume path not found: {resume_path}")
            exit(1)
        print(f"🔄 Resuming from explicit path: {resume_path}")
        
    elif parsed_args.resume:
        # Auto-find latest experiment with same name
        resume_path = find_latest_experiment(parsed_args.experiment_name)
        if resume_path:
            print(f"🔄 Found latest experiment: {resume_path}")
            print(f"� Created: {resume_path.stat().st_mtime}")
            
            # Verify it's the same configuration
            config_hash = get_experiment_config_hash(search_space, base_config)
            expected_pattern = f"tune_{parsed_args.experiment_name}_{config_hash}_"
            
            if config_hash in resume_path.name:
                print(f"✅ Configuration matches (hash: {config_hash})")
            else:
                print(f"⚠️  Configuration may have changed")
                print(f"   Found: {resume_path.name}")
                print(f"   Expected pattern: {expected_pattern}*")
                response = input("Continue anyway? [y/N]: ")
                if response.lower() != 'y':
                    print("Aborting resume")
                    exit(1)
        else:
            print(f"❌ No previous experiment found for '{parsed_args.experiment_name}'")
            print(f"🆕 Starting new experiment instead")
            parsed_args.resume = False
    
    # Configure experiment name with config hash for uniqueness
    config_hash = get_experiment_config_hash(search_space, base_config)
    unique_experiment_name = f"tune_{parsed_args.experiment_name}_{config_hash}"
    
    # Check for existing experiments with same config
    if not parsed_args.resume:
        existing = find_latest_experiment(f"{parsed_args.experiment_name}_{config_hash}")
        if existing:
            print(f"⚠️  Found existing experiment with same configuration:")
            print(f"   {existing}")
            print(f"💡 Use --resume to continue, or change parameters for new experiment")
    
    # Configure RunConfig
    run_config_kwargs = {
        "name": unique_experiment_name,
        "progress_reporter": reporter,
        "storage_path": str(storage_path),
    }
    
    if parsed_args.resume and resume_path:
        # Use the existing experiment directory name
        run_config_kwargs["name"] = resume_path.name
        run_config_kwargs["resume"] = "AUTO"
        print(f"🔄 Auto-resume enabled for: {resume_path.name}")
    else:
        print(f"🆕 Starting new experiment: {unique_experiment_name}")
    
    # Run with Ray Tune
    tuner = tune.Tuner(
        tune.with_resources(trainable, resources={"cpu": cpus_per_trial, "gpu": parsed_args.gpus_per_trial}),
        param_space=search_space if search_space else {},
        tune_config=tune.TuneConfig(**tune_config_kwargs),
        run_config=tune.RunConfig(**run_config_kwargs)
    )
    
    try:
        results = tuner.fit()
        
        # Force output flushing
        print(f"\n{'='*80}")
        sys.stdout.flush()
        
        if num_trials > 1:
            # Print best results for searches
            best_result = results.get_best_result(metric="val_accuracy", mode="max")
            print(f"\n🏆 Best trial:")
            if best_result and best_result.metrics and 'val_accuracy' in best_result.metrics:
                print(f"📈 Validation accuracy: {best_result.metrics['val_accuracy']:.4f}")
            else:
                print(f"📈 Validation accuracy: Not available")
            if search_space and best_result:
                print(f"🔧 Best config: {best_result.config}")
            
            # Save results
            results_df = results.get_dataframe()
            results_path = Path.cwd() / f"tune_results_{parsed_args.experiment_name}.csv"
            results_df.to_csv(results_path, index=False)
            print(f"💾 Results saved to: {results_path}")
        else:
            print(f"\n✅ Single experiment completed!")
        
        # Final output flush
        sys.stdout.flush()
        
    except Exception as e:
        print(f"❌ Training failed: {e}")
        sys.stdout.flush()
        raise e
    
    finally:
        ray.shutdown()


if __name__ == "__main__":
    main()
