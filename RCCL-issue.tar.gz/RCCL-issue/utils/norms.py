import torch
import torch.nn as nn

class DynamicTanh(nn.Module):
    """
    A corrected PyTorch implementation of Dynamic Tanh (DyT).
    
    This version accepts a 'num_features' argument in its constructor to act as a 
    seamless drop-in replacement for layers like BatchNorm2d, but ignores it.
    It also correctly initializes alpha as a floating-point tensor.
    """
    def __init__(self, num_features: int, initial_alpha: float = 1.0, **kwargs):
        """
        Initializes the Dynamic Tanh module.
        
        Args:
            num_features (int): This argument is accepted to match the signature of 
                                standard norm layers (e.g., BatchNorm2d) but is ignored.
            initial_alpha (float): The starting value for the learnable parameter α.
        """
        super().__init__()
        # The actual fix: ensure the tensor is created with a floating-point dtype.
        self.alpha = nn.Parameter(torch.tensor(initial_alpha, dtype=torch.float32))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Applies the Dynamic Tanh function to the input tensor.
        """
        out: torch.Tensor =  torch.tanh(self.alpha * x)
        return out
