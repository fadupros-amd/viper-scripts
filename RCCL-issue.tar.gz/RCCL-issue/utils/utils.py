
import torch
from torch import Tensor

def add_batch_if_missing(tensor: Tensor):
    shape_len = len(tensor.shape)
    if shape_len > 4 or shape_len < 3:
        raise Exception(f"Tensor cannot have dimensionality higher than 4 or lower than 3. Shape was {tensor.shape}")
    elif shape_len == 4:
        return tensor
    else:
        return tensor.unsqueeze(dim=0)

        


