"""
Visualization Processor Class

This module contains the VisualizationProcessor class that handles all visualization-related 
operations including contribution image logging and visualization processing. This class 
decouples the visualization logic from the LightningModule for better maintainability 
and separation of concerns.
"""

import gc
import wandb
import torch
import torch.nn.functional as F
from typing import Dict, Optional, Any, cast
from matplotlib import pyplot as plt
from lightning.pytorch import Trainer
from models.utils import is_bcos, get_layer_from_experiment


class VisualizationProcessor:
    """
    Handles all visualization-related operations.
    
    This class provides methods for:
    - Standard image visualization with confidence filtering
    - Contribution image logging to wandb
    - Grid PG visualization processing
    - Wandb image creation from visualization results
    """
    
    def __init__(self, experiment, model, explain_fn, forward_fn, device, grid_pg_processor=None):
        """
        Initialize the VisualizationProcessor.
        
        Args:
            experiment: The experiment configuration object
            model: The neural network model
            explain_fn: Function to generate explanations (from LightningModule)
            forward_fn: Function for forward pass (from LightningModule)
            device: The device to run computations on
            grid_pg_processor: Optional GridPGProcessor for grid visualization
        """
        self.experiment = experiment
        self.model = model
        self.explain_fn = explain_fn
        self.forward_fn = forward_fn
        self.device = device
        self.grid_pg_processor = grid_pg_processor
    
    def visualize(self, batch, dataloader_idx):
        """
        Performs visualization steps for different dataloaders. Only works for batchsize=1 currently.

        Args:
            batch: The current batch of data.
            dataloader_idx (int): The index of the dataloader.

        Returns:
            dict: A dictionary containing visualization data, or None if not applicable.
        """
        self.model.eval()
        if dataloader_idx == 0:
            return self._visualize_standard_images(batch)
        elif dataloader_idx == 1:
            if self.grid_pg_processor:
                return self.grid_pg_processor.visualize_grid_images(batch)
            else:
                raise ValueError("GridPGProcessor not provided but Grid PG visualization requested")
        else:
            raise NotImplementedError("Dataloader index out-of-range")

    def _visualize_standard_images(self, batch):
        """
        Visualization for standard validation set with confidence filtering.
        
        Args:
            batch: The input batch (inputs, targets)
            
        Returns:
            dict: Visualization results or None if confidence too low
        """
        inputs, targets = batch
        
        # Check confidence before generating explanations
        with torch.no_grad():
            logits = self.forward_fn(inputs)
            
            # Convert logits to probabilities based on model type
            if is_bcos(self.model):
                confidence = F.sigmoid(logits)
            else:
                confidence = F.softmax(logits, dim=-1)
            
            # Get confidence for the target class
            target_confidence = torch.gather(confidence, dim=1, index=targets.unsqueeze(1)).squeeze(1)
        
        confidence_threshold = self.experiment.standard_explanations_confidence_threshold
        
        # Only process if confidence exceeds threshold
        if target_confidence.item() > confidence_threshold:
            layer = get_layer_from_experiment(model=self.model, experiment=self.experiment)
            expl_out = self.explain_fn(inputs, explain_class=targets.item(), mode="native", layer=layer)
            # Add confidence information to the result
            expl_out["confidence"] = target_confidence.item()
            return expl_out
        else:
            # Return None if confidence is too low
            return None

    def log_contribution_images(self, trainer, logger, current_epoch):
        """
        Generate and log contribution images for the first x images from validation and PG datasets.
        
        Args:
            trainer: The PyTorch Lightning trainer
            logger: The wandb logger
            current_epoch: Current training epoch
        """
        num_images = self.experiment.number_of_visualization_samples
        
        # Only log images every N epochs to avoid excessive logging
        log_frequency = getattr(self.experiment, 'log_images_every_n_epochs', 5)
        
        if not hasattr(trainer, 'datamodule'):
            return
            
        if current_epoch % log_frequency != 0:
            return
        
        # Get dataloaders
        trainer_cast = cast(Trainer, trainer)
        
        if not hasattr(trainer_cast, 'datamodule') or trainer_cast.datamodule is None:
            return

        if hasattr(trainer, 'val_dataloaders'):
            val_dataloaders = trainer.val_dataloaders
        else:
            raise Exception("Trainer does not have val_dataloaders attribute. Make sure to set up the datamodule correctly.")
        
        if len(val_dataloaders) >= 2:
            standard_val_loader = val_dataloaders[0]
            pg_loader = val_dataloaders[1]
            
            images_to_log = {}
            
            # Process standard validation images
            count = 0
            for batch_idx, batch in enumerate(standard_val_loader):
                if count >= num_images:
                    break
                    
                inputs, targets = batch
                batch = inputs.to(self.device).requires_grad_(True), targets.to(self.device)
                
                for i in range(batch[0].shape[0]):
                    # Extract single sample and move to device with gradient requirements
                    inputs = batch[0][i:i+1].requires_grad_(True)
                    targets = batch[1][i:i+1]
                    single_batch = (inputs, targets)
                    
                    # Use visualize method for standard validation
                    vis_result = self.visualize(single_batch, dataloader_idx=0)
                    
                    if vis_result and "explanation" in vis_result:
                        confidence = vis_result.get("confidence", 0.0)
                        contrib_map = vis_result["explanation"]
                        
                        images_to_log[f"standard_val_{count}"] = wandb.Image(
                            contrib_map,
                            file_type="png"
                        )
                        count += 1
                        
                    if count >= num_images:
                        break
            
            gc.collect()  # Collect garbage to free memory
            
            # Process PG dataset images
            count = 0
            for batch_idx, batch in enumerate(pg_loader):
                if count >= num_images:
                    break
                    
                inputs, targets = batch
                batch = inputs.to(self.device).requires_grad_(True), targets.to(self.device)
                
                for i in range(batch[0].shape[0]):
                    # Extract single sample and move to device with gradient requirements
                    inputs = batch[0][i:i+1].to(self.device).requires_grad_(True)
                    targets = batch[1][i:i+1].to(self.device)
                    single_batch = (inputs, targets)
                    
                    # Use visualize method for PG dataset
                    vis_result = self.visualize(single_batch, dataloader_idx=1)
                    
                    if vis_result and "contribution_maps" in vis_result:
                        contrib_maps = vis_result["contribution_maps"]
                        
                        # Log the first grid cell's contribution map
                        contrib_map = contrib_maps[0].detach().cpu().squeeze().numpy()
                        
                        images_to_log[f"pg_dataset_{count}"] = wandb.Image(
                            contrib_map,
                            file_type="png"
                        )
                        count += 1
                        
                    if count >= num_images:
                        break
        
            # Log to wandb
            if images_to_log and logger:
                log_dict = {
                    **images_to_log,  # Unpack the dictionary of images
                    "epoch": current_epoch
                }
                logger.experiment.log(log_dict)

    def create_pg_wandb_images_from_vis_result(self, vis_result, caption_prefix, images_to_log):
        """
        Create wandb images for PG dataset visualization from vis_result.
        
        Args:
            vis_result: The visualization result dictionary
            caption_prefix: Prefix for the image caption
            images_to_log: List to append wandb images to
        """
        try:
            # Extract data from vis_result
            inputs = vis_result["inputs"]
            targets = vis_result["targets"]
            contribution_maps = vis_result["contribution_maps"]
            scale = vis_result["scale"]
            
            # Create grid visualization
            fig, axes = plt.subplots(2, scale, figsize=(scale*3, 6))
            
            # Original image
            input_np = inputs[0].detach().cpu().permute(1, 2, 0).numpy()
            input_np = (input_np - input_np.min()) / (input_np.max() - input_np.min() + 1e-8)
            
            # Handle grayscale images
            if input_np.shape[-1] == 1:
                input_np = input_np.squeeze(-1)
                axes[0, 0].imshow(input_np, cmap='gray')
            else:
                axes[0, 0].imshow(input_np)
            
            axes[0, 0].set_title("Original Image")
            axes[0, 0].axis('off')
            
            # Hide unused subplots in first row
            for j in range(1, scale):
                axes[0, j].axis('off')
            
            # Contribution maps for each grid cell
            for i in range(min(scale, len(contribution_maps))):
                contrib_np = contribution_maps[i].detach().cpu().squeeze().numpy()
                contrib_np = (contrib_np - contrib_np.min()) / (contrib_np.max() - contrib_np.min() + 1e-8)
                
                axes[1, i].imshow(contrib_np, cmap='hot')
                axes[1, i].set_title(f"Grid {i} (Target: {targets[0][i].item()})")
                axes[1, i].axis('off')
            
            plt.tight_layout()
            
            images_to_log.append(wandb.Image(fig, caption=f"{caption_prefix}_grid_analysis"))
            plt.close(fig)
            
        except Exception as e:
            import logging
            log = logging.getLogger(__name__)
            log.warning(f"Failed to create PG wandb images for {caption_prefix}: {e}")
