import os
import warnings
import matplotlib.pyplot as plt
import numpy as np
from data.data_module import BcosDataModule
from experiment.experiment import Experiment
from grid_pg.grid_pg_processor import GridPGProcessor
from models.lightning_module import BcosLightningModule, is_bcos, get_layer_from_experiment
import torch
from captum.attr import visualization as viz
from data.grid_pg import GridPGDataset
from data.imagenet import TinyImagenetDataset
import torch.nn.functional as F

DATA_PATH = "/BS/dnn_interpretablity_robustness_representation_learning/nobackup/data/imagenet"
SPLIT_TRAIN_PATH = "/BS/dnn_interpretablity_robustness_representation_learning/nobackup/data/imagenet/meta/tiny_imagenet_train.txt"
SPLIT_VAL_PATH = "/BS/dnn_interpretablity_robustness_representation_learning/nobackup/data/imagenet/meta/tiny_imagenet_val.txt"


def get_datamodule(add_inverse=False, scale=2, seed=42, normalize=False):
    experiment = Experiment.from_config_dict({
        "num_workers": 1,
        "batch_size": 1,
        "dataset": "TinyImagenet",
        "model": "Bcos" if add_inverse else "None",
        "seed": seed,
        "efficient_bcos": not add_inverse,
        "use_normalization": normalize,
    })

    data_module = BcosDataModule(
        experiment=experiment,
    )

    data_module.setup("predict")
    return data_module

def get_model(checkpoint, model_type="Checkpoint"):
    if model_type.lower() == "new":
        config_path = "/home/rmaser/Master-Thesis_Improved-Interpretability-and-Concepts/configs/config.yaml"
        model_config_path = "/home/rmaser/Master-Thesis_Improved-Interpretability-and-Concepts/configs/models.yaml"
        
        experiment = Experiment.from_yaml_paths(config_path=config_path, model_config_path=model_config_path, experiment_name=checkpoint)
        experiment.config.update({
            "efficient_bcos": False,
        })
        model = BcosLightningModule(experiment=experiment)

    elif model_type.lower() == "checkpoint":
        checkpoint = os.path.join(
            "/home/rmaser/Master-Thesis_Improved-Interpretability-and-Concepts/.cache/wandb/Improved-Interpretability-and-Concepts", checkpoint, "checkpoints/last.ckpt"
        )
        try:
            model = BcosLightningModule.load_from_checkpoint(checkpoint)
        except Exception as e:
            warnings.warn(f"Failed to load model from checkpoint {checkpoint}. Trying manual loading. Error: {e}")
            model = load_model_manually(checkpoint, checkpoint_id=checkpoint)
    else:
        raise ValueError(f"Unknown model type: {model_type}. Supported types are 'new' and 'checkpoint'.")
    
    return model

def load_model_manually(checkpoint_path, checkpoint_id):
    """Manual loading as last resort"""
    
    # Load checkpoint
    checkpoint_data = torch.load(checkpoint_path, map_location='cpu', weights_only=False)
    state_dict = checkpoint_data['state_dict']
    
    print(f"   Checkpoint contains {len(state_dict)} parameters")
    
    # Try to create model from hyperparameters in checkpoint
    if 'hyper_parameters' in checkpoint_data:
        hparams = checkpoint_data['hyper_parameters']
        model = BcosLightningModule(**hparams)
        
        # Load what we can
        model_state = model.state_dict()
        new_state = {}
        
        for key in model_state:
            key.replace(".conv_adapter.", ".conv_adapter_res_parallel.")

        model.load_state_dict(model_state, strict=True)
        
        #print(f"   Loaded {len(loaded_keys)}/{len(state_dict)} parameters")
        #if missing_keys:
        #   print(f"   Missing/mismatched keys: {len(missing_keys)}")

        return model
    else:
        raise Exception("No hyperparameters found in checkpoint")
    
def get_model_and_dataset_iterator(model_id, model_type="Checkpoint"):
    '''
    Helper function which takes checkpoint and returns lightning module and iterator for the dataset
    '''
    model = get_model(model_id, model_type=model_type)
    

    experiment = Experiment.from_config_dict(model.hparams.experiment.config)
    experiment.config.update({
        "num_workers": 1,
        "batch_size": 1,
        "dataset": "TinyImagenet",
        "efficient_bcos": False
    })

    data_module = BcosDataModule(
        data_path=DATA_PATH,
        split_file_train=SPLIT_TRAIN_PATH,
        split_file_val=SPLIT_VAL_PATH,
        experiment=experiment
    )
    data_module.setup("validation")
    return model, iter(data_module.val_dataloader())

def compute_positive_explanation(models_dict: dict, device):
    '''
    Computes explanation until the predictions agree with the actual labels for a certain number of models.

    Args:
        input_tuple: Model and dataset iterator
        device: The device to run the model on
        labels: The actual labels for the input
    Returns:
        models_dict (dict): Dict with models as key and explanation dict as value
    '''
    num_models = len(models_dict)  # Assuming input_tuple is a list of (model, iterator) tuplesc
    correct_predictions = 0 
    correct_predictions_dict = {key: None for key in models_dict.keys()}
    failed_predictions = {key: 0 for key in models_dict.keys()}

    num_trials = 0
    while correct_predictions < num_models:
        num_trials += 1
        for model_name, input_tuple in models_dict.items():
            model, iterator = input_tuple
            x, y = next(iterator)
            original_image = x.clone()[0].permute(1, 2, 0).detach().cpu().numpy()
            expl_out = model.explain(x)  # Pass a single batch iterator
            
            assert "prediction" in expl_out

            if expl_out["prediction"] == y.item():
                pred = expl_out["prediction"] 
                real = y.item()
                # print(f"Prediction was {pred} and target {real}")
                correct_predictions += 1
                expl_out["target"] = y
                expl_out["original_image"] = original_image
                correct_predictions_dict[model_name] = expl_out

            else:
                correct_predictions = 0  # Reset if any model predicts incorrectly
                failed_predictions[model_name] += 1

    print(f"Model predicted correctly! Correct predictions: {correct_predictions}/{num_models}. Took {num_trials} trials")
    for key in failed_predictions:
        print(f"Model {key} predicted {failed_predictions[key]} wrong labels")
    print("\n")

    return correct_predictions_dict


def scale_image(image):
    """
    Applies min-max scaling to a PyTorch tensor.
    """
    min_val = torch.min(image)
    max_val = torch.max(image)
    if max_val > min_val:
        # Apply min-max scaling
        scaled_image = (image - min_val) * torch.reciprocal(max_val - min_val)
    else:
        # Handle case of a constant image (avoid division by zero)
        scaled_image = torch.zeros_like(image) + 0.5 # e.g., set to gray

    # print(f"Scaled image range: Min={torch.min(scaled_image):.4f}, Max={torch.max(scaled_image):.4f}") # Verify range is [0, 1]
    return scaled_image

# def compute_attribution_and_plot_on_ax(models_dict, num_samples, device):
#     print(f"Using device \"{device}\"")
#     fig, axs = plt.subplots(num_samples*2, len(models_dict)+1, figsize=(6*len(models_dict),6*num_samples))

#     for sample in range(0, num_samples):
#         print(f"Computing sample {sample}")
#         models_explanation_dict = compute_positive_explanation(models_dict, device)

#         i = 1
#         for model, expl_out in models_explanation_dict.items():
#             ax = axs[sample*2, i]
#             ax_heat = axs[sample*2+1, i]

#             # if sample == 0:
#             ax.set_title(model, fontsize=10)

#             if "explanation" in expl_out:
#                 # print("expl_out shape: ", expl_out["explanation"].shape)
#                 ax.imshow(expl_out["explanation"])
#             if "contribution_map" in expl_out:
#                 models_dict[model][0].model.plot_contribution_map(expl_out["contribution_map"][0], ax = ax_heat)
#             else:
#                 assert "map" in expl_out, "key \"map\" needs to be in expl_out"
#                 # Convert PyTorch tensors to NumPy arrays before visualization
#                 attr_map = expl_out["map"][0].permute(1, 2, 0).detach().cpu().numpy()
#                 attr_map = np.repeat(attr_map, 3, axis=2)
#                 # original_img = scale_image(expl_out["original_image"])

#                 # print("attr_map shape: ", attr_map.shape)
#                 # print("orig_image shape: ", original_img.shape)
#                 # Pass a tuple of (figure, axis) instead of just the axis
#                 fig = ax.figure
#                 # viz.visualize_image_attr(attr_map, original_img, plt_fig_axis=(fig, ax), method="masked_image")
#             i += 1

#         axs[sample*2, 0].imshow((models_explanation_dict["ResNet50"]["original_image"]))
#         axs[sample*2+1, 0].imshow((models_explanation_dict["ResNet50"]["original_image"]))


#     plt.tight_layout()
#     plt.show()

#     return expl_out

def compute_attribution_and_plot_on_ax2(models_dict, num_samples, device, only_correct_predictions=False, normalize=False, show_colorbar=False, figure_size_multiplier=3, skip_samples=0, use_grid_score=False, confidence_threshold=0):
    warnings.filterwarnings("ignore")
    print(f"Using device \"{device}\"")
    
    # Determine filtering method (confidence takes priority over correctness)
    if confidence_threshold > 0:
        print(f"Filtering by confidence threshold: {confidence_threshold}")
    elif only_correct_predictions:
        print("Filtering for only correct predictions across all models")
    else:
        print("No filtering applied - showing all samples")
        
    if skip_samples > 0:
        print(f"Skipping {skip_samples} samples")
    if use_grid_score:
        print("Using grid score dataloader")
    
    num_rows = num_samples*2
    num_columns = len(models_dict)+1
    fig, axs = plt.subplots(num_rows, num_columns, figsize=(num_columns * figure_size_multiplier, num_rows * figure_size_multiplier))

    data_module = get_datamodule()
    # Use grid score dataloader (index 1) if flag is set, otherwise use regular validation dataloader (index 0)
    dataloader_idx = 1 if use_grid_score else 0
    dataloader = iter(data_module.val_dataloader()[dataloader_idx])
    
    # Skip the specified number of samples
    if skip_samples > 0:
        for _ in range(skip_samples):
            try:
                next(dataloader)
            except StopIteration:
                dataloader = iter(data_module.val_dataloader()[dataloader_idx])
                break

    data_module_bcos = get_datamodule(add_inverse=True, normalize=normalize)
    dataloader_bcos = iter(data_module_bcos.val_dataloader()[dataloader_idx])
    
    # Apply same skip for bcos dataloader
    if skip_samples > 0:
        for _ in range(skip_samples):
            try:
                next(dataloader_bcos)
            except StopIteration:
                dataloader_bcos = iter(data_module_bcos.val_dataloader()[dataloader_idx])
                break

    samples_collected = 0
    max_attempts = 1000  # Prevent infinite loops
    attempts = 0

    while samples_collected < num_samples and attempts < max_attempts:
        attempts += 1
        index = samples_collected * 2
        print(f"Computing sample {samples_collected + 1} (attempt {attempts})")
        
        try:
            image, label = next(dataloader)
            image_bcos, labels_bcos = next(dataloader_bcos)
        except StopIteration:
            print("Reached end of dataloader")
            break

        assert torch.equal(label, labels_bcos), f"Labels don't match: {label} vs {labels_bcos}"
        assert image.shape[0] == 1, f"Batchsize must be 1 for this method. Shape was {image.shape}"
        
        # Handle multiple labels for grid score dataloader
        if use_grid_score:
            # For grid score, we have multiple labels (one for each grid cell)
            # We'll use the first label for consistency, but this could be adapted
            main_label = label[0, 0]  # First label from the grid
            print(f"Grid labels: {label.flatten().tolist()}, using main label: {main_label.item()}")
        else:
            # For regular dataloader, we have a single label
            main_label = label
        
        # Filter by confidence or correct predictions (but not both)
        if only_correct_predictions or confidence_threshold > 0:
            all_valid = True
            
            # Determine which filtering method to use
            use_confidence_filter = confidence_threshold > 0
            use_correctness_filter = only_correct_predictions and not use_confidence_filter
            
            for model_name, model in models_dict.items():
                model = model.to(device)
                if is_bcos(model):
                    x = image_bcos
                else:
                    raise Exception("Model is not bcos")
                    x = image
                x = x.to(device)
                
                if use_grid_score:
                    # For grid score, use GridPGProcessor to evaluate individual cells
                    # Create a temporary experiment object with grid_pg_scale=2
                    class TempExperiment:
                        def __init__(self):
                            self.grid_pg_scale = 2
                            self.grid_scale_confidence_threshold = confidence_threshold
                    
                    temp_exp = TempExperiment()
                    processor = GridPGProcessor(
                        experiment=temp_exp,
                        model=model,
                        explain_fn=None,  # Not needed for predictions
                        is_bcos_fn=is_bcos,
                        get_layer_fn=None  # Not needed for predictions
                    )
                    
                    # Get grid dimensions and predictions
                    W, H, scale, sub_image_size = processor.get_grid_dimensions(x)
                    grid_predictions = processor.get_grid_cell_predictions(x, scale, sub_image_size)
                    
                    # Extract first cell's prediction and confidence
                    first_cell_logits = grid_predictions[0, 0]  # [batch=0, grid_cell=0]
                    first_cell_probs = torch.softmax(first_cell_logits.unsqueeze(0), dim=1)
                    max_prob = torch.max(first_cell_probs).item()
                    pred_class = torch.argmax(first_cell_logits).item()
                    
                else:
                    # Regular single image evaluation
                    with torch.no_grad():
                        logits = model(x)
                        probs = torch.softmax(logits, dim=1)
                        max_prob = torch.max(probs).item()
                        pred_class = torch.argmax(logits, dim=1).item()
                
                # Apply the selected filtering method
                if use_confidence_filter and max_prob < confidence_threshold:
                    all_valid = False
                    print(f"Model {model_name} confidence: {max_prob:.3f} < {confidence_threshold:.3f}")
                    break
                elif use_correctness_filter and pred_class != main_label.item():
                    all_valid = False
                    print(f"Model {model_name} prediction: {pred_class}, label: {main_label.item()}")
                    break
            
            if not all_valid:
                continue  # Skip this sample and try the next one

        i = 1
        for model_name, model in models_dict.items():
            model = model.to(device)
            if is_bcos(model):
                x = image_bcos
            else:
                raise Exception("Model is not bcos")
                x = image
            x = x.to(device)

            layer = get_layer_from_experiment(model=getattr(model.model, '_orig_mod', model.model), experiment=model.experiment)
            
            # Use appropriate map_size for explanation generation
            map_size = 2 if use_grid_score else 1
            expl_out = model.explain(x, layer=layer, map_size=map_size)
            
            preds = expl_out["prediction"]
            # print(f"Prediction was: {preds}")
            # print(f"Label was {main_label}")
            
            # Check if prediction is correct (handle both single and multiple predictions)
            if use_grid_score:
                # For grid score, preds is a tensor with multiple predictions
                # Check if the first prediction matches the main label
                is_correct = preds[0] == main_label.item() if hasattr(preds, '__getitem__') else preds == main_label.item()
            else:
                # For regular prediction, preds is a single value
                is_correct = preds == main_label.item()
            
            correct_text = "✓ Correct" if is_correct else "✗ Incorrect"
            
            contribution_map_numpy = channel_last_and_squeeze(expl_out["contribution_map"])
            x_numpy = channel_last_and_squeeze(x)

            # if sample == 0:
            if only_correct_predictions:
                axs[index, i].set_title(f"{model_name}", fontsize=13)
            else:
                axs[index, i].set_title(f"{model_name}\n{correct_text}", fontsize=13)

            # Set the title for the left-most column (row title)
            string_label = data_module.convert_to_label(main_label.item())
            
            # Split label by comma for better readability
            def split_label_by_comma(label_text, max_words_per_line=3):
                """Split a label by commas and format it across multiple lines."""
                if not label_text or ',' not in label_text:
                    return label_text
                
                # Split by comma and strip whitespace
                parts = [part.strip() for part in label_text.split(',')]
                
                # Group parts into lines
                lines = []
                current_line = []
                
                for part in parts:
                    current_line.append(part)
                    if len(current_line) >= max_words_per_line:
                        lines.append(', '.join(current_line))
                        current_line = []
                
                # Add remaining parts if any
                if current_line:
                    lines.append(', '.join(current_line))
                
                return '\n'.join(lines)
            
            # Apply label splitting
            formatted_label = split_label_by_comma(string_label)

            # Improved y-axis labels with better spacing
            axs[index, 0].set_ylabel(f"{formatted_label}", rotation=0, va='center', ha='right', fontsize=10)
            axs[index+1, 0].set_ylabel(f"{formatted_label}", rotation=0, va='center', ha='right', fontsize=10)
            
            # Adjust label position to prevent overlap
            axs[index, 0].yaxis.set_label_coords(-0.1, 0.5)
            axs[index+1, 0].yaxis.set_label_coords(-0.1, 0.5)

            axs[index, 0].imshow(channel_last_and_squeeze(image))
            axs[index+1, 0].imshow(channel_last_and_squeeze(image))
            
            # Keep frames only for original images (first column)
            axs[index, 0].set_xticks([])
            axs[index, 0].set_yticks([])
            axs[index+1, 0].set_xticks([])
            axs[index+1, 0].set_yticks([])
            
            # Remove frames for all other plots (explanations and attributions)
            axs[index, i].axis('off')
            axs[index+1, i].axis('off')
            # axs[index+1, i].imshow(channel_last_and_squeeze(expl_out["contribution_map"].detach().cpu()))

            if "explanation" in expl_out:
                axs[index, i].imshow((expl_out["explanation"][0]))
                if not show_colorbar:
                    axs[index, i].axis('off')
            else:
                viz.visualize_image_attr(
                    contribution_map_numpy, 
                    original_image=x_numpy, 
                    plt_fig_axis=(fig, axs[index, i]), 
                    method="masked_image", 
                    use_pyplot=False,
                    show_colorbar=show_colorbar
                )

            viz.visualize_image_attr(
                contribution_map_numpy, 
                original_image=x_numpy, 
                plt_fig_axis=(fig, axs[index+1, i]), 
                use_pyplot=False,
                show_colorbar=show_colorbar
            )
            i += 1

        samples_collected += 1

    if attempts >= max_attempts and samples_collected < num_samples:
        print(f"Warning: Only found {samples_collected} valid samples after {max_attempts} attempts")

    # Improved layout with better spacing
    plt.tight_layout(pad=1.0, w_pad=0.5, h_pad=1.0)
    
    # Adjust subplots to make room for y-labels
    plt.subplots_adjust(left=0.15)
    plt.show()

def compute_grid_pointing_game(models_dict, num_samples, device, scale=2, seed=42):
    """Visualize grid pointing game results using the model's built-in visualize method.
    
    Args:
        models_dict: Dictionary of model names to model instances
        num_samples: Number of samples to visualize
        device: Device to use for computation
        scale: Grid scale (default 2)
        seed: Random seed (default 42)
    """
    print(f"Using device \"{device}\"")
    num_rows = num_samples * (scale**2)
    num_columns = len(models_dict) + 1
    fig, axs = plt.subplots(num_rows, num_columns, figsize=(num_columns * 4, num_rows * 4))

    data_module = get_datamodule()
    dataloader = data_module.val_dataloader()[1]
    dataloader = iter(dataloader)

    data_module_bcos = get_datamodule(add_inverse=True)
    dataloader_bcos = data_module_bcos.val_dataloader()[1]
    dataloader_bcos = iter(dataloader_bcos)

    for sample in range(num_samples):
        
        image, visualizations = get_positive_visualizations_for_models(models_dict=models_dict, dataloader=dataloader, dataloader_bcos=dataloader_bcos, device=device)
        
        for i, (model_name, model_viz) in enumerate(visualizations.items()):
            index = sample * scale**2
            for c in range(scale**2):
                label = data_module.convert_to_label(model_viz["targets"][0, c].item()) # First sample in Batch (Batchsize = 0) and label index c
                axs[index + c, 0].set_ylabel(label, rotation=90, va='center')
                axs[index + c, 0].imshow(channel_last_and_squeeze(image[0]))
                axs[index + c, i+1].clear()
                cmap = channel_last_and_squeeze(model_viz["contribution_maps"][c].unsqueeze(0))
                viz.visualize_image_attr(
                    cmap, plt_fig_axis=(fig, axs[index + c, i+1]), use_pyplot=False)
                axs[index + c, i+1].set_title(f"{model_name}\nScore={model_viz['grid_scores'][c]:.2f}")
                # if c == 0:
                #     axs[0, i+1].set_title(model_name, fontsize=10)

            
    
    plt.tight_layout()
    plt.show()

def get_positive_visualizations_for_models(models_dict, dataloader, dataloader_bcos, device):
    """
    Get visualizations for models with high confidence predictions.
    
    Args:
        models_dict: Dictionary mapping model names to model instances
        dataloader: Standard dataloader
        dataloader_bcos: BCOS dataloader
        device: Device to run models on
        
    Returns:
        tuple: (image, visualizations) where visualizations is a dictionary of model visualizations
    """
    visualizations = {}
    image = None
    max_attempts = 2000  # Limit the number of attempts to find high confidence samples
    attempt = 0

    while len(visualizations) == 0 and attempt < max_attempts:
        attempt += 1
        
        try:
            image, labels = next(dataloader)
            image_bcos, labels_bcos = next(dataloader_bcos)
            
            # Debug information about the images
                        
           
            
            all_models_succeeded = True
            
            for i, (model_name, model) in enumerate(models_dict.items(), 1):
                x = image_bcos if is_bcos(model) else image
                model = model.to(device)
                x, labels = x.to(device), labels.to(device)
                # print(f"Image shape: {x.shape}, min: {x.min()}, max: {x.max()}, mean: {x.mean()}")
                
                # Get raw predictions first to check confidence
                # with torch.no_grad():
                #     preds = model(x)
                #     pred_max, pred_index = torch.max(preds, dim=1)
                
                # Use model's built-in visualize method
                vis_data = model.visualize((x, labels), dataloader_idx=1)
                
                if vis_data is None:
                    # print(f"No high confidence samples for {model_name}")
                    all_models_succeeded = False
                    break
                
                # Store visualization data
                visualizations[model_name] = vis_data
                # print(f"High confidence sample was found for {model_name}")
            
            if not all_models_succeeded:
                visualizations = {}  # Reset if any model failed
            else:
                print(f"All models succeeded in attempt {attempt}")

        
        except StopIteration:
            print("Reached the end of the dataloader")
            break
        except Exception as e:
            print(f"Error during visualization: {str(e)}")
            import traceback
            traceback.print_exc()
            visualizations = {}

    if len(visualizations) == 0:
        print("Failed to find high confidence samples after multiple attempts")
        
    assert image is not None, "No image was loaded from the dataloader"
    return image, visualizations
            
                
            
    
def channel_last_and_squeeze(image):
    image = image.detach().cpu()
    # print(f"channel_last_and_squeeze gets shape: ", image.shape)
    # assert len(image.shape) == 4, f"Image shape should have 4 dimensions but had {len(image.shape)} with shape {image.shape}"
    if len(image.shape) > 3:
        image = image.squeeze()

    # Adds channel if it was removed in the first step (important for attribution map)
    if len(image.shape) == 2:
        image = image.unsqueeze(0)
    image = image.permute(1, 2, 0)


    return image.numpy()
